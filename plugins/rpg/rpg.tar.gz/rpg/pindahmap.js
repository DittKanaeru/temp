import db from '../../lib/database.js';
import fetch from 'node-fetch';

// Map locations and their descriptions
const mapLocations = {
    'Azure Stronghold': 'Benteng melayang dengan energi sihir yang kuat, tempat para penyihir memanfaatkan kekuatan kosmos. Udara bergemeretak dengan sihir, dan struktur yang mustahil menentang gravitasi.',
    'Ethereal Sand': 'Padang pasir tanpa akhir di mana realitas berkilau seperti fatamorgana. Pemanah melatih mata mereka pada target yang muncul dan menghilang dalam kabut panas.',
    'Ancient Ice': 'Tanah tandus beku dengan gletser raksasa dan benteng es. Para tanker berjaga melawan angin yang menggigit, tekad mereka sekuat es di bawah kaki mereka.',
    'Sunken Fire': 'Jaringan ruang bawah tanah berisi lava, tempat para pembunuh berlatih dalam bayangan yang berkedip. Panasnya menekan, tetapi hadiah untuk menguasai lingkungan ini sangatlah besar.',
    'Thunder Canyon': 'Jurang bergerigi di mana petir terus-menerus menyambar. Para petarung mengasah refleks mereka di tengah kekacauan, menjadi satu dengan badai.'
};

const mapImageUrl = 'https://telegra.ph/file/5491601395f67cf018480.jpg';

// Cooldown period in milliseconds (1 day)
const cooldownPeriod = 24 * 60 * 60 * 1000;

const handler = async (m, { conn, usedPrefix, text, command }) => {
    const user = db.data.users[m.sender];
    const locations = Object.keys(mapLocations);

    if (command === 'map') {
        const caption = user.position 
            ? `Sekarang kamu berada di ${user.position}. ${mapLocations[user.position]}`
            : "Kamu belum memilih lokasi. Gunakan command 'pindah' untuk memilih lokasi awalmu.";

        await conn.sendMessage(m.chat, {
            text: 'Peta Dunia',
            contextInfo: {
                externalAdReply: {
                    title: 'Peta Dunia',
                    body: 'Klik untuk melihat peta',
                    thumbnailUrl: mapImageUrl,
                    mediaType: 1,
                    renderLargerThumbnail: true
                }
            }
        });

        return m.reply(caption);
    }

    if (command === 'pindah' || command === 'move') {
        const chosenLocation = text.trim();

        if (!chosenLocation) {
            let message = `Wahai penjelajah, inilah saatnya untuk memilih jalan petualanganmu. Pilihlah dengan bijak, karena setiap pilihan membawamu ke tempat yang berbeda.\n\n*[ Peta Dunia ]*\n\n`;
            for (const [location, description] of Object.entries(mapLocations)) {
                message += `› *[ ${location} ]*\n${description}\n\n`;
            }

            message += `Cara menggunakan:\n${usedPrefix}pindah <nama_lokasi>\n\nContoh:\n${usedPrefix}pindah Ethereal Sand\n\nUntuk melihat posisimu saat ini, gunakan:\n${usedPrefix}map`;

            await conn.sendMessage(m.chat, {
                text: 'Peta Dunia',
                contextInfo: {
                    externalAdReply: {
                        title: 'Peta Dunia',
                        body: 'Klik untuk melihat peta',
                        thumbnailUrl: mapImageUrl,
                        mediaType: 1,
                        renderLargerThumbnail: true
                    }
                }
            });

            return m.reply(message);
        }

        const matchedLocation = locations.find(location => 
            location.toLowerCase() === chosenLocation.toLowerCase()
        );

        if (!matchedLocation) {
            return m.reply(`Lokasi yang kamu pilih tidak valid. Gunakan '${usedPrefix}map' untuk melihat daftar lokasi yang tersedia.`);
        }

        const now = Date.now();

        if (user.position) {
            if (user.lastLocationChange && now - user.lastLocationChange < cooldownPeriod) {
                return m.reply(`Hai penjelajah, kamu saat ini berada di ${user.position} dan tidak bisa berpindah sampai 1 hari ke depan. Jelajahilah area ini sebelum melanjutkan ke tempat lain.`);
            }
        }

        user.position = matchedLocation;
        user.lastLocationChange = now;
        
        await conn.sendMessage(m.chat, {
            text: 'Full size map',
            contextInfo: {
                externalAdReply: {
                    title: 'Peta Dunia',
                    body: `Selamat datang di ${user.position}, penjelajah! ${mapLocations[user.position]}`,
                    thumbnailUrl: mapImageUrl,
                    mediaType: 1,
                    renderLargerThumbnail: true
                }
            }
        });

        return m.reply(`Selamat datang di ${user.position}, penjelajah! ${mapLocations[user.position]} Berhati-hatilah dalam petualanganmu dan nikmatilah pengalamanmu di sini.`);
    }
};

handler.help = ['pindah', 'map'];
handler.tags = ['rpg'];
handler.command = /^(pindah|move|map)$/i;
handler.register = true;
handler.group = true;

export default handler;
