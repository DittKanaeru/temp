import db from '../../lib/database.js';

async function handler(m, { conn }) {
  let who;
  if (m.isGroup) who = m.mentionedJid[0] ? m.mentionedJid[0] : m.sender;
  else who = m.sender;
  if (typeof db.data.users[who] == "undefined")
    throw "Pengguna tidak ada didalam database";
  const pp = await conn
    .profilePictureUrl(who, "image")
    .catch((_) => "https://telegra.ph/file/ee60957d56941b8fdd221.jpg");

  conn.sendMessage(
    m.chat,
    {
      text: `Jumlah Limit mu adalah ❲ ${db.data.users[who].limit} ❳`,
      contextInfo: {
        externalAdReply: {
          title: `➜ ❲ ${db.data.users[who].limit} ❳`,
          showAdAttribution: true,
          mediaType: 1,
          thumbnailUrl: pp,
          renderLargerThumbnail: false
        }
      }
    },
    { quoted: m }
  );
}

handler.menu =  ["limit <@user>"];
handler.tags =  ["rpg"];
handler.command = /^(limit)$/i;
handler.register = true;

export default handler;
