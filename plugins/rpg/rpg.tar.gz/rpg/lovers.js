import { areJidsSameUser } from 'baileys';
import { database } from '../../lib/database.js'; // Import database
import PhoneNumber from 'awesome-phonenumber';
import { xpRange } from '../../lib/levelling.js';

let handler = async (m, { conn, text, participants, usedPrefix }) => {
  await database.read(); // Read the latest data from the database

  let args = text.trim().split(' ');
  let subCommand = args[0]; // Sub-command (tembak, iya, putus, profile)
  let number;
  let user;
  let me = m.sender;
  let targetUser; // Variable to store the target user JID

  // Function to convert number to WhatsApp JID format
  let toJID = number => number + '@s.whatsapp.net';

  // Function to clean the number from unnecessary characters
  function no(number) {
    return number.replace(/\s/g, '').replace(/([@+-])/g, '');
  }

  switch (subCommand) {

    // ===================
    // Command: 'tembak' (Ask someone to be in a relationship)
    // ===================
    case 'tembak':
      if (!m.quoted && !m.mentionedJid?.length && !args[1]) {
        return conn.reply(m.chat, `Masukan Nomor, Tag, atau Balas Pesan Doi.`, m);
      }

      if (m.mentionedJid?.length) {
        user = m.mentionedJid[0]; // If the user is tagged, extract the JID
      } else if (m.quoted) {
        user = m.quoted.sender; // If replying to a message, extract the sender
      } else {
        if (!isNaN(args[1])) {
          number = args[1];
        } else {
          return conn.reply(m.chat, `Nomor yang kamu masukan salah!`, m);
        }
        user = toJID(number); // Convert number to JID
      }

      let users = participants.find(v => areJidsSameUser(v.jid, user));
      if (!users) return conn.reply(m.chat, `Doi atau nomor tidak ditemukan, mungkin sudah keluar atau bukan anggota grup ini.`, m);
      if (user === m.sender) return conn.reply(m.chat, `Tidak bisa berpacaran dengan diri sendiri!`, m);
      if (user === conn.user.jid) return conn.reply(m.chat, `Maaf Kak, tapi saya sepenuhnya milik Xyroine.`, m);

      let spac = database.data.users[m.sender]?.pasangan;
      let pacar = database.data.users[user]?.pasangan;

      if (spac && database.data.users[spac]?.pasangan === m.sender && spac !== user) {
        return conn.reply(m.chat, `Kamu sudah berpacaran dengan @${spac.split('@')[0]}. Putus dulu (ketik .lovers putus) untuk menembak @${user.split('@')[0]}.`, m, {
          contextInfo: { mentionedJid: [user, spac] }
        });
      } else if (pacar) {
        return conn.reply(m.chat, `Maaf, @${user.split('@')[0]} sudah berpacaran dengan @${pacar.split('@')[0]}.`, m, {
          contextInfo: { mentionedJid: [user, pacar] }
        });
      }

      database.data.users[m.sender].pasangan = user;
      database.data.users[user].pendingPasangan = m.sender;
      await database.write();

      return conn.reply(m.chat, `Kamu baru saja mengajak @${user.split('@')[0]} berpacaran. Tunggu jawaban! Ketik *${usedPrefix}lovers iya* untuk menerima atau *${usedPrefix}lovers nggak/tolak* untuk menolak.`, m, {
        contextInfo: { mentionedJid: [user] }
      });

    // ===================
    // Command: 'iya' (when the user accepts the proposal)
    // ===================
    case 'iya':
      targetUser = database.data.users[m.sender]?.pendingPasangan;
      if (!targetUser) {
        return conn.reply(m.chat, `Tidak ada ajakan berpacaran yang menunggu jawaban dari kamu.`, m);
      }

      // Set both users as partners and save the date they become lovers
      const currentDate = new Date().toISOString(); // Store current date as "Date of lovers"
      database.data.users[m.sender].pendingPasangan = null;
      database.data.users[m.sender].pasangan = targetUser;
      database.data.users[m.sender].dateOfLovers = currentDate; // Save the date they became partners

      database.data.users[targetUser].pasangan = m.sender;
      database.data.users[targetUser].dateOfLovers = currentDate; // Save the date for the partner too
      await database.write();

      return conn.reply(m.chat, `Selamat! Kamu resmi berpacaran dengan @${targetUser.split('@')[0]} 💓`, m, {
        contextInfo: { mentionedJid: [targetUser, m.sender] }
      });

    // ===================
    // Command: 'nggak/tolak'
    // ===================
    case 'nggak':
    case 'tolak':
      targetUser = database.data.users[m.sender]?.pendingPasangan;
      if (!targetUser) {
        return conn.reply(m.chat, `Tidak ada ajakan berpacaran yang menunggu jawaban dari kamu.`, m);
      }

      database.data.users[m.sender].pendingPasangan = null;
      database.data.users[targetUser].pasangan = null;
      await database.write();

      return conn.reply(m.chat, `Kamu telah menolak ajakan berpacaran dari @${targetUser.split('@')[0]}.`, m, {
        contextInfo: { mentionedJid: [targetUser, m.sender] }
      });

    // ===================
    // Command: 'putus' (Break up with a partner)
    // ===================
    case 'putus':
      let ayg = database.data.users[m.sender];
      let beb = database.data.users[ayg.pasangan];

      if (!ayg.pasangan) {
        return conn.reply(m.chat, `Kamu Tidak Memiliki Pasangan.`, m);
      }

      if (!beb) {
        conn.reply(m.chat, `Berhasil Putus Hubungan Dengan @${ayg.pasangan.split('@')[0]}`, m, {
          contextInfo: { mentionedJid: [ayg.pasangan] }
        });
        ayg.pasangan = "";
        await database.write();
        return;
      }

      if (m.sender === beb.pasangan) {
        conn.reply(m.chat, `Berhasil Putus Hubungan Dengan @${ayg.pasangan.split('@')[0]}`, m, {
          contextInfo: { mentionedJid: [ayg.pasangan] }
        });
        ayg.pasangan = "";
        beb.pasangan = "";
        await database.write();
      } else {
        return conn.reply(m.chat, `Kamu Tidak Memiliki Pasangan.`, m);
      }
      break;

    // ===================
    // Command: 'profile' (Show user profile)
    // ===================
    case 'profile':
      const who = text ? (text.replace(/[@ .+-]/g, '') + '@s.whatsapp.net') : (m.quoted ? m.quoted.sender : m.mentionedJid?.[0] ? m.mentionedJid[0] : m.sender);

      try {
        const user = database.data.users[who];
        if (!user) return m.reply(`[!] User tidak ada dalam database.`);

        // Fetch additional user data (level, exp, etc.)
        const { name, exp, level, pasangan, dateOfLovers } = user;
        const { min, xp, max } = xpRange(level, global.multiplier);

        // Check relationship status
        const pacar = pasangan ? `@${pasangan.split('@')[0]}` : '_Belum Memiliki Pasangan_';

        // Format date of lovers
        const dateLovers = dateOfLovers ? new Date(dateOfLovers).toLocaleDateString() : '_Belum Memiliki Pasangan_';

        // Construct profile response in the requested format
        let str = `*[ Lovers Profile]*\n\n`;
        str += `_${name}_ with ${pacar}\n\n`;
        str += `*Level :* ${level}\n`;
        str += `*EXP :* ${exp} (${exp - min} / ${xp})\n`;
        str += `*Date of lovers:* ${dateLovers}\n`;

        await conn.reply(m.chat, str, m);
      } catch (e) {
        console.log(e);
        m.reply(`[!] User tidak ada dalam database.`);
      }
      break;

    default:
      return conn.reply(m.chat, `Perintah tidak dikenal. Gunakan salah satu dari: *tembak*, *terima*, *putus*, atau *profile*.`, m);
  }
};

handler.help = ['lovers'];
handler.tags = ['group'];
handler.command = /^(lovers|jadian)$/i;
handler.group = true;
handler.limit = false;
handler.fail = null;

export default handler;
