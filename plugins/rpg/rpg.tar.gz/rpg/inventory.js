import { loadDatabase, database } from "../../lib/database.js";

let animalNames = ['chicken', 'cow', 'goat', 'rabbit', 'sheep', 'bear', 'pig', 'buffalo', 'griffin', 'eagle', 'thorne', 'zephyr', 'ocelot', 'faelen', 'arctic', 'cheetah', 'koala', 'leopard', 'horse', 'fox'];
let coinNames = ['bitcoin', 'polygon', 'dogecoin', 'ethereum', 'solana', 'picoin', 'sidrachain', 'notcoin'];

let handler = async (m, { conn, args, command, usedPrefix }) => {
  await loadDatabase();  // Load the database

  let users = database.data.users;  // Access the users data via database
  let user = users[m.sender] || {};

  const subcommand = args[0] ? args[0].toLowerCase() : '';

  switch (subcommand) {
    case 'stats':
      return m.reply(
        `📊 *[User Stats]* 📊\n\n` +
        `- Health: *${user.health || 0} / ${user.MAXhealth || 0}*\n` +
        `- Stamina: *${user.stamina || 0} / ${user.MAXstamina || 0}*\n` +
        `- Limit: *${user.limit || 0}*\n\n` +
        `_Periksa status kesehatan dan stamina Anda secara berkala!_`
      );

    case 'item':
      return m.reply(
        `📦 *[Inventory Others]* 📦\n\n` +
        `- Vrpass: *${user.vrpass || 0}*\n` +
        `- Spin Tiket: *${user.spintiket || 0}*\n` +
        `- Minyak: *${user.minyak || 0}*\n` +
        `- Bumbu: *${user.bumbu || 0}*\n\n` +
        `_Pastikan untuk selalu memiliki persediaan yang cukup!_`
      );

    case 'chest':
      return m.reply(
        `💎 *[Inventory Kotak Harta]* 💎\n\n` +
        `- Common: *${user.common || 0}*\n` +
        `- Uncommon: *${user.uncommon || 0}*\n` +
        `- Mythic: *${user.mythic || 0}*\n` +
        `- Legendary: *${user.legendary || 0}*\n\n` +
        `_Kotak harta yang siap dibuka kapan saja!_`
      );

    case 'backpack':
      return m.reply(
        `🎒 *[Inventory Nambang]* 🎒\n\n` +
        `- Diamond: *${user.diamond || 0}*\n` +
        `- Gold: *${user.gold || 0}*\n` +
        `- Emerald: *${user.emerald || 0}*\n` +
        `- Potion: *${user.potion || 0}*\n` +
        `- Trash: *${user.trash || 0}*\n` +
        `- Wood: *${user.wood || 0}*\n` +
        `- Iron: *${user.iron || 0}*\n` +
        `- Rock: *${user.rock || 0}*\n` +
        `- String: *${user.string || 0}*\n` +
        `- Coal: *${user.coal || 0}*\n` +
        `- Steel: *${user.steel || 0}*\n\n` +
        `_Barang tambangmu siap digunakan untuk kerajinan!_`
      );

    case 'kandang':
      let kandangMessage = `🐾 *[Inventory Kandang]* 🐾\n\n`;
      animalNames.forEach(animal => {
        kandangMessage += `- ${capitalizeFirstLetter(animal)}: *${user[animal] || 0}*\n`;
      });
      kandangMessage += `\n_Hewan peliharaanmu menunggu untuk diberi makan!_`;
      return m.reply(kandangMessage);

    case 'coin':
      let coinMessage = `💰 *[Inventory Coin]* 💰\n\n`;
      coinNames.forEach(coin => {
        coinMessage += `- ${capitalizeFirstLetter(coin)}: *${user[coin] || 0}*\n`;
      });
      coinMessage += `\n_Tukar atau gunakan koinmu untuk membeli item spesial!_`;
      return m.reply(coinMessage);

    default:
      return m.reply(
        `🎒 *[Inventory ${user.name || 'Unknown'}]* 🎒\n\nGunakan salah satu perintah berikut:\n\n` +
        `- *${usedPrefix}inv stats*\n` +
        `- *${usedPrefix}inv item*\n` +
        `- *${usedPrefix}inv chest*\n` +
        `- *${usedPrefix}inv backpack*\n` +
        `- *${usedPrefix}inv kandang*\n` +
        `- *${usedPrefix}inv coin*\n\n` +
        `_Kelola dan periksa barang-barangmu dengan mudah!_`
      );
  }
};

// Function to capitalize the first letter
function capitalizeFirstLetter(string) {
  return string.charAt(0).toUpperCase() + string.slice(1);
}

handler.help = ['inv <perintah>'];
handler.tags = ['rpg'];
handler.command = /^(inv|inventory)$/i;
handler.group = true;

export default handler;