/* import necessary modules
import fs from 'fs'
import path from 'path'
import { fileURLToPath } from 'url'
import db from '../../lib/database.js'

// Mendapatkan direktori saat ini dalam modul ESM
const __filename = fileURLToPath(import.meta.url)
const __dirname = path.dirname(__filename)

// Fungsi untuk mendapatkan data petualangan dari JSON
const getAdventureData = () => {
    const filePath = path.join('/home/container/plugins/rpg', '_adventureData.json')
    const rawData = fs.readFileSync(filePath)
    return JSON.parse(rawData)
}

// Random number generator function
const ranNumb = (min, max) => Math.floor(Math.random() * (max - min + 1)) + min

const cooldown = 24 * 60 * 60 * 1000 // 24 jam dalam milidetik
const adventureDelaySuccess = 10 * 60 * 1000 // 10 menit dalam milidetik untuk keberhasilan
const adventureDelayFail = 5 * 60 * 1000 // 5 menit dalam milidetik untuk kegagalan

// Daftar URL gambar
const imageUrls = [
    'https://i.ibb.co/Gvq1wp6/calm-of-nature-by-xmrfel-dfwy2rd-pre.jpg',
    'https://telegra.ph/file/299eec6f5bbf73cd534ac.jpg',
    'https://telegra.ph/file/27d03878764b7384daae6.png',
    'https://telegra.ph/file/ace8c960d3f7c6f128cbf.jpg',
    'https://telegra.ph/file/f8ff0f04249434862bd83.jpg'
]

let handler = async (m, { usedPrefix, command, conn }) => {
    let user = db.data.users[m.sender]
    let timers = (cooldown - (new Date - user.lastadventure))

    if (user.health < 80) return m.reply(`🚑 Kamu membutuhkan setidaknya *❤️ 80 Health* untuk pergi ${command}!!\n\nKetik *${usedPrefix}heal* untuk memulihkan health.\nAtau *${usedPrefix}use potion* untuk menggunakan potion.`)
    if (new Date - user.lastadventure <= cooldown) return m.reply(`⏳ Kamu sudah pergi berpetualang, tunggu\n*🕐${new Date(timers).toTimeString()}*`)
    if (user.onAdventure) return m.reply(`⚠️ Kamu sedang dalam petualangan. Tunggu petualangan saat ini selesai.`)

    user.onAdventure = true
    user.adventurecount += 1

    // Mengambil data petualangan dari JSON
    const adventureData = getAdventureData()

    // Filter petualangan berdasarkan skill pengguna
    const filteredAdventures = adventureData.filter(adventure => adventure.skill === user.skill)
    if (filteredAdventures.length === 0) {
        user.onAdventure = false
        return m.reply(`⚠️ Select your skill first by .pilihskill`)
    }

    const selectedAdventure = filteredAdventures[Math.floor(Math.random() * filteredAdventures.length)]

    // Kirim pesan persiapan petualangan
    m.reply(`Bersiap-siaplah, kamu akan segera melakukan petualangan ke kota ${selectedAdventure.City} untuk mencari ${selectedAdventure.quest}.`)

    // Set delay untuk menyelesaikan petualangan
    setTimeout(() => {
        const isSuccess = Math.random() >= 0.3 // 70% berhasil, 30% gagal
        const delay = isSuccess ? adventureDelaySuccess : adventureDelayFail

        setTimeout(() => {
            if (!isSuccess) {
                user.health -= 98
                user.stamina = Math.max(0, user.stamina - 98)
                user.onAdventure = false
                user.lastadventure = new Date * 1

                return m.reply(`Wahai pejuang apakah kamu tidak apa apa? kami menemukan mu terbaring lemah saat menjalani petualangan ke ${selectedAdventure.City} seperti nya hari ini kamu tak bisa melakukan petualangan lagi sembuhkan dulu diri mu pejuang`)
            }

            // Menghitung sisa health dan stamina setelah petualangan
            const remainingHealth = user.health - parseInt(selectedAdventure.hp)
            const remainingStamina = 100 - parseInt(selectedAdventure.stamina)  // Asumsikan stamina maksimum adalah 100

            user.health -= parseInt(selectedAdventure.hp)
            user.stamina = remainingStamina

            // Random yen reward between 60k and 200k
            const yenReward = ranNumb(60000, 200000)
            user.yen += yenReward

            user.exp += parseInt(selectedAdventure.exp)
            user.lastadventure = new Date * 1
            user.onAdventure = false

            // Pemberian barang lain seperti sampah, batu, kayu, string, common item, dll.
            const trash = ranNumb(10, 50)
            const rock = ranNumb(1, 4)
            const wood = ranNumb(1, 4)
            const string = ranNumb(1, 3)
            const common = ranNumb(1, 2)
            const gold = 1
            const emerald = 1
            const diamond = 1

            user.trash += trash
            user.rock += rock
            user.wood += wood
            user.string += string
            user.crystal += 3 // Add 3 crystals per adventure
            if (user.adventurecount % 25 === 0) user.common += common
            if (user.adventurecount % 50 === 0) user.gold += gold
            if (user.adventurecount % 150 === 0) user.emerald += emerald
            if (user.adventurecount % 400 === 0) user.diamond += diamond

            // Memilih gambar acak dari daftar URL gambar
            let gmbrt = imageUrls[Math.floor(Math.random() * imageUrls.length)]

            // Membangun teks respon
            let txt = `[ *Petualangan Selesai* ]\n\n`
            txt += `*Cerita:* ${selectedAdventure.story}\n\n`
            txt += `🗺️ Quest: *${selectedAdventure.quest}*\n`
            txt += `⚔️ Boss: *${selectedAdventure.Boss}*\n`
            txt += `🏙️ Kota: *${selectedAdventure.City}*\n`
            txt += `🩸 HP yang digunakan: -${selectedAdventure.hp}\n`
            txt += `⚡ Stamina yang digunakan: -${selectedAdventure.stamina}\n`
            txt += `💵 Yen: ${new Intl.NumberFormat('en-US').format(yenReward)}\n`
            txt += `✉️ Exp: ${selectedAdventure.exp}\n\n\n`
            txt += `\nKamu membawa pulang:\n`
            txt += `*🗑 Trash: ${trash}*\n`
            txt += `*🪨 Rock: ${rock}*\n`
            txt += `*🪵 Wood: ${wood}*\n`
            txt += `*🕸️ String: ${string}*\n`
            txt += `*🔮 Crystal: 3*\n` // Add crystal reward in the message
            if (user.adventurecount % 25 === 0) txt += `\n\n🎉 Bonus untuk ${user.adventurecount} petualangan\n*📦 Common: ${common}*`
            if (user.adventurecount % 50 === 0) txt += `\n\n🎉 Bonus untuk ${user.adventurecount} petualangan\n*👑 Gold: ${gold}*`
            if (user.adventurecount % 150 === 0) txt += `\n\n🎉 Bonus untuk ${user.adventurecount} petualangan\n*💚 Emerald: ${emerald}*`
            if (user.adventurecount % 400 === 0) txt += `\n\n🎉 Bonus untuk ${user.adventurecount} petualangan\n*💎 Diamond: ${diamond}*`

            // Mengirim gambar dengan teks
            conn.sendFile(m.chat, gmbrt, '', txt, m)
        }, delay)
    }, adventureDelaySuccess)
}

handler.menu = ['berpetualang']
handler.tags = ['rpg']
handler.command = /^(adventure|(ber)?petualang(ang)?)$/i
handler.register = true
handler.group = true
handler.cooldown = cooldown

export default handler

*/
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import db from '../../lib/database.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const getAdventureData = () => {
    const filePath = path.join('/home/container/plugins/rpg', '_adventureData.json');
    try {
        const rawData = fs.readFileSync(filePath);
        return JSON.parse(rawData);
    } catch (error) {
        console.error('Error reading adventure data:', error);
        return [];
    }
};

const ranNumb = (min, max) => Math.floor(Math.random() * (max - min + 1)) + min;
const cooldown = 24 * 60 * 60 * 1000; // 24 jam dalam milidetik
const adventureDelaySuccess = 5 * 60 * 1000; // 5 menit
const adventureDelayFail = 5 * 60 * 1000; // 5 menit

const imageUrls = [
    'https://telegra.ph/file/299eec6f5bbf73cd534ac.jpg',
    'https://telegra.ph/file/27d03878764b7384daae6.png',
    'https://telegra.ph/file/ace8c960d3f7c6f128cbf.jpg',
    'https://telegra.ph/file/f8ff0f04249434862bd83.jpg'
];

let handler = async (m, { usedPrefix, command, conn, text }) => {
    let user = db.data.users[m.sender];
    
    // Check if the user is requesting a reset
    if (text && text.trim() === '--reset all momok') {
        for (let key in db.data.users) {
            db.data.users[key].lastadventure = 0;
            db.data.users[key].onAdventure = false;
        }
        return m.reply('🚀 Semua cooldown dan status petualangan telah direset.');
    }

    if (user.health < 80) {
        return m.reply(`🚑 Kamu membutuhkan setidaknya *❤️ 80 Health* untuk pergi ${command}!\n\nKetik *${usedPrefix}heal* untuk memulihkan health.\nAtau *${usedPrefix}use potion* untuk menggunakan potion.`);
    }

    // Pengecekan cooldown yang benar
    let timePassed = new Date() - new Date(user.lastadventure || 0);
    let timeLeft = cooldown - timePassed;
    if (timePassed <= cooldown) {
        return m.reply(`⏳ Kamu sudah pergi berpetualang, tunggu\n*🕐 ${new Date(timeLeft).toISOString().substr(11, 8)}* lagi.`);
    }

    // Strict Adventure Stacking Prevention: Check if user is already on an adventure
    if (user.onAdventure) {
        return m.reply(`⚠️ Kamu sudah sedang dalam petualangan. Tunggu petualangan saat ini selesai.`);
    }

    user.onAdventure = true; // Set flag: user is currently on an adventure
    user.adventurecount += 1; // Increase the adventure count

    const adventureData = getAdventureData(); // Get adventure data
    const filteredAdventures = adventureData.filter(adventure => adventure.skill === user.skill);

    if (filteredAdventures.length === 0) {
        user.onAdventure = false; // Reset status adventure if no adventure data found
        return m.reply(`⚠️ Pilih keterampilanmu terlebih dahulu dengan menggunakan .pilihskill.`);
    }

    const selectedAdventure = filteredAdventures[Math.floor(Math.random() * filteredAdventures.length)];

    m.reply(`🌟 Bersiap-siaplah, kamu akan segera melakukan petualangan ke kota *${selectedAdventure.City}* untuk mencari *${selectedAdventure.quest}*.`);

    // Delay before completing the adventure
    setTimeout(() => {
        const isSuccess = Math.random() >= 0.3; // 70% success, 30% fail
        const delay = 5 * 60 * 1000; // 5 minutes delay

        setTimeout(() => {
            if (!isSuccess) {
                // Adventure failed
                user.health -= 98;
                user.stamina = Math.max(0, user.stamina - 98);
                user.onAdventure = false; // Reset status adventure after fail
                user.lastadventure = new Date(); // Update last adventure time

                return m.reply(`😩 Wahai pejuang, apakah kamu tidak apa-apa? Kami menemukanmu terbaring lemah setelah petualangan ke *${selectedAdventure.City}*! Sepertinya hari ini kamu tidak bisa berpetualang lagi. Sembuhkan dirimu terlebih dahulu!`);
            }

            // Adventure success: Update user's stats
            const remainingHealth = Math.max(0, user.health - parseInt(selectedAdventure.hp));
            const remainingStamina = Math.max(0, user.stamina - parseInt(selectedAdventure.stamina));

            user.health = remainingHealth;
            user.stamina = remainingStamina;
            user.yen += ranNumb(60000, 80000);
            user.exp += parseInt(selectedAdventure.exp);
            user.lastadventure = new Date(); // Update last adventure time
            user.onAdventure = false; // Reset status adventure after success

            // Add rewards with range max 15, min 4
            user.trash += ranNumb(4, 15);
            user.rock += ranNumb(4, 15);
            user.wood += ranNumb(4, 15);
            user.string += ranNumb(4, 15);
            user.common += user.adventurecount % 25 === 0 ? 1 : 0;
            user.gold += user.adventurecount % 50 === 0 ? 1 : 0;
            user.emerald += user.adventurecount % 150 === 0 ? 1 : 0;
            user.diamond += user.adventurecount % 400 === 0 ? 1 : 0;
            user.crystal += 3; // Add 3 crystals per adventure

            // Send message and image with adventure results
            let gmbrt = imageUrls[Math.floor(Math.random() * imageUrls.length)];
            let txt = `[ *Petualangan Selesai* ]\n\n`;
            txt += `*Cerita:* ${selectedAdventure.story}\n\n`;
            txt += `🗺️ Quest: *${selectedAdventure.quest}*\n`;
            txt += `⚔️ Boss: *${selectedAdventure.Boss}*\n`;
            txt += `🏙️ Kota: *${selectedAdventure.City}*\n`;
            txt += `🩸 HP yang digunakan: -${selectedAdventure.hp}\n`;
            txt += `⚡ Stamina yang digunakan: -${selectedAdventure.stamina}\n`;
            txt += `💵 Yen: ${new Intl.NumberFormat('en-US').format(user.yen)}\n`;
            txt += `✉️ Exp: ${selectedAdventure.exp}\n\n\n`;
            txt += `\nKamu membawa pulang:\n`;
            txt += `*🗑 Trash: ${user.trash}*\n`;
            txt += `*🪨 Rock: ${user.rock}*\n`;
            txt += `*🪵 Wood: ${user.wood}*\n`;
            txt += `*🕸️ String: ${user.string}*\n`;
            txt += `*🔮 Crystal: 3*\n`;
            if (user.adventurecount % 25 === 0) txt += `\n\n🎉 Bonus untuk ${user.adventurecount} petualangan\n*📦 Common: 1*`;
            if (user.adventurecount % 50 === 0) txt += `\n\n🎉 Bonus untuk ${user.adventurecount} petualangan\n*👑 Gold: 1*`;
            if (user.adventurecount % 150 === 0) txt += `\n\n🎉 Bonus untuk ${user.adventurecount} petualangan\n*💚 Emerald: 1*`;
            if (user.adventurecount % 400 === 0) txt += `\n\n🎉 Bonus untuk ${user.adventurecount} petualangan\n*💎 Diamond: 1*`;

            // Send image with text
            conn.sendFile(m.chat, gmbrt, '', txt, m);

        }, delay);
    }, adventureDelaySuccess);
};

handler.help = ['berpetualang', 'adventure'];
handler.tags = ['rpg'];
handler.command = /^(adventure|(ber)?petualang(ang)?)$/i;
handler.register = true;
handler.group = true;
handler.cooldown = cooldown;
handler.limit = true

export default handler;
