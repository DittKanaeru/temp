import db from '../../lib/database.js'

const repairData = {
  pickaxe: { cost: { diamond: 1, rock: 3, wood: 5, iron: 3 }, durability: 'pickaxedurability', itemName: 'Pickaxe' },
  sword: { cost: { diamond: 1, wood: 5, iron: 9 }, durability: 'sworddurability', itemName: 'Sword' },
  armor: { cost: { steel: 2, string: 4, iron: 6 }, durability: 'armordurability', itemName: 'Armor' },
  bow: { cost: { diamond: 3, wood: 15, string: 3, iron: 3 }, durability: 'bowdurability', itemName: 'Bow' },
  fishingrod: { cost: { diamond: 1, iron: 10, string: 4 }, durability: 'fishingroddurability', itemName: 'Fishing Rod' }
}

const handler = async (m, { conn, command, args }) => {
  const type = (args[0] || '').toLowerCase()
  const user = db.data.users[m.sender]
  const itemType = repairData[type]

  if (!itemType) {
    let repairList = 'Format: .repair [item]\nContoh: .repair armor\n\n*━━━[ REPAIR LIST ]━━━*\n\n'
    for (const [key, value] of Object.entries(repairData)) {
      repairList += ` - *${value.itemName.toUpperCase()}* =\n`
      for (const [resource, amount] of Object.entries(value.cost)) {
        repairList += `${resource.charAt(0).toUpperCase() + resource.slice(1)}: ${amount}, `
      }
      repairList = repairList.slice(0, -2) + '\n\n'
    }
    return conn.reply(m.chat, repairList, m)
  }

  try {
    const count = args[1] && args[1].length > 0 ? Math.min(99999999, Math.max(parseInt(args[1]), 1)) : 1
    const { cost, durability, itemName } = itemType

    if (user[durability] > 99) return m.reply(`${itemName} kamu tidak rusak.`)
    if (user[type] === 0) return m.reply(`Kamu tidak memiliki ${itemName}.`)

    for (const [resource, resourceCost] of Object.entries(cost)) {
      if (user[resource] < resourceCost * count) return m.reply(`Bahan untuk memperbaiki ${itemName} tidak cukup.`)
      user[resource] -= resourceCost * count
    }

    user[durability] = 100
    m.reply(`Sukses memperbaiki ${itemName}.`)
  } catch (err) {
    m.reply("Error\n\n\n" + err.stack)
  }
}

handler.menu =  ['repair']
handler.tags =  ['rpg']
handler.command = /^(repair)/i
handler.register = true

export default handler
