const Penjelajahan = {
    '1': {
        name: 'Frost Forest',
        waktu: '3d',
        hadiah: {
            rial: 20000,
            diamond: 2,
            common: 2,
            exp: 235
        }
    },
    '2': {
        name: 'Danguen',
        waktu: '7d',
        hadiah: {
            rial: 60000,
            emerald: 4,
            common: 6,
            rock: 46,
            exp: 1154
        }
    },
    '3': {
        name: 'Flame Peaks',
        waktu: '5d',
        hadiah: {
            rial: 35000,
            ruby: 3,
            uncommon: 4,
            exp: 892
        }
    },
    '4': {
        name: 'Shadowed Valley',
        waktu: '4d',
        hadiah: {
            rial: 28000,
            sapphire: 2,
            common: 3,
            exp: 736
        }
    },
    '5': {
        name: 'Misty Marsh',
        waktu: '6d',
        hadiah: {
            rial: 50000,
            topaz: 5,
            uncommon: 5,
            exp: 1345
        }
    },
    '6': {
        name: 'Thunder Canyon',
        waktu: '8d',
        hadiah: {
            rial: 70000,
            diamond: 3,
            sapphire: 3,
            emerald: 3,
            rare: 6,
            exp: 1689
        }
    },
    '7': {
        name: 'Celestial Summit',
        waktu: '9d',
        hadiah: {
            rial: 80000,
            diamond: 4,
            ruby: 4,
            topaz: 4,
            rare: 8,
            exp: 1975
        }
    },
    '8': {
        name: 'Haunted Hills',
        waktu: '5d',
        hadiah: {
            rial: 37000,
            sapphire: 3,
            uncommon: 4,
            rock: 50,
            exp: 927
        }
    },
    '9': {
        name: 'Sunken Ruins',
        waktu: '6d',
        hadiah: {
            rial: 55000,
            emerald: 5,
            rare: 5,
            exp: 1476
        }
    },
    '10': {
        name: 'Eldritch Forest',
        waktu: '7d',
        hadiah: {
            rial: 65000,
            diamond: 3,
            ruby: 3,
            rare: 7,
            exp: 1583
        }
    },
    '11': {
        name: 'Spectral Caves',
        waktu: '5d',
        hadiah: {
            rial: 40000,
            sapphire: 4,
            rare: 5,
            rock: 58,
            exp: 1098
        }
    },
    '12': {
        name: 'Ancient Temple',
        waktu: '8d',
        hadiah: {
            rial: 75000,
            diamond: 4,
            emerald: 4,
            rare: 9,
            exp: 1806
        }
    },
    '13': {
        name: 'Cursed Marshlands',
        waktu: '6d',
        hadiah: {
            rial: 53000,
            topaz: 6,
            rare: 6,
            exp: 1429
        }
    },
    '14': {
        name: 'Volcanic Crater',
        waktu: '9d',
        hadiah: {
            rial: 85000,
            ruby: 5,
            sapphire: 5,
            rare: 10,
            exp: 2107
        }
    },
    '15': {
        name: 'Forbidden Palace',
        waktu: '10d',
        hadiah: {
            rial: 90000,
            diamond: 5,
            topaz: 5,
            rare: 12,
            exp: 2356
        }
    },
    '16': {
        name: 'Ethereal Plains',
        waktu: '7d',
        hadiah: {
            rial: 68000,
            emerald: 6,
            rare: 7,
            exp: 1634
        }
    },
    '17': {
        name: 'Darkwood Forest',
        waktu: '6d',
        hadiah: {
            rial: 57000,
            ruby: 4,
            topaz: 4,
            rare: 6,
            exp: 1492
        }
    },
    '18': {
        name: 'Crystal Caverns',
        waktu: '8d',
        hadiah: {
            rial: 78000,
            sapphire: 6,
            diamond: 4,
            rare: 8,
            exp: 1854
        }
    },
    '19': {
        name: 'Lost City of Atlantis',
        waktu: '11d',
        hadiah: {
            rial: 95000,
            emerald: 7,
            diamond: 5,
            rare: 14,
            exp: 2578
        }
    },
    '20': {
        name: 'Goblin Stronghold',
        waktu: '6d',
        hadiah: {
            rial: 59000,
            ruby: 5,
            sapphire: 5,
            rare: 6,
            rock: 70,
            exp: 1675
        }
    },
    '21': {
        name: 'Sunken Graveyard',
        waktu: '9d',
        hadiah: {
            rial: 82000,
            topaz: 6,
            diamond: 5,
            rare: 10,
            exp: 1976
        }
    },
    '22': {
        name: 'Frozen Wasteland',
        waktu: '7d',
        hadiah: {
            rial: 70000,
            sapphire: 6,
            emerald: 5,
            rare: 8,
            rock: 64,
            exp: 1783
        }
    },
    '23': {
        name: 'Whispering Woods',
        waktu: '6d',
        hadiah: {
            rial: 61000,
            ruby: 5,
            topaz: 5,
            rare: 7,
            exp: 1576
        }
    },
    '24': {
        name: 'Mystic Mountains',
        waktu: '8d',
        hadiah: {
            rial: 79000,
            diamond: 6,
            sapphire: 6,
            rare: 9,
            exp: 2045
        }
    },
    '25': {
        name: 'Mencari jati diri',
        waktu: '10d',
        hadiah: {
            rial: 90000,
            emerald: 8,
            diamond: 6,
            rare: 13,
            exp: 2289
        }
    },
};

export default Penjelajahan;
