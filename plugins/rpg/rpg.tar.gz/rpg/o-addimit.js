/*import { database, loadDatabase } from '../../lib/database.js';

let handler = async (m, { conn, command, text, args }) => {
    await loadDatabase(); // Memuat database sebelum melakukan operasi

    if (!text && !args[0]) throw "Nomor atau tag pengguna harus disertakan!";
    let target;
    if (m.isGroup) {
      target = m.mentionedJid[0] ? m.mentionedJid[0] : args[0] + "@s.whatsapp.net";
    } else {
      target = m.sender;
      if (!args[0]) text = command;
    }
    let users = database.data.users;
    if (!(target in users)) throw "Pengguna tidak ditemukan dalam database!";
    let value = parseInt(text || args[1]);
    if (isNaN(value)) throw "Nilai harus berupa angka!";
    if (command.match(/give(limit|level|yen|exp|stamina|mana)$/i)) {
      let type = command.replace(/^give/i, "").toLowerCase();
      users[target][type] += value;
      conn.reply(
        m.chat,
        `Berhasil menambahkan ${type} sebesar ${value} untuk pengguna ini.`,
        m
      );
    } else {
      throw "Perintah tidak valid!";
    }
    database.write(); // Menyimpan perubahan ke dalam database
};

handler.help = ["give","take"];
handler.tags = ["owner"];
handler.command = /^give(limit|level|yen|exp|stamina|mana)$/i;
handler.premium = false;
handler.owner = true;

export default handler;
*/
import { database, loadDatabase } from '../../lib/database.js';

// Helper function to convert formatted values (e.g., 1k, 1jt, 1m) into numbers
const parseFormattedValue = (value) => {
    let suffix = value.slice(-1).toLowerCase();  // Get the last character (suffix)
    let num = parseFloat(value.slice(0, -1));    // Get the number part

    if (suffix === 'k') return num * 1000;      // 1k = 1,000
    if (suffix === 'm') return num * 1_000_000; // 1m = 1,000,000
    if (suffix === 'j') return num * 1_000_000; // 1jt (1 juta) = 1,000,000
    return parseFloat(value);                   // No suffix, return as is
};

let handler = async (m, { conn, command, text, args }) => {
    await loadDatabase(); // Load the database before performing operations

    if (!text && !args[0]) throw "Nomor atau tag pengguna harus disertakan!";
    let target;
    if (m.isGroup) {
        target = m.mentionedJid[0] ? m.mentionedJid[0] : args[0] + "@s.whatsapp.net";
    } else {
        target = m.sender;
        if (!args[0]) text = command;
    }
    
    let users = database.data.users;
    if (!(target in users)) throw "Pengguna tidak ditemukan dalam database!";

    let value = args[1] ? parseFormattedValue(args[1]) : parseFormattedValue(text);
    if (isNaN(value)) throw "Nilai harus berupa angka atau format yang benar seperti 1k, 1jt, 1m!";

    if (command.match(/give(limit|level|yen|exp|stamina|mana)$/i)) {
        let type = command.replace(/^give/i, "").toLowerCase();
        users[target][type] += value;  // Add the value
        conn.reply(
            m.chat,
            `Berhasil menambahkan ${type} sebesar ${value.toLocaleString()} untuk pengguna ini.`,
            m
        );
    } else if (command.match(/take(limit|level|yen|exp|stamina|mana)$/i)) {
        let type = command.replace(/^take/i, "").toLowerCase();
        if (users[target][type] - value < 0) {
            users[target][type] = 0;  // Prevent negative values
        } else {
            users[target][type] -= value;  // Subtract the value
        }
        conn.reply(
            m.chat,
            `Berhasil mengurangi ${type} sebesar ${value.toLocaleString()} dari pengguna ini.`,
            m
        );
    } else {
        throw "Perintah tidak valid!";
    }

    database.write(); // Save changes to the database
};

handler.help = ["give","take"];
handler.tags = ["owner"];
handler.command = /^(give|take)(limit|level|yen|exp|stamina|mana)$/i;
handler.premium = false;
handler.owner = true;

export default handler;
