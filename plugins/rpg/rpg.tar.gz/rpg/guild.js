// Guild System with Guild War Feature
import { loadDatabase, database } from "../../lib/database.js";
import moment from "moment-timezone";
import { canLevelUp, xpRange } from "../../lib/lepelan.js";
import canvafy from "canvafy";
import uploadImage from "../../lib/uploadImage.js";

const maxGuildMembers = 10;
const guildCreationCost = 50000;
const guildNameChangeCost = 30000;
const guildXpPerBoss = 200;
const minGuildXpForLevelUp = 10000;

let handler = async (m, { conn, args, command, usedPrefix }) => {
  await loadDatabase();

  let users = database.data.users;
  let guilds = database.data.guilds || {};
  let sender = m.sender;
  let user = users[sender];

  const validateGuildData = () => {
    if (!database.data.guilds) {
      database.data.guilds = {};
    }
    for (let userId of Object.keys(users)) {
      let userData = users[userId];
      if (userData.guild && typeof userData.guild === "string") {
        if (!database.data.guilds[userData.guild]) {
          userData.guild = null;
        }
      } else {
        userData.guild = null;
      }
    }
    for (let guildId of Object.keys(database.data.guilds)) {
      let guildData = database.data.guilds[guildId];
      guildData.level = guildData.level || 1;
      guildData.xp = guildData.xp || 0;
    }
  };

  validateGuildData();

  const levelUpGuild = async (guild) => {
    if (!canLevelUp(guild.level, guild.xp) || guild.xp < minGuildXpForLevelUp) {
      return false;
    }
    while (guild.xp >= minGuildXpForLevelUp) {
      guild.level += 1;
      guild.xp -= minGuildXpForLevelUp;
    }
    await database.write();
    return true;
  };

  const getTier = (level) => {
    if (level > 100) return "SS+";
    if (level > 45) return "A";
    if (level > 30) return "B";
    if (level > 10) return "C";
    return "D";
  };

  switch (args[0]) {
    case "create":
      if (!args[1]) {
        return m.reply(
          `🏰 *[Create Guild]* 🏰\n\nFormat: *.guild create NamaGuild*\n\n_Bersatu kita teguh, bercerai kita runtuh. Ayo bangun kerajaan impianmu!_\n\nBiaya pembuatan: ${guildCreationCost} yen`,
        );
      }

      if (user.guild) {
        return m.reply(
          `🔱 *[Guild Loyalty]* 🔱\n\nWahai *${user.name}*, engkau adalah pemimpin agung dari ${database.data.guilds[user.guild].name}. Kesetiaanmu tak tergoyahkan!\n\n_Pimpinlah dengan bijak, rawatlah persaudaraan, dan bawa guildmu menuju kejayaan!_`,
        );
      }

      if (user.yen < guildCreationCost) {
        return m.reply(
          `💰 *[Dana Tidak Cukup]* 💰\n\n_Wahai calon pemimpin, kumpulkan terlebih dahulu ${guildCreationCost} yen untuk mendirikan guildmu!_`,
        );
      }

      let guildName = args.slice(1).join(" ");
      if (guildName.length > 20) {
        return m.reply(
          `⚠️ *[Nama Terlalu Panjang]* ⚠️\n\nWahai calon pemimpin, pilih nama yang singkat namun berkesan. Maksimal 20 karakter untuk menorehkan legenda!`,
        );
      }

      let guildId = `guild_${Date.now()}`;
      let guild = {
        id: guildId,
        name: guildName,
        leader: m.sender,
        members: [m.sender],
        maxMembers: maxGuildMembers,
        requests: [],
        level: 1,
        xp: 0,
      };

      user.guild = guildId;
      database.data.guilds[guildId] = guild;
      user.yen -= guildCreationCost;

      await database.write();

      return m.reply(
        `🎉 *[Guild Terbentuk]* 🎉\n\nSelamat! \`${guildName}\` telah bangkit!\n\n👑 *Engkau kini menjadi pemimpin agung.*\n\n_Ukirlah sejarah, perluas wilayah, dan jadikan guildmu yang terhebat di seluruh negeri!_\n\nBiaya ${guildCreationCost} yen telah diambil dari kantongmu.`,
      );

    case "setname":
    case "changename":
      if (!user.guild) {
        return m.reply(
          `❌ *[Tanpa Guild]* ❌\n\n_Engkau belum tergabung dalam guild manapun. Bergabunglah atau dirikan guildmu sendiri!_`,
        );
      }

      let currentGuildForNameChange = guilds[user.guild];
      if (currentGuildForNameChange.leader !== m.sender) {
        return m.reply(
          `🚫 *[Bukan Pemimpin]* 🚫\n\n_Hanya sang pemimpin yang berhak mengubah nama guild. Hormati hierarki!_`,
        );
      }

      if (user.yen < guildNameChangeCost) {
        return m.reply(
          `💰 *[Dana Tidak Cukup]* 💰\n\n_Wahai pemimpin, kumpulkan terlebih dahulu ${guildNameChangeCost} yen untuk mengubah nama guildmu!_`,
        );
      }

      let newName = args.slice(1).join(" ");
      if (!newName) {
        return m.reply(
          `🏷️ *[Nama Baru]* 🏷️\n\nFormat: *${usedPrefix}guild setname <nama_baru>*\n\n_Pilih nama yang mencerminkan keagungan guildmu!_`,
        );
      }

      if (newName.length > 20) {
        return m.reply(
          `⚠️ *[Nama Terlalu Panjang]* ⚠️\n\nWahai pemimpin bijak, pilih nama yang singkat namun berkesan. Maksimal 20 karakter untuk menorehkan legenda baru!`,
        );
      }

      user.yen -= guildNameChangeCost;
      let oldName = currentGuildForNameChange.name;
      currentGuildForNameChange.name = newName;

      await database.write();

      return m.reply(
        `🎊 *[Perubahan Nama Guild]* 🎊\n\n_Dengan biaya ${guildNameChangeCost} yen, guildmu telah mengukir nama baru dalam sejarah!_\n\nNama Lama: ${oldName}\nNama Baru: ${newName}\n\n_Semoga nama baru ini membawa kemakmuran dan kejayaan!_`,
      );

    case "request":
      if (!args[1]) {
        return conn.reply(
          m.chat,
          `🙏 *[Permohonan Bergabung]* 🙏\n\n*Mention pemimpin guild yang ingin kau ikuti.*\n\n_Tunjukkan tekadmu untuk bergabung dengan guild impianmu!_`,
          m,
        );
      }

      let mention = m.mentionedJid && m.mentionedJid[0];
      if (!mention) {
        return conn.reply(
          m.chat,
          `❓ *[Pemimpin Tidak Dikenal]* ❓\n\n*Mention pemimpin guild yang ingin kau ikuti.*\n\n_Pastikan kau mengenal baik pemimpin yang kau pilih!_`,
          m,
        );
      }

      let leader = users[mention];
      if (!leader || !leader.guild) {
        return conn.reply(
          m.chat,
          `🚫 *[Guild Tidak Ditemukan]* 🚫\n\n_Pemimpin yang kau pilih belum memiliki guild. Mungkin ini saatnya kau membuat guildmu sendiri?_`,
          m,
        );
      }

      let guildRequest = guilds[leader.guild];
      if (!guildRequest) {
        return conn.reply(
          m.chat,
          `🚫 *[Guild Tidak Ditemukan]* 🚫\n\n_Guild yang dimaksud tidak ditemukan. Mungkin telah dibubarkan atau terjadi kesalahan data._`,
          m,
        );
      }

      if (guildRequest.members.length >= guildRequest.maxMembers) {
        return conn.reply(
          m.chat,
          `😔 *[Guild Penuh]* 😔\n\n_Maaf, guild ini telah mencapai batas maksimal anggota. Mungkin takdirmu berada di guild lain yang lebih membutuhkanmu!_`,
          m,
        );
      }

      let request = {
        user: m.sender,
        reason: args[2] || "",
      };

      guildRequest.requests = guildRequest.requests || [];
      guildRequest.requests.push(request);

      await database.write();

      let leaderName = leader && leader.name ? leader.name : "pemimpin guild";

      return conn.reply(
        m.chat,
        `📨 *[Permohonan Terkirim]* 📨\n\n_Permohonan bergabungmu telah dikirim kepada ${leaderName}. Sabar ya, semoga diterima!_`,
        m,
      );

    case "accept":
      if (!user.guild) {
        return m.reply(
          `❌ *[Tanpa Guild]* ❌\n\n_Engkau belum tergabung dalam guild manapun. Bergabunglah atau dirikan guildmu sendiri!_`,
        );
      }

      let currentGuildForAccept = guilds[user.guild];
      if (currentGuildForAccept.leader !== m.sender) {
        return m.reply(
          `🚫 *[Bukan Pemimpin]* 🚫\n\n_Hanya sang pemimpin yang berhak menerima anggota baru. Hormati hierarki!_`,
        );
      }

      if (!args[1]) {
        return m.reply(
          `🤔 *[Permohonan Tidak Jelas]* 🤔\n\n_Format: ${usedPrefix}guild accept @mention*\n\n_Sebutkan anggota yang ingin kau terima._`,
        );
      }

      let acceptMention = m.mentionedJid && m.mentionedJid[0];
      if (!acceptMention) {
        return m.reply(
          `🤔 *[Permohonan Tidak Jelas]* 🤔\n\n_Format: ${usedPrefix}guild accept @mention*\n\n_Sebutkan anggota yang ingin kau terima._`,
        );
      }

      let requestIndex = currentGuildForAccept.requests.findIndex(
        (req) => req.user === acceptMention,
      );
      if (requestIndex === -1) {
        return m.reply(
          `❌ *[Permohonan Tidak Ditemukan]* ❌\n\n_Tidak ada permohonan dari pengguna tersebut._`,
        );
      }

      if (
        currentGuildForAccept.members.length >= currentGuildForAccept.maxMembers
      ) {
        return m.reply(
          `😔 *[Guild Penuh]* 😔\n\n_Maaf, guild ini telah mencapai batas maksimal anggota._`,
        );
      }

      currentGuildForAccept.members.push(acceptMention);
      currentGuildForAccept.requests.splice(requestIndex, 1);
      users[acceptMention].guild = user.guild;

      await database.write();

      return m.reply(
        `🎉 *[Anggota Baru]* 🎉\n\n_${users[acceptMention].name} telah diterima sebagai anggota guild._`,
      );

    case "reject":
      if (!user.guild) {
        return m.reply(
          `❌ *[Tanpa Guild]* ❌\n\n_Engkau belum tergabung dalam guild manapun. Bergabunglah atau dirikan guildmu sendiri!_`,
        );
      }

      let currentGuildForReject = guilds[user.guild];
      if (currentGuildForReject.leader !== m.sender) {
        return m.reply(
          `🚫 *[Bukan Pemimpin]* 🚫\n\n_Hanya sang pemimpin yang berhak menolak permohonan. Hormati hierarki!_`,
        );
      }

      if (!args[1]) {
        return m.reply(
          `🤔 *[Permohonan Tidak Jelas]* 🤔\n\n_Format: ${usedPrefix}guild reject @mention*\n\n_Sebutkan anggota yang ingin kau tolak._`,
        );
      }

      let rejectMention = m.mentionedJid && m.mentionedJid[0];
      if (!rejectMention) {
        return m.reply(
          `🤔 *[Permohonan Tidak Jelas]* 🤔\n\n_Format: ${usedPrefix}guild reject @mention*\n\n_Sebutkan anggota yang ingin kau tolak._`,
        );
      }

      let rejectIndex = currentGuildForReject.requests.findIndex(
        (req) => req.user === rejectMention,
      );
      if (rejectIndex === -1) {
        return m.reply(
          `❌ *[Permohonan Tidak Ditemukan]* ❌\n\n_Tidak ada permohonan dari pengguna tersebut._`,
        );
      }

      currentGuildForReject.requests.splice(rejectIndex, 1);

      await database.write();

      return m.reply(
        `❌ *[Permohonan Ditolak]* ❌\n\n_Permohonan dari ${users[rejectMention].name} telah ditolak._`,
      );

    case "promote":
      if (!user.guild) {
        return m.reply(
          `❌ *[Tanpa Guild]* ❌\n\n_Engkau belum tergabung dalam guild manapun. Bergabunglah atau dirikan guildmu sendiri!_`,
        );
      }

      let currentGuildForPromote = guilds[user.guild];
      if (currentGuildForPromote.leader !== m.sender) {
        return m.reply(
          `🚫 *[Bukan Pemimpin]* 🚫\n\n_Hanya sang pemimpin yang berhak mempromosikan anggota. Hormati hierarki!_`,
        );
      }

      if (!args[1]) {
        return m.reply(
          `🤔 *[Permohonan Tidak Jelas]* 🤔\n\n_Format: ${usedPrefix}guild promote @mention*\n\n_Sebutkan anggota yang ingin kau promosikan._`,
        );
      }

      let promoteMention = m.mentionedJid && m.mentionedJid[0];
      if (!promoteMention) {
        return m.reply(
          `🤔 *[Permohonan Tidak Jelas]* 🤔\n\n_Format: ${usedPrefix}guild promote @mention*\n\n_Sebutkan anggota yang ingin kau promosikan._`,
        );
      }

      if (!currentGuildForPromote.members.includes(promoteMention)) {
        return m.reply(
          `❌ *[Anggota Tidak Ditemukan]* ❌\n\n_Pengguna tersebut bukan anggota guild._`,
        );
      }

      if (promoteMention === m.sender) {
        return m.reply(
          `🤔 *[Permohonan Tidak Valid]* 🤔\n\n_Kau tidak bisa mempromosikan dirimu sendiri._`,
        );
      }

      currentGuildForPromote.leader = promoteMention;

      await database.write();

      return m.reply(
        `🎖️ *[Promosi Berhasil]* 🎖️\n\n_${users[promoteMention].name} telah dipromosikan menjadi pemimpin guild._`,
      );

    case "level":
      if (!user.guild) {
        return m.reply(
          `❌ *[Tanpa Guild]* ❌\n\n_Engkau belum tergabung dalam guild manapun. Bergabunglah atau dirikan guildmu sendiri!_`,
        );
      }

      let currentGuildForLevel = guilds[user.guild];
      let leveledUp = await levelUpGuild(currentGuildForLevel);

      return m.reply(
        `🔰 *[Level Guild]* 🔰\n\n_${currentGuildForLevel.name} sekarang berada di level ${currentGuildForLevel.level}. ${leveledUp ? "Selamat! Guildmu naik level!" : "Lanjutkan perjuangan untuk naik level berikutnya!"}_`,
      );

    case "list":
      let guildListMessage = "🛡️ *[Daftar Guild]* 🛡️\n\n";
      Object.values(guilds).forEach((guild) => {
        guildListMessage += `👑 *[ ${guild.name} ]* 👑\n`;
        guildListMessage += `Leader: ${users[guild.leader].name}\n`;
        guildListMessage += `Tier: [ ${getTier(guild.level)} ]✨\n\n`;
      });
      return m.reply(guildListMessage);

    case "info":
      if (!user.guild) {
        return m.reply(
          `❌ *[Tanpa Guild]* ❌\n\n_Engkau belum tergabung dalam guild manapun. Bergabunglah atau dirikan guildmu sendiri!_`,
        );
      }

      let currentGuildForInfo = guilds[user.guild];
      let guildInfoMessage = `🏰 *[Informasi Guild]* 🏰\n\n*Nama:* ${currentGuildForInfo.name}\n*Level:* ${currentGuildForInfo.level}\n*Tier:* ${getTier(currentGuildForInfo.level)}\n*Pemimpin:* ${users[currentGuildForInfo.leader].name}\n*Anggota:* ${currentGuildForInfo.members.length}/${currentGuildForInfo.maxMembers}\n\n*Daftar Anggota:*\n`;

      currentGuildForInfo.members.forEach((member) => {
        guildInfoMessage += `- ${users[member].name}\n`;
      });

      return m.reply(guildInfoMessage);

    // Function untuk mereset war guild setiap 5 jam sekali
setInterval(() => {
  Object.values(guilds).forEach((guild) => {
    guild.attackCount = 0;
    guild.lastWar = 0;
  });
  database.write();
}, 5 * 60 * 60 * 1000); // Setiap 5 jam

case "war":
  const today = moment.tz("Asia/Jakarta").day();
  if (today !== 6 && today !== 0) {
    return m.reply(
      `⚔️ *[Guild War]* ⚔️\n\n_Guild war hanya bisa dilakukan pada hari Sabtu dan Minggu. Harap kembali saat akhir pekan untuk bertempur!_`,
    );
  }

  if (!user.guild) {
    return m.reply(
      `❌ *[Tanpa Guild]* ❌\n\n_Engkau belum tergabung dalam guild manapun. Bergabunglah atau dirikan guildmu sendiri!_`,
    );
  }

  let userGuild = guilds[user.guild];
  const now = Date.now();

  if (!userGuild.lastWar) {
    userGuild.lastWar = 0;
    userGuild.attackCount = 0;
  }

  const timeSinceLastWar = now - userGuild.lastWar;

  if (userGuild.attackCount >= 3 && timeSinceLastWar < 24 * 60 * 60 * 1000) {
    const remainingTime = 24 * 60 * 60 * 1000 - timeSinceLastWar;
    const hours = Math.floor(remainingTime / (60 * 60 * 1000));
    const minutes = Math.floor((remainingTime % (60 * 60 * 1000)) / (60 * 1000));
    return m.reply(
      `⏳ *[Cooldown Aktif]* ⏳\n\n_Guildmu telah mencapai batas maksimum 3 serangan hari ini. Tunggu ${hours} jam ${minutes} menit sebelum dapat menyerang lagi._`,
    );
  }

  // Step 1: Searching for an opponent
  await m.reply(
    "🔍 *[Pencarian Lawan]* 🔍\n\n_Guildmu sedang mencari lawan...._",
  );
  await new Promise((resolve) =>
    setTimeout(resolve, Math.random() * (5000 - 3000) + 3000),
  );

  // Step 2: Opponent found
  await m.reply(
    "⚔️ *[Lawan Ditemukan]* ⚔️\n\n_Lawan guild ditemukan! Bersiaplah untuk bertarung!_",
  );
  await new Promise((resolve) =>
    setTimeout(resolve, Math.random() * (20000 - 9000) + 9000),
  );

  let otherGuilds = Object.keys(guilds).filter(
    (guildId) => guildId !== user.guild,
  );

  if (otherGuilds.length === 0) {
    return m.reply(
      `😔 *[Tidak Ada Lawan]* 😔\n\n_Tidak ada guild lain yang tersedia untuk bertarung._`,
    );
  }

  let opponentGuildId =
    otherGuilds[Math.floor(Math.random() * otherGuilds.length)];
  let opponentGuild = guilds[opponentGuildId];

  let userGuildLevel = userGuild.level;
  let opponentGuildLevel = opponentGuild.level;

  let userGuildMembers = userGuild.members.map(
    (memberId) => users[memberId].level || 1,
  );
  let opponentGuildMembers = opponentGuild.members.map(
    (memberId) => users[memberId].level || 1,
  );

  let userAverageLevel =
    userGuildMembers.reduce((sum, lvl) => sum + lvl, 0) /
    userGuildMembers.length;
  let opponentAverageLevel =
    opponentGuildMembers.reduce((sum, lvl) => sum + lvl, 0) /
    opponentGuildMembers.length;

  let baseWinChance = 0.5;
  let levelDifferenceFactor =
    (userAverageLevel - opponentAverageLevel) / 100;
  let finalWinChance = baseWinChance + levelDifferenceFactor;

  finalWinChance = Math.max(0.1, Math.min(0.9, finalWinChance));

  let battleResult = Math.random() < finalWinChance;
  let yenReward = Math.floor(
    Math.random() * (150000 - 80000) + 80000,
  );

  if (battleResult) {
    let rewardPerMember = Math.floor(yenReward / userGuild.members.length);
    userGuild.members.forEach((memberId) => {
      users[memberId].yen += rewardPerMember;
    });
    await m.reply(
      `🏆 *[Kemenangan Gemilang]* 🏆\n\n*Guild:* ${userGuild.name}\n*Lawan:* ${opponentGuild.name}\n\n📈 *Statistik Pertarungan:*\n- Level Guild: ${userGuildLevel} vs ${opponentGuildLevel}\n- Rata-Rata Level Anggota: ${userAverageLevel.toFixed(
        2,
      )} vs ${opponentAverageLevel.toFixed(
        2,
      )}\n\n🔥 *Hasil:* Guildmu memenangkan pertarungan dengan strategi dan kekuatan superior!\n\n🎁 *Hadiah:* +${yenReward} Yen (dibagi rata di antara anggota guild)\n\n_🎉 Selamat! Terus tingkatkan kekuatan guildmu!_`,
    );
  } else {
    await m.reply(
      `🥀 *[Kekalahan Terhormat]* 🥀\n\n*Guild:* ${userGuild.name}\n*Lawan:* ${opponentGuild.name}\n\n📉 *Statistik Pertarungan:*\n- Level Guild: ${userGuildLevel} vs ${opponentGuildLevel}\n- Rata-Rata Level Anggota: ${userAverageLevel.toFixed(
        2,
      )} vs ${opponentAverageLevel.toFixed(
        2,
      )}\n\n⚡ *Hasil:* Guildmu kalah dalam pertarungan yang sengit.\n\n💔 *Kerugian:* Tidak ada hadiah kali ini, tetapi guildmu akan kembali lebih kuat!_\n\n_💪 Jangan menyerah! Perkuat pasukanmu dan coba lagi!_`,
    );
  }

  userGuild.attackCount += 1;
  userGuild.lastWar = now;

  if (userGuild.attackCount >= 3) {
    await m.reply(
      `⏳ *[Cooldown Aktif]* ⏳\n\n_Guildmu telah mencapai batas maksimum 3 serangan hari ini. Tunggu 24 jam sebelum dapat menyerang lagi._`,
    );
  }

  await database.write();
  break;



    default:
      return m.reply(
        `🏰 *[Perintah Guild]* 🏰\n\nGunakan salah satu perintah berikut:\n\n- *${usedPrefix}guild create <nama_guild>*\n- *${usedPrefix}guild setname <nama_baru>*\n- *${usedPrefix}guild request @mention*\n- *${usedPrefix}guild accept @mention*\n- *${usedPrefix}guild reject @mention*\n- *${usedPrefix}guild promote @mention*\n- *${usedPrefix}guild level*\n- *${usedPrefix}guild list*\n- *${usedPrefix}guild info*\n- *${usedPrefix}guild war*\n\n_Bentuk, kelola, dan pimpin guildmu menuju kejayaan!_`,
      );
  }
};

handler.help = ["guild <perintah>"];
handler.tags = ["rpg"];
handler.command = /^(guild|g)$/i;
handler.group = true;
handler.register = true;

export default handler;

/*import { loadDatabase, database } from "../../lib/database.js";
import moment from "moment-timezone";
import { canLevelUp, xpRange } from "../../lib/lepelan.js";
import canvafy from "canvafy";
import uploadImage from "../../lib/uploadImage.js";

const maxGuildMembers = 10;
const guildCreationCost = 50000;
const guildNameChangeCost = 30000;
const guildXpPerBoss = 200;
const minGuildXpForLevelUp = 10000;

let handler = async (m, { conn, args, command, usedPrefix }) => {
  await loadDatabase();

  let users = database.data.users;
  let guilds = database.data.guilds || {}; // Initialize guilds if it doesn't exist
  let sender = m.sender;
  let user = users[sender];

  // Helper function to validate guild data
  const validateGuildData = () => {
    if (!database.data.guilds) {
      database.data.guilds = {};
    }
    for (let userId of Object.keys(users)) {
      let userData = users[userId];
      if (userData.guild && typeof userData.guild === "string") {
        if (!database.data.guilds[userData.guild]) {
          userData.guild = null; // Reset invalid guild data
        }
      } else {
        userData.guild = null; // Reset invalid guild data
      }
    }
    for (let guildId of Object.keys(database.data.guilds)) {
      let guildData = database.data.guilds[guildId];
      guildData.level = guildData.level || 1;
      guildData.xp = guildData.xp || 0;
    }
  };

  // Call validateGuildData to ensure data consistency
  validateGuildData();

  const levelUpGuild = async (guild) => {
    if (!canLevelUp(guild.level, guild.xp) || guild.xp < minGuildXpForLevelUp) {
      return false;
    }
    while (guild.xp >= minGuildXpForLevelUp) {
      guild.level += 1;
      guild.xp -= minGuildXpForLevelUp;
    }
    await database.write();
    return true;
  };

  const getTier = (level) => {
    if (level > 100) return "SS+";
    if (level > 45) return "A";
    if (level > 30) return "B";
    if (level > 10) return "C";
    return "D";
  };

  switch (args[0]) {
    case "create":
      if (!args[1]) {
        return m.reply(
          `🏰 *[Guild Creation]* 🏰 \n \nFormat: *.guild create NamaGuild*\n\n_Bersatu kita teguh, bercerai kita runtuh. Ayo bangun kerajaan impianmu!_ \n\n Biaya pembuatan: ${guildCreationCost} yen`,
        );
      }

      if (user.guild) {
        return m.reply(
          `🔱 *[Guild Loyalty]* 🔱 \n \n Wahai *${user.name}*, engkau adalah pemimpin agung dari ${database.data.guilds[user.guild].name}. Kesetiaanmu tak tergoyahkan! \n\n _Pimpinlah dengan bijak, rawatlah persaudaraan, dan bawa guildmu menuju kejayaan!_`,
        );
      }

      if (user.yen < guildCreationCost) {
        return m.reply(
          "💰 *[Dana Tidak Cukup]* 💰\n \n _Wahai calon pemimpin, kumpulkan terlebih dahulu " +
            guildCreationCost +
            " yen untuk mendirikan guildmu!_",
        );
      }

      let guildName = args.slice(1).join(" ");

      if (guildName.length > 20) {
        return m.reply(
          `⚠️ *[Nama Terlalu Panjang]* ⚠️\n\nWahai calon pemimpin, pilih nama yang singkat namun berkesan. Maksimal 20 karakter untuk menorehkan legenda!`,
        );
      }

      let guildId = `guild_${Date.now()}`; // Unique ID for the guild

      let guild = {
        id: guildId,
        name: guildName,
        leader: m.sender,
        members: [m.sender],
        maxMembers: maxGuildMembers,
        requests: [],
        level: 1,
        xp: 0,
      };

      user.guild = guildId;
      database.data.guilds[guildId] = guild;
      user.yen -= guildCreationCost;

      await database.write();

      return m.reply(
        `🎉 *[Guild Terbentuk]* 🎉\n\nSelamat! \`${guildName}\` telah bangkit!\n\n👑 *Engkau kini menjadi pemimpin agung.*\n\n_Ukirlah sejarah, perluas wilayah, dan jadikan guildmu yang terhebat di seluruh negeri!_\n\nBiaya ${guildCreationCost} yen telah diambil dari kantongmu.`,
      );

    case "setname":
    case "changename":
      if (!user.guild) {
        return m.reply(
          `❌ *[Tanpa Guild]* ❌\n\n_Engkau belum tergabung dalam guild manapun. Bergabunglah atau dirikan guildmu sendiri!_`,
        );
      }

      let currentGuildForNameChange = guilds[user.guild];
      if (currentGuildForNameChange.leader !== m.sender) {
        return m.reply(
          `🚫 *[Bukan Pemimpin]* 🚫\n\n_Hanya sang pemimpin yang berhak mengubah nama guild. Hormati hierarki!_`,
        );
      }

      if (user.yen < guildNameChangeCost) {
        return m.reply(
          `💰 *[Dana Tidak Cukup]* 💰\n\n_Wahai pemimpin, kumpulkan terlebih dahulu ${guildNameChangeCost} yen untuk mengubah nama guildmu!_`,
        );
      }

      let newName = args.slice(1).join(" ");
      if (!newName) {
        return m.reply(
          `🏷️ *[Nama Baru]* 🏷️\n\nFormat: *${usedPrefix}guild setname <nama_baru>*\n\n_Pilih nama yang mencerminkan keagungan guildmu!_`,
        );
      }

      if (newName.length > 20) {
        return m.reply(
          `⚠️ *[Nama Terlalu Panjang]* ⚠️\n\nWahai pemimpin bijak, pilih nama yang singkat namun berkesan. Maksimal 20 karakter untuk menorehkan legenda baru!`,
        );
      }

      user.yen -= guildNameChangeCost;
      let oldName = currentGuildForNameChange.name;
      currentGuildForNameChange.name = newName;

      await database.write();

      return m.reply(
        `🎊 *[Perubahan Nama Guild]* 🎊\n\n_Dengan biaya ${guildNameChangeCost} yen, guildmu telah mengukir nama baru dalam sejarah!_\n\nNama Lama: ${oldName}\nNama Baru: ${newName}\n\n_Semoga nama baru ini membawa kemakmuran dan kejayaan!_`,
      );

    case "request":
      if (!args[1]) {
        return conn.reply(
          m.chat,
          `🙏 *[Permohonan Bergabung]* 🙏\n\n*Mention pemimpin guild yang ingin kau ikuti.*\n\n_Tunjukkan tekadmu untuk bergabung dengan guild impianmu!_`,
          m,
        );
      }

      let mention = m.mentionedJid && m.mentionedJid[0];

      if (!mention) {
        return conn.reply(
          m.chat,
          `❓ *[Pemimpin Tidak Dikenal]* ❓\n\n*Mention pemimpin guild yang ingin kau ikuti.*\n\n_Pastikan kau mengenal baik pemimpin yang kau pilih!_`,
          m,
        );
      }

      let leader = users[mention];

      if (!leader || !leader.guild) {
        return conn.reply(
          m.chat,
          `🚫 *[Guild Tidak Ditemukan]* 🚫\n\n_Pemimpin yang kau pilih belum memiliki guild. Mungkin ini saatnya kau membuat guildmu sendiri?_`,
          m,
        );
      }

      let guildRequest = guilds[leader.guild];

      if (!guildRequest) {
        return conn.reply(
          m.chat,
          `🚫 *[Guild Tidak Ditemukan]* 🚫\n\n_Guild yang dimaksud tidak ditemukan. Mungkin telah dibubarkan atau terjadi kesalahan data._`,
          m,
        );
      }

      if (guildRequest.members.length >= guildRequest.maxMembers) {
        return conn.reply(
          m.chat,
          `😔 *[Guild Penuh]* 😔\n\n_Maaf, guild ini telah mencapai batas maksimal anggota. Mungkin takdirmu berada di guild lain yang lebih membutuhkanmu!_`,
          m,
        );
      }

      let request = {
        user: m.sender,
        reason: args[2] || "",
      };

      guildRequest.requests = guildRequest.requests || [];
      guildRequest.requests.push(request);

      await database.write();

      let leaderName = leader && leader.name ? leader.name : "pemimpin guild";

      return conn.reply(
        m.chat,
        `📨 *[Permohonan Terkirim]* 📨\n\n_Permohonan bergabungmu telah dikirim kepada ${leaderName}. Sabar ya, semoga diterima!_`,
        m,
      );

    case "accept":
      if (!user.guild) {
        return m.reply(
          `❌ *[Tanpa Guild]* ❌\n\n_Engkau belum tergabung dalam guild manapun. Bergabunglah atau dirikan guildmu sendiri!_`,
        );
      }

      let currentGuildForAccept = guilds[user.guild];
      if (currentGuildForAccept.leader !== m.sender) {
        return m.reply(
          `🚫 *[Bukan Pemimpin]* 🚫\n\n_Hanya sang pemimpin yang berhak menerima anggota baru. Hormati hierarki!_`,
        );
      }

      if (!args[1]) {
        return m.reply(
          `🤔 *[Permohonan Tidak Jelas]* 🤔\n\n_Format: ${usedPrefix}guild accept @mention*\n\n_Sebutkan anggota yang ingin kau terima._`,
        );
      }

      let acceptMention = m.mentionedJid && m.mentionedJid[0];
      if (!acceptMention) {
        return m.reply(
          `🤔 *[Permohonan Tidak Jelas]* 🤔\n\n_Format: ${usedPrefix}guild accept @mention*\n\n_Sebutkan anggota yang ingin kau terima._`,
        );
      }

      let requestIndex = currentGuildForAccept.requests.findIndex(
        (req) => req.user === acceptMention,
      );
      if (requestIndex === -1) {
        return m.reply(
          `❌ *[Permohonan Tidak Ditemukan]* ❌\n\n_Tidak ada permohonan dari pengguna tersebut._`,
        );
      }

      if (
        currentGuildForAccept.members.length >= currentGuildForAccept.maxMembers
      ) {
        return m.reply(
          `😔 *[Guild Penuh]* 😔\n\n_Maaf, guild ini telah mencapai batas maksimal anggota._`,
        );
      }

      currentGuildForAccept.members.push(acceptMention);
      currentGuildForAccept.requests.splice(requestIndex, 1);
      users[acceptMention].guild = user.guild;

      await database.write();

      return m.reply(
        `🎉 *[Anggota Baru]* 🎉\n\n_${users[acceptMention].name} telah diterima sebagai anggota guild._`,
      );

    case "reject":
      if (!user.guild) {
        return m.reply(
          `❌ *[Tanpa Guild]* ❌\n\n_Engkau belum tergabung dalam guild manapun. Bergabunglah atau dirikan guildmu sendiri!_`,
        );
      }

      let currentGuildForReject = guilds[user.guild];
      if (currentGuildForReject.leader !== m.sender) {
        return m.reply(
          `🚫 *[Bukan Pemimpin]* 🚫\n\n_Hanya sang pemimpin yang berhak menolak permohonan. Hormati hierarki!_`,
        );
      }

      if (!args[1]) {
        return m.reply(
          `🤔 *[Permohonan Tidak Jelas]* 🤔\n\n_Format: ${usedPrefix}guild reject @mention*\n\n_Sebutkan anggota yang ingin kau tolak._`,
        );
      }

      let rejectMention = m.mentionedJid && m.mentionedJid[0];
      if (!rejectMention) {
        return m.reply(
          `🤔 *[Permohonan Tidak Jelas]* 🤔\n\n_Format: ${usedPrefix}guild reject @mention*\n\n_Sebutkan anggota yang ingin kau tolak._`,
        );
      }

      let rejectIndex = currentGuildForReject.requests.findIndex(
        (req) => req.user === rejectMention,
      );
      if (rejectIndex === -1) {
        return m.reply(
          `❌ *[Permohonan Tidak Ditemukan]* ❌\n\n_Tidak ada permohonan dari pengguna tersebut._`,
        );
      }

      currentGuildForReject.requests.splice(rejectIndex, 1);

      await database.write();

      return m.reply(
        `❌ *[Permohonan Ditolak]* ❌\n\n_Permohonan dari ${users[rejectMention].name} telah ditolak._`,
      );

    case "promote":
      if (!user.guild) {
        return m.reply(
          `❌ *[Tanpa Guild]* ❌\n\n_Engkau belum tergabung dalam guild manapun. Bergabunglah atau dirikan guildmu sendiri!_`,
        );
      }

      let currentGuildForPromote = guilds[user.guild];
      if (currentGuildForPromote.leader !== m.sender) {
        return m.reply(
          `🚫 *[Bukan Pemimpin]* 🚫\n\n_Hanya sang pemimpin yang berhak mempromosikan anggota. Hormati hierarki!_`,
        );
      }

      if (!args[1]) {
        return m.reply(
          `🤔 *[Permohonan Tidak Jelas]* 🤔\n\n_Format: ${usedPrefix}guild promote @mention*\n\n_Sebutkan anggota yang ingin kau promosikan._`,
        );
      }

      let promoteMention = m.mentionedJid && m.mentionedJid[0];
      if (!promoteMention) {
        return m.reply(
          `🤔 *[Permohonan Tidak Jelas]* 🤔\n\n_Format: ${usedPrefix}guild promote @mention*\n\n_Sebutkan anggota yang ingin kau promosikan._`,
        );
      }

      if (!currentGuildForPromote.members.includes(promoteMention)) {
        return m.reply(
          `❌ *[Anggota Tidak Ditemukan]* ❌\n\n_Pengguna tersebut bukan anggota guild._`,
        );
      }

      if (promoteMention === m.sender) {
        return m.reply(
          `🤔 *[Permohonan Tidak Valid]* 🤔\n\n_Kau tidak bisa mempromosikan dirimu sendiri._`,
        );
      }

      currentGuildForPromote.leader = promoteMention;

      await database.write();

      return m.reply(
        `🎖️ *[Promosi Berhasil]* 🎖️\n\n_${users[promoteMention].name} telah dipromosikan menjadi pemimpin guild._`,
      );

    case "level":
      if (!user.guild) {
        return m.reply(
          `❌ *[Tanpa Guild]* ❌\n\n_Engkau belum tergabung dalam guild manapun. Bergabunglah atau dirikan guildmu sendiri!_`,
        );
      }

      let currentGuildForLevel = guilds[user.guild];
      let leveledUp = await levelUpGuild(currentGuildForLevel);

      return m.reply(
        `🔰 *[Level Guild]* 🔰\n\n_${currentGuildForLevel.name} sekarang berada di level ${currentGuildForLevel.level}. ${leveledUp ? "Selamat! Guildmu naik level!" : "Lanjutkan perjuangan untuk naik level berikutnya!"}_`,
      );

    case "list":
      let guildListMessage = "🛡️ *[Daftar Guild]* 🛡️\n\n";

      Object.values(guilds).forEach((guild) => {
        guildListMessage += `👑 *[ ${guild.name} ]* 👑\n`;
        guildListMessage += `Leader: ${users[guild.leader].name}\n`;
        guildListMessage += `Tier: [ ${getTier(guild.level)} ]✨\n\n`;
      });

      return m.reply(guildListMessage);
    case "info":
      if (!user.guild) {
        return m.reply(
          `❌ *[Tanpa Guild]* ❌\n\n_Engkau belum tergabung dalam guild manapun. Bergabunglah atau dirikan guildmu sendiri!_`,
        );
      }

      let currentGuildForInfo = guilds[user.guild];
      let guildInfoMessage = `🏰 *[Informasi Guild]* 🏰\n\n*Nama:* ${currentGuildForInfo.name}\n*Level:* ${currentGuildForInfo.level}\n*Tier:* ${getTier(currentGuildForInfo.level)}\n*Pemimpin:* ${users[currentGuildForInfo.leader].name}\n*Anggota:* ${currentGuildForInfo.members.length}/${currentGuildForInfo.maxMembers}\n\n*Daftar Anggota:*\n`;

      currentGuildForInfo.members.forEach((member) => {
        guildInfoMessage += `- ${users[member].name}\n`;
      });

      return m.reply(guildInfoMessage);

    default:
      return m.reply(
        `🏰 *[Perintah Guild]* 🏰\n\nGunakan salah satu perintah berikut:\n\n- *${usedPrefix}guild create <nama_guild>*\n- *${usedPrefix}guild setname <nama_baru>*\n- *${usedPrefix}guild request @mention*\n- *${usedPrefix}guild accept @mention*\n- *${usedPrefix}guild reject @mention*\n- *${usedPrefix}guild promote @mention*\n- *${usedPrefix}guild level*\n- *${usedPrefix}guild list*\n- *${usedPrefix}guild info*\n\n_Bentuk, kelola, dan pimpin guildmu menuju kejayaan!_`,
      );
  }
};

handler.help = ["guild <perintah>"];
handler.tags = ["rpg"];
handler.command = /^(guild|g)$/i;

export default handler;*/
