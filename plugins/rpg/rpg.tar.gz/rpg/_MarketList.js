const items = {
    limit: {
        buyPrice: 9000,
        sellPrice: null // Tidak bisa menjual limit
    },
    spintiket: {
        buyPrice: 1500000,
        sellPrice: null
    },
    potion: {
        buyPrice: 150000,
        sellPrice: 5000
    },
    trash: {
        buyPrice: 10,
        sellPrice: 5
    },
    wood: {
        buyPrice: 20000,
        sellPrice: 1000
    },
    rock: {
        buyPrice: 20000,
        sellPrice: 1000
    },
    string: {
        buyPrice: 60000,
        sellPrice: 30000
    },
    emerald: {
        buyPrice: 700000,
        sellPrice: 32000
    },
    diamond: {
        buyPrice: 500000,
        sellPrice: 23000
    },
    gold: {
        buyPrice: 350000,
        sellPrice: 12000
    },
    iron: {
        buyPrice: 150000,
        sellPrice: 6000
    },
    // Masak
    bumbu: {
        buyPrice: 5000,
        sellPrice: 150
    },
    minyak: {
        buyPrice: 12000,
        sellPrice: 400
    },
    coal: {
        buyPrice: 5000,
        sellPrice: 100
    }
};

export default items;
