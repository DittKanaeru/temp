// nyoman and Dixy

import crypto from "crypto";
import db from '../../lib/database.js';

const yen_first_time = 10000;
const yen_link_creator = 15000;
const yen_bonus = {
  5: 10000,
  10: 20000,
  20: 30000,
  50: 40000,
  100: 500000
};

let handler = async (m, { conn, usedPrefix, text }) => {
  let users = db.data.users;

  if (text) {
    if ("ref_count" in users[m.sender])
      throw "Tidak bisa menggunakan kode referal!";
    
    let link_creator = (Object.entries(users).find(
      ([, { ref_code }]) => ref_code === text.trim()
    ) || [])[0];
    
    if (!link_creator) throw "Kode referal tidak valid";

    let count = users[link_creator].ref_count++;
    let extra = yen_bonus[count] || 0;
    users[link_creator].yen += yen_link_creator + extra;
    users[m.sender].yen += yen_first_time;
    users[m.sender].ref_count = 0;

    await db.write();

    await m.reply(`
Selamat!
+${yen_first_time} yen
`.trim());

    await m.reply(`
Seseorang telah menggunakan kode referal kamu
+${yen_link_creator + extra} yen
`.trim(), link_creator);
  } else {
    let code = users[m.sender].ref_code ||
      new Array(11)
        .fill()
        .map(() =>
          [
            ..."0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz"
          ][crypto.randomInt(62)]
        )
        .join("");

    users[m.sender].ref_code = code;
    users[m.sender].ref_count = users[m.sender].ref_count || 0;

    let command_text = `${usedPrefix}ref ${code}`;
    let command_link = `wa.me/${
      conn.user.jid.split("@")[0]
    }?text=${encodeURIComponent(command_text)}`;
    let share_text = `
Dapatkan ${yen_first_time} yen untuk yang menggunakan link/kode referal dibawah ini

Referal Code: *${code}*

${command_link}
`.trim();

    await m.reply(`
Dapatkan ${yen_link_creator} yen untuk setiap pengguna baru yang menggunakan kode referal kamu
${users[m.sender].ref_count} orang telah menggunakan kode referal kamu

Kode referal kamu: ${code}

Bagikan link kepada teman: ${command_link}

atau kirim pesan kepada teman wa.me/?text=${encodeURIComponent(share_text)}

${Object.entries(yen_bonus)
  .map(([count, yen]) => `${count} Orang = Bonus ${yen} yen`)
  .join("\n")}
`.trim());

    await db.write();
  }
};

handler.help = ["ref"];
handler.tags = ["rpg"];
handler.command = ["ref"];
handler.register = true;

export default handler;
