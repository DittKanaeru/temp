import db from '../../lib/database.js'

const cooldown = 2400000 // 20 menit dalam milidetik

let handler = async (m) => {
    try {
        let user = db.data.users[m.sender]
        let __timers = (new Date - user.lastopm)
        let _timers = (2400000 - __timers)
        let timers = clockString(_timers)
        let dapat = getRandomInt(3000, 5000)
        let expget = getRandomInt(100, 200)
        
        if (user.lastopm && new Date - user.lastopm < cooldown) {
            let remainingTime = (cooldown - (new Date - user.lastopm)) / 1000
            return m.reply(`Tunggu ${remainingTime.toFixed(0)} detik lagi sebelum kamu bisa menggunakan perintah ini.`)
        }

        if (user.health > 89) {
            if (new Date - user.lastopm > 1800000) {
                setTimeout(() => {
                    m.reply(`@${m.sender.split('@')[0]} Sudah Mengamankan Anggota OPM ke ${user.opm}, Dan Mendapakatkan Gaji\n\n\`HASIL OPM HUNTER\`\nMoney: +${dapat}\nExp: +${expget}`)
                    user.yen += dapat;
                    user.exp += expget;
                }, 80000)

                setTimeout(() => {
                    m.reply(`@${m.sender.split('@')[0]} akan mengantar Anggota OPM ke tempat pengamanan untuk introgasi`)
                }, 60000)
                setTimeout(() => {
                    m.reply(`@${m.sender.split('@')[0]} Untungnya kamu handal dalam berlari hingga mereka kelelahan dan akhirnya tertangkap`)
                }, 42000)

                setTimeout(() => {
                    m.reply(`@${m.sender.split('@')[0]} Oh sial OPM tersebut hampir gagal ditangkap`)
                }, 35000)

                setTimeout(() => {
                    m.reply(`@${m.sender.split('@')[0]} Mendapatkan Anggota OPM, Dan Sekarang saatnya mengejar mereka`)
                }, 20000)

                setTimeout(() => {
                    m.reply(`@${m.sender.split('@')[0]} Sedang Mencari Anggota OPM.....`)
                    user.opm += 1
                }, 0)
                user.lastopm = new Date * 1

                // Mengurangi kesehatan pengguna setelah berhasil memburu OPM
                user.health -= 60;
            } else m.reply(`Kamu sudah lelah banget nyari mereka, Dan Kamu Butuh Istirahat Selama *${timers}*`)
        } else m.reply('Minimal 50 Stamina Untuk Bisa berburu OPM\nKamu Bisa Menggunakan Potion Dengan Cara *.makan*')
    } catch (e) {
        console.log(e)
        m.reply('Error')
    }
}
handler.menu =  ['huntingopm']
handler.tags =  ['rpg']
handler.command = /^(opm|huntingopm|huntopm)$/i
handler.register = true
handler.limit = 20
handler.group = true
handler.group = true
handler.cooldown = cooldown // Menambahkan cooldown

export default handler

function clockString(ms) {
    let h = Math.floor(ms / 3600000)
    let m = Math.floor(ms / 60000) % 60
    let s = Math.floor(ms / 1000) % 60
    console.log({ ms, h, m, s })
    return [h, m, s].map(v => v.toString().padStart(2, 0)).join(':')
}

function getRandomInt(min, max) {
    return Math.floor(Math.random() * (max - min + 1)) + min;
}
