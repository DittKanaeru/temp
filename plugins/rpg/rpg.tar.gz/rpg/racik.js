import db, { loadDatabase } from '../../lib/database.js'

const handler = async (m, { conn, args, usedPrefix, command }) => {
  await loadDatabase();

  let type = (args[0] || '').toLowerCase()

  const user = db.data.users[m.sender]
  if (!user) {
    return conn.reply(m.chat, `⚠️ *User not found in the database.*`, m)
  }

  // Ubah peluang keberhasilan berdasarkan role
  const isMage = user.skill === 'mage'
  const successRate = isMage ? 0.89 : 0.60

  // Ensure all required resources are initialized
  function initializeResources(resources) {
    Object.keys(resources).forEach(key => {
      if (user[key] == null) user[key] = 0;
    })
  }

  const hasSufficientResources = (resources) => {
    initializeResources(resources)
    return Object.keys(resources).every(key => user[key] >= resources[key])
  }

  const craftItem = (resources, itemType) => {
    initializeResources(resources)
    Object.keys(resources).forEach(key => {
      user[key] -= resources[key]
    })
    user[itemType] = (user[itemType] || 0) + 1
    user[`last${itemType}claim`] = new Date()
  }

  const resourcesNeeded = {
    potion: { nixie: 15, triton: 13, marlin: 12, coralin: 14 },
    neuron: { azure: 5, aqualis: 3, zeplyn: 2, tritonus: 4 },
    elixir: { gourami: 5, fish: 3, octopus: 2, squid: 4 }
  }

  const handleCrafting = (itemType, itemClaimKey) => {
    if (!hasSufficientResources(resourcesNeeded[itemType])) {
      return conn.reply(m.chat, `
🚫 *Sumber Daya Tidak Cukup!*
Pastikan kamu memiliki bahan-bahan berikut:
${itemType === 'potion' ? '🧪 *Potion*: 🐠 *Nixie* (15), 🐡 *Triton* (13), 🐟 *Marlin* (12), 🎣 *Coralin* (14)' : 
itemType === 'neuron' ? '🧠 *Neuron*: 🐬 *Azure* (5), 🦞 *Aqualis* (3), 🐟 *Zeplyn* (2), 🎣 *Tritonus* (4)' : 
'🧪 *Elixir*: 🦈 *Gourami* (5), 🐠 *Fish* (3), 🐙 *Octopus* (2), 🦑 *Squid* (4)'}`
      , m);
    }

    const lastClaim = user[itemClaimKey] || 0
    if (new Date() - lastClaim < 600000) {
      const remainingTime = clockString(600000 - (new Date() - lastClaim))
      return conn.reply(m.chat, `
⏳ *Cooldown Aktif*
Kamu baru saja meracik. Tunggu sebentar untuk meracik lagi.
Sisa waktu: ${remainingTime}`
      , m)
    }

    conn.reply(m.chat, `
🧙‍♂️ *Proses Meracik Dimulai*
🔮 Mengumpulkan bahan-bahan...
🧪 Mencampur ramuan...
✨ Mantra sedang diucapkan...
Mohon tunggu hasil racikan ${itemType}...`
    , m)

    setTimeout(() => {
      if (Math.random() < successRate) {
        craftItem(resourcesNeeded[itemType], itemType)
        let craftedMessage = `
🎉 *Peracikan Berhasil!*
Selamat! Kamu berhasil meracik ${itemType.toUpperCase()}!
📦 *Hasil*:
${itemType === 'potion' ? '🧪' : itemType === 'neuron' ? '🧠' : '🧪'} ${itemType.charAt(0).toUpperCase() + itemType.slice(1)}: +1
${isMage ? '✨ *Bonus Mage*: Peluang keberhasilan lebih tinggi!' : ''}
Gunakan ${itemType} dengan bijak!`
        .trim()
        conn.reply(m.chat, craftedMessage, m)
      } else {
        conn.reply(m.chat, `
😔 *Peracikan Gagal*
Sayang sekali, proses meracik ${itemType} tidak berhasil.
Jangan menyerah! Coba lagi nanti.`
        , m)
      }
    }, 6000) // Durasi crafting 6 detik
  }

  const resepPotion = `
🧪 *Potion*:
- 🐠 *Nixie* (15)
- 🐡 *Triton* (13)
- 🐟 *Marlin* (12)
- 🎣 *Coralin* (14)`

  const resepNeuron = `
🧠 *Neuron*:
- 🐬 *Azure* (5)
- 🦞 *Aqualis* (3)
~ 🐟 *Zeplyn* (2)
~ 🎣 *Tritonus* (4)`

  const resepElixir = `
🧪 *Elixir*:
~ 🦈 *Gourami* (5)
~ 🐠 *Fish* (3)
~ 🐙 *Octopus* (2)
~ 🦑 *Squid* (4)`

  switch (type) {
    case '':
      return conn.reply(m.chat, `
🧙‍♂️ *Selamat Datang di Laboratorium Alkemis!*
Apa yang ingin kamu racik hari ini?
  
1. 🧪 *Potion*
2. 🧠 *Neuron*
3. 🧪 *Elixir*

Ketik '${usedPrefix}${command} [jenis ramuan]' untuk memulai!
Atau ketik '${usedPrefix}${command} resep' untuk melihat resep.` 
      , m)
    
    case 'potion':
      handleCrafting('potion', 'lastpotionclaim')
      break
      
    case 'neuron':
      handleCrafting('neuron', 'lastneuronclaim')
      break
      
    case 'elixir':
      handleCrafting('elixir', 'lastelixirclaim')
      break

    case 'resep':
      return conn.reply(m.chat, `
📋 *Daftar Resep* 📋

${resepPotion.trim()}
    
${resepNeuron.trim()}
    
${resepElixir.trim()}
`
      , m)
      
    default:
      return conn.reply(m.chat, `
❓ *Ramuan Tidak Dikenal*
Penggunaan: ${usedPrefix + command} [potion | neuron | elixir | resep]
Contoh: *${usedPrefix + command} potion*
Pilih salah satu ramuan yang tersedia!`
      , m)
  }

  db.write()
}

handler.help = ['meracik [type]']
handler.tags = ['rpg']
handler.command = /^(meracik|racik)$/i
handler.limit = true
handler.register = true
handler.group = true

export default handler

function clockString(ms) {
  let h = Math.floor(ms / 3600000)
  let m = Math.floor(ms / 60000) % 60
  let s = Math.floor(ms / 1000) % 60
  return [h, m, s].map(v => v.toString().padStart(2, 0)).join(':')
}
