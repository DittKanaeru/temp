import db from '../../lib/database.js';
import { isNumber, ranNumb } from '../../lib/func.js';
import vr from '../../config.js';

// Data untuk hewan peliharaan dan crate tier
const pets = {
    ss: ['naga', 'dog'],        // SS tier pets
    s: ['snake', 'raccoon'],     // S tier pets
    a: ['axolotl', 'hamster'],   // A tier pets
    b: ['kucing']                // B tier pets
};

const petData = {
    naga: { hp: 120, stamina: 200, damage: '80-350', specialAbility: { name: 'Dragon Fury', description: 'Deals 40 bonus fire damage.' }},
    dog: { hp: 150, stamina: 200, damage: '50-350', specialAbility: { name: 'Berserker Rage', description: 'Increases damage by 50% when HP is below 50%.' }},
    snake: { hp: 100, stamina: 100, damage: '40-180', specialAbility: { name: 'Poison Bite', description: '25% chance to deal 5 poison damage for 3 turns.' }},
    raccoon: { hp: 80, stamina: 120, damage: '30-200', specialAbility: { name: 'Shadow Dodge', description: '40% chance to dodge an attack.' }},
    axolotl: { hp: 90, stamina: 120, damage: '30-250', specialAbility: { name: 'Water Heal', description: 'Heals 15% HP every 3 turns.' }},
    hamster: { hp: 50, stamina: 80, damage: '20-150', specialAbility: { name: 'Bounce Heal', description: '20% chance to heal 15 HP.' }},
    kucing: { hp: 80, stamina: 150, damage: '20-150', specialAbility: { name: 'Double Claw', description: '30% chance to attack twice.' }}
};

// Fungsi untuk menghitung damage acak
const getRandomDamage = (damageRange) => {
    const [min, max] = damageRange.split('-').map(Number);
    return Math.floor(Math.random() * (max - min + 1)) + min;
};

// Fungsi untuk mendapatkan hewan peliharaan acak dari crate
const getRandomPet = (tier) => {
    const petList = pets[tier] || [];
    const petName = petList[Math.floor(Math.random() * petList.length)];
    return { name: petName, ...petData[petName] };
};

// Fungsi untuk membuka crate
let openCrates = async (m, { args }) => {
    let user = db.data.users[m.sender];
    let type = (args[0] || '').toLowerCase();
    let total = Math.floor(isNumber(args[1]) ? Math.min(Math.max(parseInt(args[1]), 1), 100) : 1); // Limit 100 crate

    if (!['ss', 's', 'a', 'b'].includes(type)) {
        return m.reply(`Tipe crate tidak valid. Gunakan: SS, S, A, atau B.`);
    }

    if (user[type] < total) {
        return m.reply(`Kamu tidak memiliki cukup ${vr.rpg.emoticon(type)} ${type} crates.`);
    }

    let txt = `Kamu membuka *${total} ${vr.rpg.emoticon(type)} ${type} crates* dan menerima:\n`;
    let yenTotal = 0, expTotal = 0, trashTotal = 0, petTotal = 0, newPets = [];

    for (let i = 0; i < total; i++) {
        let yen = ranNumb(type === 'ss' ? 10000 : type === 's' ? 5000 : type === 'a' ? 2000 : 1000, type === 'ss' ? 20000 : type === 's' ? 10000 : type === 'a' ? 5000 : 2000);
        let exp = ranNumb(type === 'ss' ? 500 : type === 's' ? 300 : type === 'a' ? 200 : 100, type === 'ss' ? 100 : type === 's' ? 600 : type === 'a' ? 400 : 200);
        let trash = ranNumb(5, 30);
        let pet = getRandomPet(type);

        if (pet) {
            user.pets[pet.name] = { hp: pet.hp, stamina: pet.stamina, damage: pet.damage, level: 1, xp: 0, specialAbility: pet.specialAbility };
            newPets.push(pet.name);
            petTotal += 1;
        }

        user.yen += yen;
        user.exp += exp;
        user.trash += trash;

        yenTotal += yen;
        expTotal += exp;
        trashTotal += trash;
    }

    user[type] -= total; // Mengurangi jumlah crates

    // Ringkasan hadiahnya
    txt += `${vr.rpg.emoticon('yen')} ${yenTotal} yen\n`;
    txt += `${vr.rpg.emoticon('exp')} ${expTotal} exp\n`;
    txt += `${vr.rpg.emoticon('trash')} ${trashTotal} trash\n`;
    if (petTotal > 0) {
        txt += `Dan ${petTotal} hewan peliharaan: ${newPets.join(', ')}`;
    }

    m.reply(txt);
};

// Pet Fight: Pertarungan berbasis giliran
let petFight = async (m, { args }) => {
    let user1 = db.data.users[m.sender];
    let user2 = db.data.users[args[0]]; // Pemain kedua
    let user1Pet = user1.pets[args[1].toLowerCase()];
    let user2Pet = user2.pets[args[2].toLowerCase()];

    if (!user1Pet || !user2Pet) {
        return m.reply("Kedua pemain harus memiliki hewan peliharaan yang valid.");
    }

    m.reply(`Pertarungan Dimulai! \n${user1Pet.name} vs ${user2Pet.name}`);
    let turn = 1;

    while (user1Pet.hp > 0 && user2Pet.hp > 0) {
        const currentAttacker = (turn % 2 === 1) ? user1Pet : user2Pet;
        const currentDefender = (turn % 2 === 1) ? user2Pet : user1Pet;
        let damage = getRandomDamage(currentAttacker.damage);
        currentDefender.hp -= damage;

        let abilityMessage = currentAttacker.specialAbility.effect ? currentAttacker.specialAbility.effect(currentAttacker, currentDefender) : '';
        m.reply(`Giliran ${turn}: ${currentAttacker.name} menyerang ${currentDefender.name} untuk ${damage} damage!\nHP ${currentDefender.name}: ${currentDefender.hp}\n${abilityMessage}`);

        if (currentDefender.hp <= 0) {
            m.reply(`${currentDefender.name} KO! ${currentAttacker.name} menang!`);
            break;
        }

        turn++;
        await new Promise(resolve => setTimeout(resolve, 2000)); // Delay antar giliran
    }
};

// Pet Info: Menampilkan statistik dan kemampuan hewan peliharaan
let petInfo = async (m, { args }) => {
    let user = db.data.users[m.sender];
    let pet = user.pets[args[0].toLowerCase()];

    if (!pet) {
        return m.reply("Kamu tidak memiliki hewan peliharaan ini.");
    }

    let info = `🐾 Info Hewan Peliharaan: ${pet.name}\n`;
    info += `❤️ HP: ${pet.hp}\n`;
    info += `⚡ Stamina: ${pet.stamina}\n`;
    info += `💪 Damage: ${pet.damage}\n`;
    info += `🔰 Kemampuan Khusus: ${pet.specialAbility.name}\n${pet.specialAbility.description}`;
    m.reply(info);
};

// Menu perintah
const showMenu = () => {
    return `*🌟 Menu Hewan Peliharaan 🌟*\n\n` +
           `1. .pet open <tipe crate> <jumlah> - Buka crate untuk mendapatkan hewan peliharaan.\n` +
           `2. .pet fight <pemain> <hewan1> <hewan2> - Pertarungkan hewan peliharaan.\n` +
           `3. .pet info <hewan> - Tampilkan informasi hewan peliharaan.\n`;
};

// Handler untuk perintah .pet
const handler = async (m, { command, args }) => {
    switch (command) {
        case 'pet':
            if (args.length === 0) {
                m.reply(showMenu());
                return;
            }
            const action = args[0].toLowerCase();
            args.shift(); // Hapus perintah dari argumen
            switch (action) {
                case 'open':
                    await openCrates(m, { args });
                    break;
                case 'fight':
                    await petFight(m, { args });
                    break;
                case 'info':
                    await petInfo(m, { args });
                    break;
                default:
                    m.reply('Perintah tidak dikenali. Gunakan .pet untuk melihat menu.');
            }
            break;
        default:
            m.reply('Perintah tidak dikenali. Gunakan .pet untuk melihat menu.');
    }
};

// Pengaturan handler
handler.command = /^(pet)$/i;
handler.tags = ['rpg'];
handler.register = true;
handler.group = true;

export default handler;


/*import db from '../../lib/database.js';
import pets from './_PetShopList.js'; // Pet profile list
import { canLevelUp, xpRange } from '../../lib/lepelan.js'; // For leveling system

const petNameChangeCost = 1; // Cost in petvoucher to change pet name

const generatePetList = () => {
    let petList = '*🌟 Pet Adoption 🌟*\n\n> Example : .pet adopt (pet name)\n\n━━─┈ Pet List ┈─━━\n';
    for (const pet in pets) {
        petList += `${pets[pet].emoji} *${pet.charAt(0).toUpperCase() + pet.slice(1)}*\nType: ${pets[pet].skill}\n\n`;
    }
    return petList.trim();
};

const generateActionList = () => {
    return `*🌟 Pet Menu 🌟*\n\nOptions:\n \`.pet adopt <pet_name>\`\n \`.pet stats\`\n \`.pet detail <pet_name>\`\n \`.pet level <pet_name>\`\n \`.pet changename <pet_name> <new_name>\`\n \`.pet fight\``;
};

const handler = async (m, { conn, args }) => {
    const action = args[0]?.toLowerCase();
    const petName = args[1]?.toLowerCase();

    if (!action) {
        conn.reply(m.chat, generateActionList(), m);
        return;
    }

    switch (action) {
        case 'adopt':
            if (!petName) {
                conn.reply(m.chat, generatePetList(), m);
            } else {
                await adoptPet(m, conn, petName);
            }
            break;

        case 'stats':
            await showPetStats(m, conn);
            break;

        case 'detail':
            if (!petName) {
                conn.reply(m.chat, 'Harap berikan nama pet untuk melihat detail.\nExample: .pet detail kucing', m);
            } else {
                await showPetDetail(m, conn, petName);
            }
            break;

        case 'level':
            await petLevelUp(m, conn, petName);
            break;

        case 'changename':
            const user = db.data.users[m.sender];
            if (!petName || !user[petName]) {
                return m.reply(`❌ *[Tanpa Pet]* ❌\n\n_Engkau belum memiliki pet ini. Adopsi atau pilih pet yang benar!_`);
            }
            await changePetName(m, conn, petName, args.slice(2).join(" "));
            break;

        case 'fight':
            await petFight(m, conn);
            break;

        default:
            conn.reply(m.chat, 'Gunakan perintah yang valid seperti .pet (adopt/stats/detail/level/changename/fight)', m);
    }
};

// Function untuk mengadopsi pet
const adoptPet = async (m, conn, petName) => {
    const pet = pets[petName];
    const user = db.data.users[m.sender];

    if (!pet) {
        return conn.reply(m.chat, 'Pet tidak ditemukan. Coba cek list lagi!', m);
    }

    if (user[petName]) {
        return conn.reply(m.chat, `Kamu sudah memiliki ${petName}. Tidak bisa mengadopsi lagi.`, m);
    }

    if (user.yen < pet.buyPrice) {
        return conn.reply(m.chat, `Uangmu tidak cukup untuk mengadopsi ${petName}. Kamu butuh ${pet.buyPrice} yen.`, m);
    }

    user.yen -= pet.buyPrice;
    user[petName] = {
        hp: pet.hp,
        stamina: pet.stamina,
        damage: pet.damage,
        level: 1,
        xp: 0
    };

    conn.reply(m.chat, `Selamat! Kamu telah mengadopsi ${pets[petName].emoji} ${petName.charAt(0).toUpperCase() + petName.slice(1)} dengan harga ${pet.buyPrice} yen.`, m);
};

// Function untuk menampilkan stats pet pengguna
const showPetStats = async (m, conn) => {
    const user = db.data.users[m.sender];
    let message = '*🌟 Pet Stats 🌟*\n\n';

    const userPets = Object.keys(user).filter(pet => pets[pet]);

    if (userPets.length === 0) {
        return conn.reply(m.chat, 'Kamu belum mengadopsi pet apapun.', m);
    }

    userPets.forEach(petName => {
        const pet = user[petName];
        message += `🌟 *${pets[petName].emoji} ${petName.charAt(0).toUpperCase() + petName.slice(1)}*\n`;
        message += `❤️ HP: ${pet.hp}/${pets[petName].hp}\n`;
        message += `⚡ Stamina: ${pet.stamina}/${pets[petName].stamina}\n`;
        message += `💪 Damage: ${pet.damage}\n`;
        message += `🔰 Level: ${pet.level}\n`;
        message += `✨ XP: ${pet.xp}/200\n\n`;
    });

    conn.reply(m.chat, message.trim(), m);
};

// Function untuk menampilkan detail pet
const showPetDetail = async (m, conn, petName) => {
    const pet = pets[petName];

    if (!pet) {
        return conn.reply(m.chat, 'Pet tidak ditemukan. Coba cek list lagi!', m);
    }

    let message = `🌟 Detail ${pets[petName].emoji} *${petName.charAt(0).toUpperCase() + petName.slice(1)}* 🌟\n`;
    message += '━━━━━━━━━━━━━━━━━━━━━━\n';
    message += `❤️ HP: ${pet.hp}\n`;
    message += `💪 Damage: ${pet.damage}\n`;
    message += `⚡ Stamina: ${pet.stamina}\n`;
    message += `🛡️ Skill: ${pet.skill}\n`;

    conn.reply(m.chat, message.trim(), m);
};

// Function untuk menaikkan level pet
const petLevelUp = async (m, conn, petName) => {
    const user = db.data.users[m.sender];
    const pet = user[petName];

    if (!pet) {
        return m.reply(`❌ *[Tanpa Pet]* ❌\n\n_Engkau belum memiliki pet ini. Adopsi pet atau pilih yang benar!_`);
    }

    if (pet.xp < 200) {
        return m.reply(`🔰 *[Level Pet]* 🔰\n\n_${petName.charAt(0).toUpperCase() + petName.slice(1)} belum memiliki cukup XP. Kamu membutuhkan minimal 200 XP untuk naik level._`);
    }

    pet.level++;
    pet.xp -= 200;
    pet.hp += 50;
    pet.stamina += 50;

    await db.write();

    return m.reply(`🎉 *[Level Up]* 🎉\n\n_${petName.charAt(0).toUpperCase() + petName.slice(1)} telah naik ke level ${pet.level}!_`);
};

// Function untuk mengganti nama pet
const changePetName = async (m, conn, oldName, newName) => {
    const user = db.data.users[m.sender];

    if (!newName || newName.length > 20) {
        return m.reply('🏷️ Nama baru maksimal 20 karakter. Pilih nama yang lebih singkat!');
    }

    if (user.petvoucher < petNameChangeCost) {
        return m.reply(`💰 Kamu memerlukan ${petNameChangeCost} petvoucher untuk mengganti nama.`);
    }

    user.petvoucher -= petNameChangeCost;
    pets[oldName].name = newName;

    await db.write();
    conn.reply(m.chat, `🎊 Nama petmu berhasil diubah dari ${oldName} menjadi ${newName}!`);
};

// Function untuk pertarungan pet (gacha lawan secara acak)
const petFight = async (m, conn) => {
    const user = db.data.users[m.sender];

    // Pastikan pengguna memiliki setidaknya 1 pet
    const userPets = Object.keys(user).filter(pet => pets[pet]);
    if (userPets.length === 0) {
        return conn.reply(m.chat, 'Kamu belum mengadopsi pet apapun. Adopsi dulu sebelum bertarung.', m);
    }

    // Mencari lawan (bisa user lain atau bot)
    const opponentUser = findOpponent(); // Fungsi ini mencari lawan dari data pengguna
    if (!opponentUser) {
        return conn.reply(m.chat, 'Tidak ada lawan yang ditemukan saat ini!', m);
    }

    const opponentPetNames = Object.keys(opponentUser.pets); // Ambil nama pet lawan
    const opponentPetName = opponentPetNames[Math.floor(Math.random() * opponentPetNames.length)];
    const opponentPet = opponentUser.pets[opponentPetName];

    // Matching
    conn.reply(m.chat, `Mencari lawan untuk ${userPets[0]} mu...`, m);
    await new Promise(resolve => setTimeout(resolve, 2000 + Math.random() * 2000)); // 2-4 detik
    conn.reply(m.chat, `Musuh telah ditemukan!! Bersiap untuk melakukan pertarungan: ${opponentPet.emoji} ${opponentPetName}`, m);

    const turns = 3;  // Jumlah total giliran
    let fightMessage;

    for (let turn = 1; turn <= turns && userPets[0].hp > 0 && opponentPet.hp > 0; turn++) {
        // Serangan pengguna
        let userDamage = getRandomDamage(userPets[0].damage);
        opponentPet.hp -= userDamage;

        // Trigger special ability
        const specialUserMessage = userPets[0].specialAbility.effect(userPets[0], opponentPet);
        fightMessage = `**Turn ${turn}**\n🐾 *${conn.getName(m.sender)}'s ${userPets[0].name} menyerang!*\n❤️ Lawan terkena ${userDamage} damage! HP lawan tersisa: ${opponentPet.hp}`;
        if (specialUserMessage) {
            fightMessage += `\n${specialUserMessage}`;
        }

        conn.reply(m.chat, fightMessage, m);
        await new Promise(resolve => setTimeout(resolve, 2000)); // Delay

        if (opponentPet.hp <= 0) break;

        // Serangan lawan
        let opponentDamage = getRandomDamage(opponentPet.damage);
        userPets[0].hp -= opponentDamage;

        // Trigger special ability
        const specialOpponentMessage = opponentPet.specialAbility.effect(opponentPet, userPets[0]);
        fightMessage = `🐾 *Lawan: ${opponentPetName} menyerang balik!*\n❤️ ${conn.getName(m.sender)}'s ${userPets[0].name} terkena ${opponentDamage} damage! HP kamu tersisa: ${userPets[0].hp}`;
        if (specialOpponentMessage) {
            fightMessage += `\n${specialOpponentMessage}`;
        }

        conn.reply(m.chat, fightMessage, m);
        await new Promise(resolve => setTimeout(resolve, 2000)); // Delay
    }

    // Menentukan hasil pertarungan dengan 50:50 chance win-lose
    let resultMessage;
    const outcome = Math.random(); // Ini akan memberikan 50:50 chance

    if (userPets[0].hp > 0 && opponentPet.hp <= 0) {
        userPets[0].xp += 100; // Tambahkan XP untuk pet
        resultMessage = `✨ *${conn.getName(m.sender)}'s ${userPets[0].name} menang!* 🏆\nKamu mendapatkan 100 XP!`;
    } else if (userPets[0].hp <= 0 && opponentPet.hp > 0) {
        resultMessage = `💀 *Lawan: ${opponentPetName} menang!* 🏆\n❌ ${userPets[0].name} kehabisan HP!`;
    } else {
        if (outcome < 0.5) {
            resultMessage = `✨ *${conn.getName(m.sender)}'s ${userPets[0].name} menang!* 🏆\nKamu mendapatkan 100 XP!`;
        } else {
            resultMessage = `💀 *Lawan: ${opponentPetName} menang!* 🏆\n❌ ${userPets[0].name} kehabisan HP!`;
        }
    }

    return conn.reply(m.chat, resultMessage, m);
};

// Helper Function untuk mengacak damage berdasarkan rentang damage dari pet
const getRandomDamage = (damageRange) => {
    const [min, max] = damageRange.split('-').map(Number);
    return Math.floor(Math.random() * (max - min + 1)) + min;
};

handler.help = ['pet adopt', 'pet stats', 'pet fight']
handler.tags = ['rpg']
handler.command = /^(pet)$/i
export default handler;*/