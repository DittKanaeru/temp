const pets = {
    kucing: {
        buyPrice: 200000,
        hp: 80, // Menurunkan sedikit HP agar seimbang
        stamina: 150,
        damage: '20-150', // Rentang damage disesuaikan
        skill: 'claw striker',
        emoji: '🐈',
        specialAbility: {
            name: 'Double Claw',
            description: 'Peluang 30% untuk menyerang dua kali dalam satu giliran.',
            effect: (pet, opponentPet) => {
                if (Math.random() < 0.3) { // 30% chance to activate
                    let extraDamage = Math.floor(getRandomDamage(pet.damage) * 0.8); // Mengurangi damage tambahan sedikit
                    opponentPet.hp -= extraDamage;
                    return `✨ *Skill 'Double Claw' aktif!* Serangan kedua memberikan ${extraDamage} damage tambahan!`;
                }
                return '';
            }
        }
    },
    hamster: {
        buyPrice: 300000,
        hp: 50, // Meningkatkan sedikit HP agar bisa bertahan lebih lama
        stamina: 80,
        damage: '20-150', // Menurunkan damage max agar lebih adil
        skill: 'earth bounce',
        emoji: '🐹',
        specialAbility: {
            name: 'Bounce Heal',
            description: 'Peluang 20% untuk memulihkan 15 HP saat melompat.',
            effect: (pet, opponentPet) => {
                if (Math.random() < 0.2) { // 20% chance to heal
                    let heal = 15; // Mengurangi heal untuk keseimbangan
                    pet.hp += heal;
                    return `💧 *Skill 'Bounce Heal' aktif!* Hamster memulihkan ${heal} HP!`;
                }
                return '';
            }
        }
    },
    axolotl: {
        buyPrice: 350000,
        hp: 90,
        stamina: 120,
        damage: '30-250', // Menurunkan damage max
        skill: 'water splash',
        emoji: '🐬',
        specialAbility: {
            name: 'Water Heal',
            description: 'Memulihkan 15% dari HP setiap 3 putaran.',
            effect: (pet, opponentPet) => {
                let heal = Math.floor(pet.hp * 0.15); // Mengurangi heal menjadi 15% agar lebih seimbang
                pet.hp += heal;
                return `💧 *Skill 'Water Heal' aktif!* Axolotl memulihkan ${heal} HP!`;
            }
        }
    },
    snake: {
        buyPrice: 200000,
        hp: 100,
        stamina: 100,
        damage: '40-180', // Menurunkan damage max agar lebih adil
        skill: 'poison strike',
        emoji: '🐍',
        specialAbility: {
            name: 'Poison Bite',
            description: 'Peluang 25% untuk memberikan 5 damage berkelanjutan selama 3 putaran.',
            effect: (pet, opponentPet) => {
                if (Math.random() < 0.25) { // 25% chance for poison
                    let poisonDamage = 5; // Mengurangi poison damage menjadi 5 untuk lebih seimbang
                    opponentPet.hp -= poisonDamage;
                    return `🐍 *Skill 'Poison Bite' aktif!* Lawan terkena 5 poison damage selama 3 putaran!`;
                }
                return '';
            }
        }
    },
    dog: {
        buyPrice: 500000,
        hp: 150,
        stamina: 200,
        damage: '50-350', // Menurunkan damage max agar lebih seimbang
        skill: 'earth bite',
        emoji: '🐶',
        specialAbility: {
            name: 'Berserker Rage',
            description: 'Meningkatkan damage 50% saat HP di bawah 50%.',
            effect: (pet, opponentPet) => {
                if (pet.hp < (pet.maxHp * 0.5)) { // Mengaktifkan saat HP < 50%
                    let rageBonus = Math.floor(getRandomDamage(pet.damage) * 0.5);
                    return `🔥 *Skill 'Berserker Rage' aktif!* Damage meningkat ${rageBonus} poin tambahan!`;
                }
                return '';
            }
        }
    },
    raccoon: {
        buyPrice: 200000,
        hp: 80,
        stamina: 120,
        damage: '30-200', // Menurunkan damage max agar tidak terlalu besar
        skill: 'shadow dash',
        emoji: '🦝',
        specialAbility: {
            name: 'Shadow Dodge',
            description: 'Peluang 40% untuk menghindari serangan lawan.',
            effect: (pet, opponentPet) => {
                if (Math.random() < 0.4) { // Menurunkan chance dodge menjadi 40%
                    return `🦝 *Skill 'Shadow Dodge' aktif!* Serangan lawan gagal!`;
                }
                return '';
            }
        }
    },
    naga: {
        buyPrice: 800000,
        hp: 120,
        stamina: 200,
        damage: '80-350', // Menurunkan damage max agar lebih seimbang
        skill: 'fire breath',
        emoji: '🐲',
        specialAbility: {
            name: 'Dragon Fury',
            description: 'Menyerang dengan kekuatan api dan memberikan 40 damage tambahan.',
            effect: (pet, opponentPet) => {
                let bonusDamage = 40; // Menurunkan bonus damage
                opponentPet.hp -= bonusDamage;
                return `🔥 *Skill 'Dragon Fury' aktif!* Serangan memberikan ${bonusDamage} damage tambahan!`;
            }
        }
    }
}

export default pets;

// Helper Function untuk mengacak damage berdasarkan rentang damage dari pet
const getRandomDamage = (damageRange) => {
    const [min, max] = damageRange.split('-').map(Number);
    return Math.floor(Math.random() * (max - min + 1)) + min;
};
