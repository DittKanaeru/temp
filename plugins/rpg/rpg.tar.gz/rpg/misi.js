import db from '../../lib/database.js';
import fs from 'fs';
import { getWeek } from 'date-fns';  // Menambahkan date-fns untuk menangani getWeek

// Durasi cooldown dalam milidetik
const cooldown = 2700000; // 2700000 = 45 menit
const banDuration = 3600000; // 1 jam dalam milidetik
const maxListRequests = 50; // Maksimum permintaan misi list per pengguna

// Konfirmasi pengguna
const confirm = {};
const listRequests = {}; // Menyimpan jumlah permintaan misi list per pengguna

// Fungsi untuk memilih secara acak misi dari file misi.json
function randomPick(tier) {
  let missions;
  try {
    missions = JSON.parse(fs.readFileSync('/home/container/plugins/rpg/_misi.json', 'utf8'));
  } catch (error) {
    console.error('Error reading missions file:', error);
    return null;
  }
  
  const filteredMissions = missions.filter(mission => mission.tier === tier);
  if (filteredMissions.length === 0) return null;
  
  return filteredMissions[Math.floor(Math.random() * filteredMissions.length)];
}

// Fungsi untuk memilih misi spesial S tier dengan kemungkinan 2%
function specialMission() {
  let missions;
  try {
    missions = JSON.parse(fs.readFileSync('/home/container/plugins/rpg/_misi.json', 'utf8'));
  } catch (error) {
    console.error('Error reading missions file:', error);
    return null;
  }

  const specialMissions = missions.filter(mission => mission.tier === 'S');
  if (specialMissions.length === 0) return null;

  return specialMissions[Math.floor(Math.random() * specialMissions.length)];
}

async function handler(m, { conn, args }) {
  try {
    const player = db.data.users[m.sender];
    if (!player) return m.reply("Kamu belum terdaftar dalam game.");

    // Hapus status banned jika sudah lewat durasinya
    if (player.banned && (Date.now() - player.banned >= banDuration)) {
      delete player.banned;
    }

    if (player.banned) {
      const remainingTime = Math.ceil((banDuration - (Date.now() - player.banned)) / 1000);
      return m.reply(`Kamu telah dibanned karena melakukan spam. Tunggu ${remainingTime} detik lagi.`);
    }

    switch (args[0]) {
      case 'pilih':
        return handlePilih(m, conn, player, args[1]);
      case 'list':
        return handleList(m, conn, player);
      default:
        return m.reply(`
Hai survivor, apakah pada hari ini kamu ingin mengambil misi? Kamu bisa menggunakan opsi di bawah ini:

~ .misi pilih [A/B/C/S]
~ .misi list
        `.trim());
    }
  } catch (e) {
    console.error(e);
    m.reply("Terjadi kesalahan.");
  }
}

async function handlePilih(m, conn, player, missionKey) {
  if (!missionKey) {
    return m.reply("Gunakan .misi pilih <A/B/C/S> untuk memilih misi.");
  }

  if (!(m.sender in confirm)) {
    return m.reply("Kamu harus melihat daftar misi terlebih dahulu dengan menggunakan .misi list.");
  }

  const { missions, timeout } = confirm[m.sender];
  const mission = missions[missionKey.toUpperCase()];

  if (!mission) {
    return m.reply("Misi tidak ditemukan. Gunakan .misi list untuk melihat pilihan misi.");
  }

  clearTimeout(timeout);
  delete confirm[m.sender];

  if (player.health < 80) {
    return m.reply("Segera lakukan heal terlebih dahulu agar dapat melakukan hunting. Minimal 80 health untuk lanjut.");
  }

  if (player.stamina < 60) {
    return m.reply("Stamina tidak mencukupi. Minimal 60 stamina diperlukan untuk melanjutkan.");
  }

  if (player.level < mission.level) {
    return m.reply(`Level kamu tidak mencukupi untuk mengambil misi ini. Minimal level yang dibutuhkan adalah ${mission.level}.`);
  }

  player.lastmisi = Date.now();

  const isDead = Math.random() < 0.3;
  if (isDead) {
    let msg = `Misi Gagal

Pejuang Terhormat: @${m.sender.replace(/@.+/, '')}
Misi: ${mission.monsterName.toUpperCase()}

Pejuang, sayangnya kamu gagal dalam misi kali ini. Monster tersebut masih menjadi ancaman.

Detail Misi:
- Monster: ${mission.monsterName.toUpperCase()}
- Lokasi: ${mission.location.toUpperCase()}
- Area: Level ${mission.area}
- Level Minimal: ${mission.level}

Selamat beristirahat, dan semoga lebih berhasil dalam misi selanjutnya.

Tetaplah berhati-hati dalam menjelajah!
`;
    if (player.level > 0 && player.sworddurability > 0) {
      player.level -= 1;
      player.sworddurability -= 100;
      player.exp -= mission.exp;
    }
    player.health = 20;
    await conn.reply(m.chat, msg, m, { mentions: conn.parseMention(msg) });
    return true;
  }

  player.health -= mission.health;
  player.stamina -= mission.stamina;
  player.yen += mission.yen;
  player.exp += mission.exp;

  const pesan = `Selamat! Kamu telah berhasil menyelesaikan misi ${mission.monsterName.toUpperCase()}!

@${m.sender.replace(/@.+/, '')}, kamu telah mengalahkan monster tersebut!

Kami telah menyiapkan hadiah untukmu setelah menyelesaikan misi ini:
+${new Intl.NumberFormat('en-US').format(mission.yen)} Yen
+${new Intl.NumberFormat('en-US').format(mission.exp)} XP

Konsekuensi:
- Health: Tersisa ${player.health} Health
- Stamina: Tersisa ${player.stamina} Stamina`;

  await conn.reply(m.chat, pesan, m, { contextInfo: { mentionedJid: [m.sender] } });
  return true;
}

async function handleList(m, conn, player) {
  if (player.health < 80) {
    return m.reply("Segera lakukan heal terlebih dahulu agar dapat melakukan hunting. Minimal 80 health untuk lanjut.");
  }

  if (player.stamina < 60) {
    return m.reply("Stamina tidak mencukupi. Minimal 60 stamina diperlukan untuk melanjutkan.");
  }

  if (player.lastmisi && new Date() - player.lastmisi <= cooldown) {
    const timers = cooldown - (new Date() - player.lastmisi);
    return m.reply(`Kamu harus menunggu sebentar sebelum memulai misi berikutnya.\nWaktu yang tersisa: ${Math.ceil(timers / 1000)} detik`);
  }

  if (listRequests[m.sender] && listRequests[m.sender].count >= maxListRequests) {
    player.banned = Date.now();
    return m.reply("Kamu telah dibanned karena melakukan spam.");
  }

  if (confirm[m.sender]) {
    listRequests[m.sender].count += 1;
    return displayMissions(m, confirm[m.sender].missions);
  }

  const now = new Date();
  const lastWeek = new Date(player.lastSpecialMission || 0);
  const isSameWeek = now.getFullYear() === lastWeek.getFullYear() && getWeek(now) === getWeek(lastWeek);

  let specialMissionAvailable = false;
  if (!isSameWeek && Math.random() < 0.02) {
    specialMissionAvailable = true;
    player.lastSpecialMission = now;
  }

  const missions = {
    A: randomPick('A'),
    B: randomPick('B'),
    C: randomPick('C'),
    ...(specialMissionAvailable && { S: specialMission() })
  };

  if (!missions.A && !missions.B && !missions.C && !missions.S) {
    return m.reply("Tidak ada misi yang tersedia saat ini.");
  }

  confirm[m.sender] = {
    player,
    missions,
    timeout: setTimeout(() => {
      m.reply("Waktu Berakhir");
      delete confirm[m.sender];
    }, getRandomDelay()) // delay antara 15 hingga 20 menit
  };

  if (!listRequests[m.sender]) {
    listRequests[m.sender] = { count: 0, timestamp: Date.now() };
  }

  listRequests[m.sender].count += 1;

  return displayMissions(m, missions);
}

function displayMissions(m, missions) {
  const missionList = `
Quest yang tersedia pada hari ini:

*==================*

Tier: *A*
Monster: ${missions.A ? missions.A.monsterName.toUpperCase() : 'Tidak ada'}
Lokasi: ${missions.A ? missions.A.location.toUpperCase() : 'Tidak ada'}
Area: Level ${missions.A ? missions.A.area : 'Tidak ada'}
Pedang yang Dibutuhkan: ${missions.A ? missions.A.sword.toUpperCase() : 'Tidak ada'}
Level Minimal: ${missions.A ? missions.A.level : 'Tidak ada'}

\`\`\`Deskripsi: ${missions.A ? missions.A.description : 'Tidak ada'}\`\`\`
*==================*

Tier: *B*
Monster: ${missions.B ? missions.B.monsterName.toUpperCase() : 'Tidak ada'}
Lokasi: ${missions.B ? missions.B.location.toUpperCase() : 'Tidak ada'}
Area: Level ${missions.B ? missions.B.area : 'Tidak ada'}
Pedang yang Dibutuhkan: ${missions.B ? missions.B.sword.toUpperCase() : 'Tidak ada'}
Level Minimal: ${missions.B ? missions.B.level : 'Tidak ada'}

\`\`\`Deskripsi: ${missions.B ? missions.B.description : 'Tidak ada'}\`\`\`
*==================*

Tier: *C*
Monster: ${missions.C ? missions.C.monsterName.toUpperCase() : 'Tidak ada'}
Lokasi: ${missions.C ? missions.C.location.toUpperCase() : 'Tidak ada'}
Area: Level ${missions.C ? missions.C.area : 'Tidak ada'}
Pedang yang Dibutuhkan: ${missions.C ? missions.C.sword.toUpperCase() : 'Tidak ada'}
Level Minimal: ${missions.C ? missions.C.level : 'Tidak ada'}

\`\`\`Deskripsi: ${missions.C ? missions.C.description : 'Tidak ada'}\`\`\`
${missions.S ? `*==================*

Tier: *S*
Monster: ${missions.S.monsterName.toUpperCase()}
Lokasi: ${missions.S.location.toUpperCase()}
Area: Level ${missions.S.area}
Pedang yang Dibutuhkan: ${missions.S.sword.toUpperCase()}
Level Minimal: ${missions.S.level}

\`\`\`Deskripsi: ${missions.S.description}\`\`\`` : ''}
~ _End_
Tetap berhati-hati saat menjelajah, wahai pejuang. Kami selalu menunggumu!
  `.trim();

  return m.reply(missionList);
}

// Fungsi untuk mendapatkan delay acak antara 15 hingga 20 menit (dalam milidetik)
function getRandomDelay() {
  return Math.floor(Math.random() * (1200000)) + 900000; // antara 15 hingga 20 menit
}

handler.command = /^(misi)$/i;
handler.group = true;
handler.cooldown = cooldown;
handler.register = true;

export default handler;
