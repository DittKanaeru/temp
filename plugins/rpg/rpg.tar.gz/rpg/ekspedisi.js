import db from '../../lib/database.js'
import { ranNumb } from '../../lib/func.js'
import ms from 'ms'; 
import Penjelajahan from './_EkspedisiList.js'

function formatWaktu(milidetik) {
    return ms(milidetik, { long: true });
}

let handler = async (m, { conn, usedPrefix, command, args }) => {
    let user = db.data.users[m.sender]
    let now = Date.now()

    if (command == 'ekspedisi') {
        if (args[0] && args[0] in Penjelajahan) {
            let ekspedisi = Penjelajahan[args[0]]
            if (args[1] === 'info') {
                return conn.reply(m.chat, `
*${ekspedisi.name}*
Waktu: ${ms(ms(ekspedisi.waktu), { long: true })}
Hadiah: 
${Object.entries(ekspedisi.hadiah).map(([item, count]) => `${count} ${item}`).join('\n')}
                `, m)
            } else if (!user.lastekspedisi || user.lastekspedisi == 0) {
                let waktu = ms(ekspedisi.waktu); // Konversi waktu dari format '3d' ke milidetik
                user.lastekspedisi = now + waktu
                db.data.users[m.sender] = user
                conn.reply(m.chat, `Kamu akan melakukan ekspedisi di ${ekspedisi.name}, tunggu selama ${ms(waktu, { long: true })}`, m)
                setTimeout(() => {
                    conn.reply(m.sender, `Kamu berhasil melakukan ekspedisi ke ${ekspedisi.name} dengan hadiah:\n${Object.entries(ekspedisi.hadiah).map(([item, count]) => `${count} ${item}`).join('\n')}`, m)
                    // Tambahkan hadiah ke db user
                    for (let [item, count] of Object.entries(ekspedisi.hadiah)) {
                        if (item in user) user[item] += count
                        else user[item] = count
                    }
                    db.data.users[m.sender].lastekspedisi = 0
                }, waktu)
            } else {
                let time = user.lastekspedisi - now
                return conn.reply(m.chat, `Anda sudah melakukan ekspedisi sebelumnya, Anda tidak dapat melakukan ekspedisi yang lain sampai cooldown selesai, tunggu ${formatWaktu(time)} lagi`, m)
            }
        } else {
            let listEkspedisi = Object.entries(Penjelajahan).map(([id, ekspedisi]) => `${id}. ${ekspedisi.name}`).join('\n')
            return conn.sendMessage(m.chat, {
                text: `List Ekspedisi:\n${listEkspedisi}`,
                contextInfo: {
                    externalAdReply: {
                        title: `Ekspedisi Mingguan`,
                        body: `Name : ${user.registered ? user.name : conn.getName(m.sender)}`,
                        thumbnailUrl: 'https://i.ibb.co/9pskv9m/gutshot-square-by-deivcalviz-dc8bmht-min.jpg',
                        mediaType: 1,
                        renderLargerThumbnail: true
                    }
                }
            })
        }
    }
}

handler.menu =  ['ekspedisi'];
handler.tags =  ['rpg'];
handler.command = /^(ekspedisi)$/i;
handler.register = true;

export default handler;