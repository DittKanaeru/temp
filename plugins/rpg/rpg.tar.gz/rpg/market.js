import db from '../../lib/database.js';
import items from './_MarketList.js';

const generateItemList = () => {
    let itemList = '*♝ Market List ♝*:\n\n> Example : .market (buy/sell) (item) (jumlah)\n\n━─┈────────────┈─━\n';
    for (const item in items) {
        itemList += `♜ *${item.charAt(0).toUpperCase() + item.slice(1)}*\n`;
        itemList += `*Harga Beli:* ${items[item].buyPrice ? new Intl.NumberFormat('en-US').format(items[item].buyPrice) + ' yen' : '_Tidak bisa dibeli_'}\n`;
        itemList += `*Harga Jual:* ${items[item].sellPrice !== null ? new Intl.NumberFormat('en-US').format(items[item].sellPrice) + ' yen' : '_Tidak bisa dijual_'}\n\n`;
    }
    return itemList.trim();
};

const handler = async (m, { conn, command, args, usedPrefix }) => {
    const jualbeli = args[0]?.toLowerCase();
    const type = args[1]?.toLowerCase();
    const count = parseInt(args[2]);

    if (!jualbeli || !type || isNaN(count)) {
        conn.reply(m.chat, generateItemList(), m);
        return;
    }

    const item = items[type];

    try {
        if (!item) return conn.reply(m.chat, 'Item tidak valid.', m);

        if (count <= 0) return conn.reply(m.chat, 'Jumlah harus lebih dari 0.', m);  // Generalized check for both buy/sell

        switch (jualbeli) {
            case 'buy':
                if (!item.buyPrice) return conn.reply(m.chat, 'Item ini tidak bisa dibeli.', m);
                const totalBuyPrice = item.buyPrice * count;
                if (db.data.users[m.sender].yen < totalBuyPrice) return conn.reply(m.chat, 'Uang tidak cukup.', m);
                
                // Proceed with the purchase
                db.data.users[m.sender].yen -= totalBuyPrice;
                db.data.users[m.sender][type] = (db.data.users[m.sender][type] || 0) + count;
                conn.reply(m.chat, `Berhasil membeli ${count} ${type} dengan harga ${totalBuyPrice} yen.`, m);
                break;

            case 'sell':
                if (item.sellPrice === null) return conn.reply(m.chat, 'Item ini tidak bisa dijual.', m);
                if (db.data.users[m.sender][type] == null || db.data.users[m.sender][type] < count) {
                    return conn.reply(m.chat, `Anda tidak memiliki cukup ${type} untuk dijual.`, m);
                }

                const totalSellPrice = item.sellPrice * count;
                db.data.users[m.sender].yen += totalSellPrice;
                db.data.users[m.sender][type] -= count;

                conn.reply(m.chat, `Berhasil menjual ${count} ${type} dengan harga ${totalSellPrice} yen.`, m);
                break;

            default:
                conn.reply(m.chat, `Pilihan tindakan tidak valid. Gunakan ${usedPrefix}shop (buy/sell) <item> <jumlah>.`, m);
        }
    } catch (e) {
        conn.reply(m.chat, 'Terjadi kesalahan dalam eksekusi perintah.', m);
        console.error(e);
    }
};

handler.menu = ['market'];
handler.tags = ['rpg'];
handler.command = /^(market)$/i;
handler.register = true;
handler.group = true
export default handler;
