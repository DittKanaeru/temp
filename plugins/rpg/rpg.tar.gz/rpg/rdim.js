import db from '../../lib/database.js';

// Durasi cooldown dalam milidetik (1 tahun)
const cooldown = 31536000000;

let handler = async (m, { conn, args }) => {
    // Mendapatkan data pengguna dari database
    let user = db.data.users[m.sender];
    let now = Date.now();

    // Memeriksa apakah pengguna pernah menukarkan hadiah sebelumnya
    if (user.lastCodemt) {
        // Menghitung selisih waktu antara sekarang dan waktu terakhir menukarkan hadiah
        let timeDiff = now - user.lastCodemt;

        // Memeriksa apakah selisih waktu lebih kecil dari cooldown (satu tahun)
        if (timeDiff < cooldown) {
            // Jika masih dalam cooldown, kirim pesan bahwa pengguna sudah menukarkan hadiah sebelumnya
            let remainingTime = cooldown - timeDiff;
            let remainingTimeString = clockString(remainingTime);
            return conn.reply(m.chat, `Maaf, kamu sudah menukarkan hadiah sebelumnya. Tunggu sampai Maintenance selanjut nya`, m);
        }
    }

    // Lanjutkan dengan proses menukarkan hadiah jika pengguna tidak dalam cooldown
    if (args.length == 0)
        return conn.reply(m.chat, `Harap masukkan kode yang diberikan admin.`, m);

    // Memeriksa apakah kode yang dimasukkan pengguna benar
    let validCodes = ["Rk-Ruka", "Ak-mw"];
    if (!validCodes.includes(args[0])) {
        return conn.reply(m.chat, 'yang bener.', m);
    }

    // Tambahkan hadiah kepada pengguna
    conn.reply(
        m.chat,
        `*MAINTENANCE REWARD*\nTerima kasih telah menunggu, ini hadiahmu:\n- *Exp*: +8000\n- *Limit*: +120\n- *Potion*: +20\n- *Yen*: +300k`,
        m
    );

    // Update data pengguna
    user.exp += 8000;
    user.limit += 120;
    user.potion += 20;
    user.yen += 300000;
    user.lastCodemt = now; // Simpan timestamp terakhir kali menukarkan hadiah
};

handler.menu =  ["giftmt"];
handler.tags =  ["rpg"];
handler.command = /^(giftmt|hadiahmt|mt)$/i;
handler.register = true;

export default handler;

function clockString(ms) {
    let d = isNaN(ms) ? "--" : Math.floor(ms / 86400000);
    let h = isNaN(ms) ? "--" : Math.floor(ms / 3600000) % 24;
    let m = isNaN(ms) ? "--" : Math.floor(ms / 60000) % 60;
    let s = isNaN(ms) ? "--" : Math.floor(ms / 1000) % 60;
    return [
        d + " *Days*",
        h + " *Hours*",
        m + " *Minutes*",
        s + " *Seconds*"
    ].join(" ");
}
