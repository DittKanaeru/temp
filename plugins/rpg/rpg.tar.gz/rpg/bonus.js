/*import { database } from '../../lib/database.js'; // Mengimpor objek database dari file database.js

const handler = async (m, { conn }) => {
    let userData = database.data.users[m.sender];

    // Mengambil waktu terakhir bonus diberikan
    let lastBonusTime = userData.lastbonus || 0;
    // Mengambil waktu terakhir bonus limit diberikan
    let lastBonusLimitTime = userData.lastbonuslimit || 0;

    // Memeriksa apakah sudah lewat 24 jam sejak bonus terakhir diberikan
    if (new Date() - lastBonusTime < 86400000) {
        let remainingTime = lastBonusTime + 86400000 - new Date();
        throw `Kamu sudah ambil bonus hari ini. Tunggu ${msToTime(remainingTime)} lagi.`;
    }

    // Memeriksa apakah sudah lewat 24 jam sejak bonus limit terakhir diberikan
    if (new Date() - lastBonusLimitTime < 86400000) {
        let remainingTime = lastBonusLimitTime + 86400000 - new Date();
        throw `Kamu sudah ambil bonus limit hari ini. Tunggu ${msToTime(remainingTime)} lagi.`;
    }

    let limit = 80; // Mendefinisikan limit bonus
    let yen = 120000; // Menghasilkan jumlah bonus secara acak
    userData.yen += yen; // Menambahkan bonus ke saldo pengguna
    userData.lastbonus = new Date(); // Memperbarui waktu terakhir bonus diberikan
    userData.limit += limit; // Menambahkan limit bonus
    userData.lastbonuslimit = new Date(); // Memperbarui waktu terakhir bonus limit diberikan

    m.reply(`Makasih yah udah beli prem jadi ini ucapan kecil Selamat Kamu Mendapatkan Bonus : \n+${yen} yen dan ${limit}`);

    // Menyimpan perubahan ke database
    database.write();
};

handler.menu =  ['bonus <Premium only>'];
handler.tags =  ['rpg'];
handler.command = /^(bonus)/i;
handler.register = true;
handler.private = true;
handler.premium = true;

export default handler;

function msToTime(duration) {
    var milliseconds = parseInt((duration % 1000) / 100),
        seconds = Math.floor((duration / 1000) % 60),
        minutes = Math.floor((duration / (1000 * 60)) % 60),
        hours = Math.floor((duration / (1000 * 60 * 60)) % 24);
    
    hours = (hours < 10) ? "0" + hours : hours;
    minutes = (minutes < 10) ? "0" + minutes : minutes;
    seconds = (seconds < 10) ? "0" + seconds : seconds;

    return hours + " jam " + minutes + " menit " + seconds + " detik";
}
*/