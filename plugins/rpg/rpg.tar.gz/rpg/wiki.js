import db from '../../lib/database.js';
import wikiItems from './_WikiList.js';

const generateWikiList = () => {
    let itemList = '*📚 Wiki Encyclopedia for Ruka AI 📚*\n\n';
    itemList += 'Welcome to our Wiki! Explore the world of items and their descriptions.\n\n';
    itemList += '🔍 *How to use*:\n';
    itemList += '`.Wiki` - View this list\n';
    itemList += '`.Wiki detail <item>` - View detailed information about a specific item\n\n';
    itemList += '📜 *Available Entries*:\n';
    
    for (const item in wikiItems) {
        const itemData = wikiItems[item];
        itemList += `• *${item.charAt(0).toUpperCase() + item.slice(1)}* - ${itemData.shortDesc}\n`;
    }
    
    itemList += '\n💡 Tip: Use `.Wiki detail <item>` to learn more about any entry!';
    return itemList.trim();
};

const getItemDetails = (type) => {
    const item = wikiItems[type.toLowerCase()];
    if (!item) return 'Item not found in the Wiki. Please check the spelling or use `.Wiki` to see all available entries.';
    
    let details = `📖 *${type.charAt(0).toUpperCase() + type.slice(1)}*\n\n`;
    details += '`Explanation`\n\n';
    details += `${item.Expla}\n\n`;
    if (item.rarity) details += `✨ *Rarity*: ${item.rarity}\n`;
    details += '\n🔎 To explore more items, use `.Wiki`';
    
    return details;
};

const handler = async (m, { conn, command, args, usedPrefix }) => {
    const action = args[0]?.toLowerCase();
    const type = args[1]?.toLowerCase();

    if (!action) {
        conn.reply(m.chat, generateWikiList(), m);
        return;
    }

    try {
        switch (action) {
            case 'detail':
                if (!type) return conn.reply(m.chat, 'Please specify the item you want to learn about. Use `.Wiki` to see all available entries.', m);
                conn.reply(m.chat, getItemDetails(type), m);
                break;
            default:
                conn.reply(m.chat, `Invalid action. Use \`${usedPrefix}Wiki\` to see the list or \`${usedPrefix}Wiki detail <item>\` to view details about a specific item.`, m);
        }
    } catch (e) {
        conn.reply(m.chat, 'An error occurred while executing the command.', m);
        console.error(e);
    }
};

handler.menu = ['wiki']
handler.tags = ['rpg']
handler.command = /^(wiki)$/i;
handler.register = true

export default handler;