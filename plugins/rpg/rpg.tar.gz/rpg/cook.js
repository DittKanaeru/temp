import db from "../../lib/database.js";

// Daftar item dan detailnya
const items = {
    'grilled_chicken': {
        name: '🍗 Grilled Chicken',
        ingredients: {
            chicken: 3,
            coal: 2
        }
    },
    'fried_chicken': {
        name: '🍗 Fried Chicken',
        ingredients: {
            chicken: 3,
            minyak: 1,
            bumbu: 1
        }
    },
    'grilled_cow': {
        name: '🥩 Grilled Cow',
        ingredients: {
            cow: 1,
            coal: 2,
            bumbu: 3
        }
    },
    'bakso': {
        name: '🍲 Bakso',
        ingredients: {
            daging: 2,
            bumbu: 1,
            tepung: 1
        }
    },
    'burger': {
        name: '🍔 Burger',
        ingredients: {
            daging: 2,
            roti: 1,
            sayur: 1
        }
    },
    'bubur': {
        name: '🍚 Bubur',
        ingredients: {
            beras: 1,
            ayam: 1,
            bumbu: 1
        }
    },
    'kebab': {
        name: '🌯 Kebab',
        ingredients: {
            daging: 2,
            roti: 1,
            sayur: 1
        }
    },
    'nasi': {
        name: '🍚 Nasi',
        ingredients: {
            beras: 2,
            air: 1
        }
    },
    'pasta': {
        name: '🍝 Pasta',
        ingredients: {
            tepung: 2,
            telur: 1,
            bumbu: 1
        }
    },
    'pizza': {
        name: '🍕 Pizza',
        ingredients: {
            tepung: 3,
            keju: 2,
            bumbu: 1
        }
    },
    'roti': {
        name: '🍞 Roti',
        ingredients: {
            tepung: 3,
            telur: 1,
            gula: 1
        }
    },
    'salad': {
        name: '🥗 Salad',
        ingredients: {
            sayur: 3,
            saus: 1
        }
    },
    'sushi': {
        name: '🍣 Sushi',
        ingredients: {
            ikan: 2,
            nasi: 1,
            rumput_laut: 1
        }
    },
    'steak': {
        name: '🥩 Steak',
        ingredients: {
            daging: 3,
            bumbu: 2
        }
    },
    'lobsterbakar': {
        name: '🦞 Lobster Bakar',
        ingredients: {
            lobster: 1,
            coal: 2,
            bumbu: 2
        }
    },
    'guritabakar': {
        name: '🐙 Gurita Bakar',
        ingredients: {
            gurita: 1,
            coal: 2,
            bumbu: 2
        }
    },
    'cumibakar': {
        name: '🦑 Cumi Bakar',
        ingredients: {
            cumi: 1,
            coal: 2,
            bumbu: 2
        }
    },
    'ikanbakar': {
        name: '🐟 Ikan Bakar',
        ingredients: {
            ikan: 2,
            coal: 2,
            bumbu: 2
        }
    },
    'udangbakar': {
        name: '🍤 Udang Bakar',
        ingredients: {
            udang: 2,
            coal: 2,
            bumbu: 2
        }
    },
    'kepitingbakar': {
        name: '🦀 Kepiting Bakar',
        ingredients: {
            kepiting: 1,
            coal: 2,
            bumbu: 2
        }
    }
}

let handler = async (m, { conn, command, usedPrefix, DevMode, args }) => {
    let user = db.data.users[m.sender];
    
    // Initialize user's ingredients and food items if not a number
    const isNumber = (n) => !isNaN(parseFloat(n)) && isFinite(n);

    let foodItems = ['grilled_chicken', 'grilled_cow', 'fried_chicken', 'bakso', 'burger', 'bubur', 'kebab', 'nasi', 'pasta', 'pizza', 'roti', 'salad', 'sushi', 'steak', 'lobsterbakar', 'guritabakar', 'cumibakar', 'ikanbakar', 'udangbakar', 'kepitingbakar'];
    let ingredients = ['bumbu', 'minyak', 'coal', 'chip'];

    // Initialize user's items and ingredients if not present
    foodItems.forEach(food => {
        if (!isNumber(user[food])) user[food] = 0;
    });

    ingredients.forEach(ingredient => {
        if (!isNumber(user[ingredient])) user[ingredient] = 0;
    });

    try {
        if (/masak|cook/i.test(command)) {
            let itemName = args.join('_').toLowerCase(); // Menggabungkan argumen dan ubah ke huruf kecil
            itemName = itemName.replace(/\s+/g, '_'); // Replace spaces with underscores
            let item = items[itemName];

            if (!item) {
                // Tampilkan daftar item jika perintah tidak dikenali
                let itemList = Object.keys(items).map(item => {
                    let ingredientsList = Object.keys(items[item].ingredients).map(ingredient => `🛠 ${items[item].ingredients[ingredient]} ${ingredient}`).join(', ');
                    return `🍴 ${items[item].name}\n   📜 Bahan: ${ingredientsList}`;
                }).join('\n\n');
                await conn.reply(m.chat, itemList, m);
                return;
            }

            // Periksa ketersediaan bahan
            let hasIngredients = true;
            let missingIngredients = [];
            for (let ingredient in item.ingredients) {
                if ((user[ingredient] || 0) < item.ingredients[ingredient]) {
                    hasIngredients = false;
                    missingIngredients.push(`🛠 ${item.ingredients[ingredient]} ${ingredient}`);
                }
            }

            if (hasIngredients) {
                // Kurangi bahan dari inventaris user dan tambahkan item yang dimasak
                for (let ingredient in item.ingredients) {
                    user[ingredient] -= item.ingredients[ingredient];
                }
                user[itemName] = (user[itemName] || 0) + 1;
                await conn.reply(m.chat, `✅ Sukses Memasak ${item.name}!`, m);
            } else {
                await conn.reply(m.chat, `❌ Kamu Kekurangan Bahan ${missingIngredients.join(', ')} Untuk Memasak ${item.name}`, m);
            }
        }
    } catch (e) {
        await conn.reply(m.chat, `⚠️ Sepertinya Ada Yg Eror, Coba Laporkan Ke Owner Deh`, m);
        console.log(e);
    }
}

handler.menu = ['masak']
handler.tags = ['rpg']
handler.command = /^(masak|cook)$/i
handler.register = true
handler.group = true

export default handler
