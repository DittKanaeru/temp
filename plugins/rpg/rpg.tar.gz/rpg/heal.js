import db from '../../lib/database.js';

let handler = async (m, { args, usedPrefix }) => {
    let user = db.data.users[m.sender];

    // Initialize user properties if they don't exist
    if (!user.health) user.health = user.MAXhealth || 100;  // Use MAXhealth if it exists, otherwise default to 100
    if (!user.stamina) user.stamina = user.MAXstamina || 100;  // Use MAXstamina if it exists, otherwise default to 100
    if (!user.potion) user.potion = 0;
    if (!user.elixir) user.elixir = 0;
    if (!user.neuron) user.neuron = 0;

    if (!args[0] || (args[0].toLowerCase() !== 'health' && args[0].toLowerCase() !== 'stamina')) {
        return m.reply(`
💊 *Pilih yang ingin diheal:*
- .heal health
- .heal stamina

💡 *Contoh:*
.heal health potion
        `.trim());
    }

    let healType = args[0].toLowerCase();

    // Check if the user's health or stamina is already at max
    if (healType === 'health' && user.health >= user.MAXhealth) {
        return m.reply(`🛑 *Health kamu sudah penuh!*`);
    } else if (healType === 'stamina' && user.stamina >= user.MAXstamina) {
        return m.reply(`🛑 *Stamina kamu sudah penuh!*`);
    }

    if (!args[1] || (args[1].toLowerCase() !== 'potion' && args[1].toLowerCase() !== 'elixir' && args[1].toLowerCase() !== 'neuron')) {
        return m.reply(`
🧪 *Pilih ramuan yang ingin digunakan:*
- .heal ${healType} potion (${user.potion} tersedia)
- .heal ${healType} elixir (${user.elixir} tersedia)
- .heal ${healType} neuron (${user.neuron} tersedia)

💡 *Contoh:*
.heal ${healType} potion
        `.trim());
    }

    let healOption = args[1].toLowerCase();
    let healAmount;
    let potionCount;

    switch (healOption) {
        case 'potion':
            healAmount = Math.floor(Math.random() * (50 - 30 + 1) + 30);
            potionCount = user.potion;
            break;
        case 'neuron':
            if (['mage', 'fighter', 'tank'].includes(user.role)) {
                healAmount = Math.floor(Math.random() * (70 - 40 + 1) + 40);
                potionCount = user.neuron;
            } else {
                return m.reply(`⚠️ *Neuron hanya dapat digunakan oleh Mage, Fighter, atau Tank.*`);
            }
            break;
        case 'elixir':
            if (['marksman', 'assassin'].includes(user.role)) {
                healAmount = Math.floor(Math.random() * (68 - 45 + 1) + 45);
                potionCount = user.elixir;
            } else {
                return m.reply(`⚠️ *Elixir hanya dapat digunakan oleh Marksman atau Assassin.*`);
            }
            break;
        default:
            return m.reply(`❌ *Ramuan tidak dikenali.*`);
    }

    if (potionCount < 1) {
        return m.reply(`
🚫 *Kamu tidak memiliki cukup ${healOption}.*
💰 *Ketik ${usedPrefix}shop buy ${healOption}* untuk membelinya.
        `.trim());
    }

    // Heal the user without exceeding max health or stamina
    if (healType === 'health') {
        user.health = Math.min(user.health + healAmount, user.MAXhealth);
    } else if (healType === 'stamina') {
        user.stamina = Math.min(user.stamina + healAmount, user.MAXstamina);
    }

    // Decrease the corresponding potion count
    if (healOption === 'potion') {
        user.potion -= 1;
    } else if (healOption === 'elixir') {
        user.elixir -= 1;
    } else if (healOption === 'neuron') {
        user.neuron -= 1;
    }

    m.reply(`
🎉 *Sukses!*
${healOption.charAt(0).toUpperCase() + healOption.slice(1)} berhasil digunakan.
🌟 Kamu telah diheal sebanyak ${healAmount} ${healType === 'health' ? 'Health' : 'Stamina'}!

🧪 *Sisa Ramuan:*
- Potion: ${user.potion}
- Elixir: ${user.elixir}
- Neuron: ${user.neuron}
    `.trim());
};

handler.help = ['heal'];
handler.tags = ['rpg'];
handler.command = /^(heal)$/i;
handler.register = true;
handler.group = true;

export default handler;

function isNumber(number) {
    if (!number) return false;
    number = parseInt(number);
    return typeof number == 'number' && !isNaN(number);
}
