import db from "../../lib/database.js";

const cooldownCommands = [
    "claim",
    "berburu",
    "adventure",
    "memancing",
    "dungeon",
    "duel",
    "mining",
    "misi",
    "lumber",
    "hunt",
    "jb",
    "kerja",
    "bunga",
    "weekly",
    "monthly"
];

const capitalizeFirstLetter = (string) => {
    return string.charAt(0).toUpperCase() + string.slice(1);
};

const getCooldownStatus = (lastCooldown) => {
    return lastCooldown > 0 ? "❌" : "✅";
};

const handler = async (m, { conn }) => {
    const userId = m.sender;
    const user = db.data.users[userId];
    const level = user.level;
    const username = await conn.getName(userId);
    const pp = await conn.profilePictureUrl(userId, 'image').catch(_ => '../../src/avatar_contact.png');

    let cooldownStatus = '';
    for (const command of cooldownCommands) {
        cooldownStatus += `*Last ${capitalizeFirstLetter(command)} :* ${getCooldownStatus(user[`last${command}`])}\n`;
    }

    const str = `
*—「 Cooldown 」—*
${cooldownStatus.trim()}
`;

    conn.sendMessage(m.chat, {
        text: str,
        contextInfo: {
            externalAdReply: {
                title: `Name : ${username}`,
                body: `Level : ${level}`,
                thumbnailUrl: pp,
                mediaType: 1,
                renderLargerThumbnail: true
            }
        }
    });
};

handler.menu =  ["cd", "cooldown"];
handler.tags =  ["rpg"];
handler.command = /^(cd|cooldown)$/i;
handler.register = true
export default handler;
