const wikiItems = {
    trash: {
        shortDesc: "Common waste material",
        Expla: "Trash refers to any discarded or unwanted material. In many RPG settings, it's often the most common and least valuable item found during adventures or scavenging.",
        //type: "Common Item",
        rarity: "Very Common"
    },
    potion: {
        shortDesc: "Healing liquid",
        Expla: "A magical or alchemical concoction that restores health when consumed. Potions are a staple in many RPG and fantasy settings.",
        //type: "Consumable",
        rarity: "Common"
    },
    material: {
        shortDesc: "Wood,Steel,Iron,Dan lain lain",
        Expla: "Simple nya bahan bahan yg di gunakan untuk material create atapun bisa di jual, kamu bisa mendapatkan ini dengan mudah",
        //type: "Consumable",
        rarity: "Common"
    },
     crypto: {
        shortDesc: "Simple investment",
        Expla: "Sedikit simulasi dengan sistem yg sama seperti crypto yaitu harga yg naik/turun sesuai dengan market pada hari itu",
        //type: "Consumable",
        rarity: "Common"
    },    
    limit: {
        shortDesc: "Limit kamu menggunakan fitur",
        Expla: "Suatu item yg membatasi sebanyak apa kamu bisa bermain dengan fitur bot. kamu kehabisan limit? bisa kamu beli di .market buy limit.",
        //type: "Penting",
        rarity: "null"
    },
    claim: {
        shortDesc: "Hadiah harian/mingguan/bulanan",
        Expla: "Kamu bisa mengambil hadiah harian/bulanan/mingguan dengan cara .claim daily/monthly/weekly",
        //type: "private",
        rarity: "normal"
    },
    bank: {
        shortDesc: "tempat kamu menyimpan uang",
        Expla: "Kamu bisa mengecheck keuangan mu di sini dengan command .bank kamu ga bisa nabung? coba craft ATM aja dulu lewat .craft atm nah nanti auto bisa.",
        //type: "private",
        rarity: "Common"
    },
    profile: {
        shortDesc: "data diri mu",
        Expla: "Kamu bisa mengecheck Nick mu,role,exp,level bahkan pekerjaan mu.",
        //type: "private",
        rarity: "Common"
    },
    inv: {
        shortDesc: "tempat penyimpanan mu",
        Expla: "Kamu bisa mengecheck semua yg terdapat dalam backpack mu seperti potion,sword,pickaxe,DLL sesuai dengan apa yg kamu dapatkan untuk membuka inv kamu cukup .inv .",
        //type: "Consumable",
        rarity: "Common"
    },
    craft: {
        shortDesc: "Buat barang mu sendiri",
        Expla: "Beberapa fitur mengharuskan diri mu untuk membuat sebuah peralatan entah itu pedang,bow,axe,fishing rod nah untuk membuat itu kamu harus melakukan .craft dan pastikan untuk punya semua material yg kamu butuhkan.",
        //type: "Consumable",
        rarity: "Private"
    },
    misi: {
        shortDesc: "Daily mission",
        Expla: "Tempat dimana kamu bisa mencari yen/mata uang dengan 3 opsi kesulitan dan di mulai dengan tier D.",
        //type: "Consumable",
        rarity: "Daily"
    },
    cook: {
        shortDesc: "Masak sendiri",
        Expla: "Beberapa fitur mengharuskan diri mu untuk membuat sebuah peralatan entah itu pedang,bow,axe,fishing rod nah untuk membuat itu kamu harus melakukan .craft dan pastikan untuk punya semua material yg kamu butuhkan.",
        //type: "Consumable",
        rarity: "Private"
    },
    market: {
        shortDesc: "Jual beli barang",
        Expla: "Tempat dimana kamu bisa membeli barang sesuai dengan kebutuhan mu atau pun kamu bisa menjual barang untuk mendapatkan yen.",
        //type: "Consumable",
        rarity: "Null"
    },
    work: {
        shortDesc: "Kerja kerja kerja",
        Expla: "Tempat dimana kamu bisa mendapatkan yen yg lumayan banyak hanya dengan mengetik .work oh ya di sini juga ada banyak opsi nya jadi kamu bisa memilih salah satu jika kamu ingin mengganti yg lain maka kamu harus menunggu selama 1 minggu.",
        //type: "Consumable",
        rarity: "Private"
    },
    eat: {
        shortDesc: "kalo ga makan mati!!!",
        Expla: "Sama kayak .use tapi ini khusus makanan saja dan ya udah sih sama aja",
        //type: "Consumable",
        rarity: "Private"
    },
    family100: {
        shortDesc: "TV show games",
        Expla: "Games dimana kamu harus menjawab sebuah soal namun jawaban mu harus benar dan juga berdasarkan opini banyak org",
        //type: "Consumable",
        rarity: "Normal"
    },
    games: {
        shortDesc: "Fuck your boring",
        Expla: "Permainan yg bisa di mainkan oleh banyak orang dengan sistem tebak tebakan.",
        //type: "Consumable",
        rarity: "Normal"
    },
    skill: {
        shortDesc: "Skill is important",
        Expla: "Tempat dimana kamu bisa memilih skill yg kamu mau dan juga ingat untuk berhati hati memlih skill karena kamu harus menunggu lama untuk memilih skill kembali",
        //type: "Consumable",
        rarity: "Normal"
    },
    tebakgambar: {
        shortDesc: "Fuck your boring",
        Expla: "Game ini mengharuskan mu untuk menebak kata dari sebuah gambar.",
        //type: "Consumable",
        rarity: "Normal"
    },
};

export default wikiItems;