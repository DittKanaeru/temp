const items = {
    health_breaker: {
        buyPrice: 500000000,
    },
    stamina_breaker: {
        buyPrice: 500000000
    },
    vrpass: {
        buyPrice: 5000000
    },
	limit: {
		buyPrice: 100000
	},
	potion: {
		buyPrice: 200000
	}
};

export default items;