import db from '../../lib/database.js'
import { ranNumb } from '../../lib/func.js'

const cooldown = 21600000 // 6 jam
const minCooldownn = 600000 // 10 menit
const maxCooldownn = 1800000 // 30 menit
const pityChance = 0.3 // 30% chance to fail

const fishingLocations = {
    "aquaspace": [
        { name: "nixie", emoji: "🐠" },
        { name: "triton", emoji: "🐡" },
        { name: "marlin", emoji: "🐟" },
        { name: "coralin", emoji: "🎣" },
        { name: "finley", emoji: "🐋" },
        { name: "wave", emoji: "🦑" },
        { name: "keplie", emoji: "🦐" },
        { name: "lagoon", emoji: "🐙" },
        { name: "fingrod", emoji: "🐠" },
        { name: "nymphora", emoji: "🐡" }
    ],
    "darkness_sea": [
        { name: "azure", emoji: "🐬" },
        { name: "aqualis", emoji: "🦞" },
        { name: "zeplyn", emoji: "🐟" },
        { name: "tritonus", emoji: "🎣" },
        { name: "finara", emoji: "🐋" },
        { name: "naucitus", emoji: "🦈" },
        { name: "tetra", emoji: "🐬" },
        { name: "clownfi", emoji: "🦑" },
        { name: "hyoxis", emoji: "🦐" },
        { name: "crab", emoji: "🦀" }
    ],
    "power_sea": [
        { name: "gourami", emoji: "🦈" },
        { name: "fish", emoji: "🐠" },
        { name: "octopus", emoji: "🐙" },
        { name: "squid", emoji: "🦑" },
        { name: "shrimp", emoji: "🦐" },
        { name: "seaweed", emoji: "🌿" },
        { name: "lobster", emoji: "🦞" }
    ]
}

const locationNames = ["aquaspace", "darkness_sea", "power_sea"]

let handler = async (m, { conn, command, usedPrefix, text }) => {
    let user = db.data.users[m.sender]
    if (new Date - user.lastfishing <= cooldown) 
        return m.reply(`📍 Anda sudah memancing, selanjutnya dapat dilakukan dalam . . .\n🕖 *${new Date(user.lastfishing + cooldown).toLocaleTimeString()}*`)
    if (user.fishingrod == 0) 
        return m.reply(`Perlu *${usedPrefix}craft* fishingrod terlebih dahulu.\n\nAnda memiliki :\n━ 🎣 ${user.fishingrod} FishingRod`)

    let location = text.toLowerCase().trim()
    if (!locationNames.includes(location) && !["1", "2", "3"].includes(location)) {
        return m.reply(`Silakan pilih lokasi memancing yang valid:\n1. Aquaspace\n2. Darkness Sea\n3. Power Sea\n\nContoh: ${usedPrefix}mancing 1 atau ${usedPrefix}mancing aquaspace`)
    }

    if (["1", "2", "3"].includes(location)) {
        location = locationNames[parseInt(location) - 1]
    }

    const locationDisplay = location.replace('_', ' ')
    m.reply(`Kamu sudah memilih lokasi mancingmu yaitu ${locationDisplay.toUpperCase()}.\n\n**Cerita:**\n\nDengan semangat petualangan, kamu mempersiapkan alat pancingmu dan melangkah ke arah ${locationDisplay.toUpperCase()}. Langit cerah dan angin sepoi-sepoi menambah semangatmu. Kamu mulai memasang umpan di kail dan melemparkan pancing ke dalam air biru yang tenang. Dalam hatimu, kamu berharap akan mendapatkan tangkapan besar hari ini.`)

    if (Math.random() < pityChance) {
        return setTimeout(() => m.reply("Setelah beberapa jam menunggu, kamu merasa ada yang kurang hari ini. Mancing sudah selesai namun kamu tak membawa apa-apa. Yah, mungkin ini hari sialmu. Jangan putus asa dan coba lagi nanti!"), ranNumb(minCooldownn, maxCooldownn))
    }

    const selectedLocation = fishingLocations[location]

    let mancing = Array.from({ length: selectedLocation.length }, () => ({ ikan: 0 }))
    for (let x of mancing) {
        let random = ranNumb(0, 2)
        x.ikan += random
    }

    let gmbrt = 'https://i.ibb.co/Gvq1wp6/calm-of-nature-by-xmrfel-dfwy2rd-pre.jpg'
    let hsl = `🌊 **Mancing di ${locationDisplay.toUpperCase()} Selesai** 🌊\n\n` +
              `Dengan hati berdebar, kamu menarik pancingmu ke atas dan melihat hasil tangkapanmu:\n\n`

    let itemsShown = false;
    for (let i = 0; i < selectedLocation.length; i++) {
        if (mancing[i].ikan > 0) {
            hsl += `*${selectedLocation[i].emoji} ${selectedLocation[i].name.toUpperCase()}* = [ ${mancing[i].ikan} ]\n`
            itemsShown = true;
        }
    }

    if (!itemsShown) {
        hsl += "(Tidak ada hasil mancing kali ini)"
    }

    const randomCooldownn = ranNumb(minCooldownn, maxCooldownn)

    setTimeout(() => {
        for (let i = 0; i < selectedLocation.length; i++) {
            user[selectedLocation[i].name] += mancing[i].ikan
        }
        conn.sendFile(m.chat, gmbrt, '', hsl, m)
    }, randomCooldownn)

    setTimeout(() => {
        m.reply('_Sedang memancing..._')
    }, 0)

    user.lastfishing = new Date * 1
    user.fishingcount += 1
}

handler.menu = ['mancing']
handler.tags = ['rpg']
handler.command = /^(mancing|fishing)$/i

handler.cooldown = cooldown
handler.register = true
handler.group = true
export default handler
