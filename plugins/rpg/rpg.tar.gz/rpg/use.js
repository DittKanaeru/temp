import db from '../../lib/database.js';

const elixirs = {
    'health_breaker': {
        name: 'Health Breaker',
        effect: 'MAXhealth',
        amount: 100
    },
    'stamina_breaker': {
        name: 'Stamina Breaker',
        effect: 'MAXstamina',
        amount: 100
    }
};

const handler = async (m, { args, usedPrefix }) => {
    const user = db.data.users[m.sender];

    if (!args[0]) {
        let elixirList = Object.entries(user)
            .filter(([key, value]) => elixirs[key])
            .map(([key, value]) => `- ${elixirs[key].name}: ${value}`)
            .join('\n');
        m.reply(`> *Elixir Yang Kamu Miliki*:\n${elixirList || 'Kamu tidak memiliki elixir.'}\n\n> Usage: .use <nama item> <jumlah>`);
        return;
    }

    let useAmount = 1;

    if (!isNaN(args[args.length - 1])) {
        useAmount = parseInt(args.pop());
    }

    const itemName = args.join(" ").toLowerCase();

    const elixir = Object.values(elixirs).find(elixir => elixir.name.toLowerCase() === itemName || elixir.alias?.toLowerCase() === itemName);

    if (!elixir) {
        m.reply(`Elixir '${itemName}' tidak ditemukan.`);
        return;
    }

    const elixirKey = Object.keys(elixirs).find(key => elixirs[key] === elixir);

    if (user[elixirKey] === undefined || user[elixirKey] < useAmount) {
        m.reply(`Kamu tidak memiliki ${elixir.name} sebanyak itu.`);
        return;
    }

    if (elixir.effect && user[elixir.effect] !== undefined) {
        user[elixir.effect] += elixir.amount * useAmount;
        user[elixirKey] -= useAmount;
        db.data.users[m.sender] = user;
        m.reply(`${elixir.name} sebanyak ${useAmount} telah digunakan. ${elixir.effect} ditambahkan sebanyak ${elixir.amount * useAmount}.`);
    } else {
        m.reply(`Elixir '${elixir.name}' tidak memiliki efek yang dapat diaplikasikan.`);
    }
};

handler.menu =  ['use'];
handler.tags =  ['rpg'];
handler.command = /^(use)$/i;
handler.register = true;

export default handler;
