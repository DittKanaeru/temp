import db from '../../lib/database.js'

let animalNames = ['chicken', 'cow', 'goat', 'rabbit', 'sheep', 'bear', 'pig', 'buffalo', 'griffin', 'eagle', 'thorne', 'zephyr', 'ocelot', 'faelen', 'arctic', 'cheetah', 'koala', 'leopard', 'horse', 'fox'];

let handler = async (m, { conn }) => {
    let userData = db.data.users[m.sender];
    let username = userData.name;
    let leveluser = userData.level;

    let past = '*—「 KANDANG  」—*\n━─┈───────────────┈─━\n';
    animalNames.forEach(animalNames => {
        past += `• ${capitalizeFirstLetter(animalNames)}: *${userData[animalNames]}*\n`;
    });

    past += `• ${capitalizeFirstLetter(animalNames[animalNames.length - 1])}: *${userData[animalNames[animalNames.length - 1]]}*\n`;

    past += '━─┈───────────────┈─━\n';
    past = past.trim();
    
    conn.sendMessage(m.chat, {
        text: past,
        contextInfo: {
            externalAdReply: {
                title: `Name : ${username}`,
                body: `Level : ${leveluser}`,
                thumbnailUrl: `https://i.ibb.co/sqFntGP/enchanted-forest-at-golden-hour-by-plam50-dgjsj83-2.jpg`,
                mediaType: 1,
                renderLargerThumbnail: true
            }
        }
    });
}

// Fungsi untuk membuat huruf pertama menjadi kapital
function capitalizeFirstLetter(string) {
    return string.charAt(0).toUpperCase() + string.slice(1);
}

handler.menu =  ['kandang']
handler.tags =  ['rpg']
handler.command = /^(kandang)$/i
handler.register = true
handler.group = true
export default handler
