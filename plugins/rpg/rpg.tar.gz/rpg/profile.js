import db from '../../lib/database.js'
import PhoneNumber from 'awesome-phonenumber'
import { xpRange } from '../../lib/levelling.js'

const handler = async (m, { conn, isPrems, text }) => {
  const who = text ? (text.replace(/[@ .+-]/g, '') + '@s.whatsapp.net') : (m.quoted ? m.quoted.sender : m.mentionedJid?.[0] ? m.mentionedJid[0] : m.sender)

  try {
    const user = db.data.users[who]
    if (!isPrems && user.level > db.data.users[m.sender].level) 
      return m.reply(`[!] Gagal, level target lebih tinggi.`)

    let pp = './src/avatar_contact.png'
    try {
      const profilePictureUrl = await conn.profilePictureUrl(who, 'image')
      if (profilePictureUrl) {
        pp = profilePictureUrl
      }
    } catch (e) {
      console.log(`[!] Gagal mendapatkan gambar profil untuk ${who}:`, e)
    }

    const { name, limit, exp, yen, level, role, job, skill } = user
    const { min, xp, max } = xpRange(level, global.multiplier)

    let str = `*Name :* _${name}_\n\n`
    str += `*Level :* ${level}\n`
    str += `*EXP :* ${exp} (${exp - min} / ${xp})\n`
    str += `*Role :* ${role}\n`
    str += `*Job :* ${job || '_Belum Memiliki Job_'}\n`
    str += `*Class :* ${skill || '_Belum Memiliki Class_'}\n`

    await conn.sendMsg(m.chat, { image: { url: pp, fileName: 'pp.jpg' }, caption: str }, { quoted: m })
  } catch (e) {
    console.log(e)
    m.reply(`[!] User tidak ada dalam database.`)
  }
}

handler.menu = ['profile']
handler.tags = ['rpg']
handler.command = /^(profile?|me)$/i
handler.register = true
export default handler