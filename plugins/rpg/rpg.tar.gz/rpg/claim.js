import db from '../../lib/database.js'
import vr from '../../config.js';

const monthlyRewards = {
	exp: 4000,
	yen: 100000,
	potion: 12,
	wood: 12,
	rock: 12,
	string: 9,
	iron: 9,
}

const weeklyRewards = {
	exp: 350,
	yen: 27000,
	potion: 2,
	wood: 4,
	rock: 4,
	string: 3,
	iron: 3,
}

const monthlyCooldown = 2592000000
const weeklyCooldown = 604800000

let handler = async (m, { text }) => {
    let user = db.data.users[m.sender]
    if (!text) {
        return m.reply(`Silakan pilih mau claim apa, dengan menggunakan usage seperti ini:\n> .claim weekly\n> .claim monthly`)
    } else if (/^monthly$/i.test(text)) {
        if (new Date - user.lastmonthly < monthlyCooldown) return m.reply(`Anda sudah mengklaim ini bulanan, tunggu *${((user.lastmonthly + monthlyCooldown) - new Date()).toTimeString()}*`)
        let monthlyText = ''
        for (let reward of Object.keys(monthlyRewards)) {
            if (!(reward in user)) continue
            user[reward] += monthlyRewards[reward]
            monthlyText += `*+${monthlyRewards[reward]}* ${vr.rpg.emoticon(reward)}${reward}\n`
        }
        m.reply(monthlyText.trim())
        user.lastmonthly = new Date * 1
    } else if (/^weekly$/i.test(text)) {
        if (new Date - user.lastweekly < weeklyCooldown) return m.reply(`Anda sudah mengklaim ini mingguan, tunggu *${((user.lastweekly + weeklyCooldown) - new Date()).toTimeString()}*`)
        let weeklyText = ''
        for (let reward of Object.keys(weeklyRewards)) {
            if (!(reward in user)) continue
            user[reward] += weeklyRewards[reward]
            weeklyText += `*+${weeklyRewards[reward]}* ${vr.rpg.emoticon(reward)}${reward}\n`
        }
        m.reply(weeklyText.trim())
        user.lastweekly = new Date * 1
    } else {
        return m.reply(`Opsi yang Anda pilih tidak valid. Silakan gunakan "weekly" atau "monthly" untuk melakukan klaim hadiah.`)
    }
}

handler.menu =  ['claim']
handler.tags =  ['rpg']
handler.command = /^(claim)$/i
handler.register = true
export default handler
