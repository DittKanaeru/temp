import { loadDatabase, database as db } from '../../lib/database.js';

const danakagetCooldown = 10 * 60 * 1000; // 5 minutes in milliseconds
const minParticipants = 3;
const maxParticipants = 20;

const activeDanakagets = new Map();

let handler = async (m, { conn }) => {
    await loadDatabase(); // Ensure the database is loaded

    let command = m.text.trim().split(' ');
    let user = m.sender;
    let chatId = m.chat;

    if (!db.data.users[user]) {
        db.data.users[user] = {
            yen: 0,
            lastDanakaget: 0
        };
    }

    let userData = db.data.users[user];
    let currentTime = Date.now();

    if (command[0] === '.danakaget' && command.length === 1) {
        conn.reply(chatId, `⚠️ Gunakan: .danakaget <jumlah yen> <jumlah penerima>. Contoh: .danakaget 1000 5`, m);
        return;
    }

    if (command[0] === '.danakaget' && command[1] !== 'claim' && command.length === 3) {
        let amount = parseInt(command[1]);
        let numParticipants = parseInt(command[2]);

        // Validasi input
        if (isNaN(amount) || isNaN(numParticipants) || numParticipants < minParticipants || numParticipants > maxParticipants) {
            conn.reply(chatId, `⚠️ Format salah! Gunakan .danakaget <yen> <jumlah pengguna>. Jumlah pengguna harus antara ${minParticipants} dan ${maxParticipants}.`, m);
            return;
        }

        if (userData.lastDanakaget + danakagetCooldown > currentTime) {
            let remainingTime = formatTime(userData.lastDanakaget + danakagetCooldown - currentTime);
            conn.reply(chatId, `⏳ Kamu @${user.split('@')[0]}, perlu menunggu ${remainingTime} sebelum bisa membuat danakaget lagi.`, m);
            return;
        }

        if (userData.yen < amount) {
            conn.reply(chatId, `⚠️ Kamu tidak memiliki cukup yen (${amount} yen diperlukan) untuk membuat danakaget ini.`, m);
            return;
        }

        userData.yen -= amount; // Deduct the amount from user's yen
        let code = generateCode();

        // Simpan danakaget dalam Map
        activeDanakagets.set(code, {
            creator: user,
            amount,
            numParticipants,
            claimed: [],
            createdAt: currentTime
        });

        userData.lastDanakaget = currentTime;
        await db.write();

        conn.reply(chatId, `💸 Danakaget dibuat oleh @${user.split('@')[0]}!

- Code: ${code}
- Jumlah: ${numParticipants}

🔔 Ketik: .danakaget claim <code>
🔕 Kadaluarsa Dalam 5 menit`, m);

        // Set timeout untuk kedaluwarsa
        setTimeout(async () => {
            if (activeDanakagets.has(code)) {
                let danakaget = activeDanakagets.get(code);
                let remainingAmount = danakaget.amount - calculateTotalClaimed(danakaget.claimed, danakaget.amount, danakaget.numParticipants);

                db.data.users[danakaget.creator].yen += remainingAmount; // Kembalikan sisa amount ke creator
                conn.reply(chatId, `⏰ Danakaget dengan code ${code} telah kedaluwarsa. Sisa uang ${remainingAmount} yen telah dikembalikan ke @${danakaget.creator.split('@')[0]}.`, m);

                activeDanakagets.delete(code);
                await db.write();
            }
        }, danakagetCooldown);

    }

    if (command[0] === '.danakaget' && command[1] === 'claim' && command.length === 3) {
        let code = command[2].trim();

        if (!activeDanakagets.has(code)) {
            conn.reply(chatId, `⚠️ Kode danakaget tidak valid atau telah kedaluwarsa.`, m);
            return;
        }

        let danakaget = activeDanakagets.get(code);

        if (danakaget.claimed.includes(user)) {
            conn.reply(chatId, `⚠️ Kamu sudah mengambil danakaget ini.`, m);
            return;
        }

        if (danakaget.claimed.length >= danakaget.numParticipants) {
            conn.reply(chatId, `⚠️ Semua danakaget telah diambil.`, m);
            return;
        }

        let share = calculateShare(danakaget.amount, danakaget.claimed.length, danakaget.numParticipants);

        // Hanya beri share untuk peserta yang klaim
        userData.yen += share;
        danakaget.claimed.push(user);

        await db.write();

        conn.reply(chatId, `🎉 @${user.split('@')[0]} telah menerima ${share} yen!`, m);

        if (danakaget.claimed.length === danakaget.numParticipants) {
            activeDanakagets.delete(code);
        }
    }
};

function formatTime(milliseconds) {
    let seconds = Math.floor(milliseconds / 1000);
    let hours = Math.floor(seconds / 3600);
    seconds %= 3600;
    let minutes = Math.floor(seconds / 60);
    seconds %= 60;
    return `${pad(hours)}:${pad(minutes)}:${pad(seconds)}`;
}

function pad(number) {
    return (number < 10 ? '0' : '') + number;
}

function generateCode() {
    return Math.random().toString(36).substring(2, 8).toUpperCase();
}

function calculateShare(totalAmount, claimedCount, totalParticipants) {
    // Jangan bagi totalAmount dengan 0 untuk menghindari pembagian dengan nol
    if (totalParticipants <= claimedCount) return 0; 
    const remainingAmount = totalAmount - calculateTotalClaimed([], totalAmount, totalParticipants); // Ambil total klaim yang sudah ada
    return Math.round(remainingAmount / (totalParticipants - claimedCount));
}

function calculateTotalClaimed(claimedArray, totalAmount, totalParticipants) {
    let claimedAmount = 0;
    for (let i = 0; i < claimedArray.length; i++) {
        claimedAmount += calculateShare(totalAmount, i, totalParticipants);
    }
    return claimedAmount;
}

handler.help = ['danakaget'];
handler.tags = ['rpg'];
handler.command = /^(danakaget|\.danakaget)$/i;
handler.group = true;
handler.register = true;
handler.limit = true

export default handler;
