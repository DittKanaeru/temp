import db from '../../lib/database.js'

const cooldown = 4320000
const durabilityReduction = 20
const minDurability = 30

let handler = async (m, { usedPrefix }) => {
    let user = db.data.users[m.sender]
    let timers = (cooldown - (new Date - user.lastmining))
    if (user.health < 80) return m.reply(`
Kesehatanmu Kurang Dari 80%, Gunakan Perintah *${usedPrefix}buy potion <quantity>*,
Dan Perintah *${usedPrefix}heal <quantity>* Untuk Membeli Dan Menggunakan Potion
`.trim())
    if (db.data.users.pickaxe == 0) return m.reply('Mau Nambang Nggak Punya Pickaxe, Bikin Dulu Dengan Cara Ketik .craft pickaxe')
    if (user.pickaxedurability < minDurability) return m.reply('Perbaiki durability pickaxe terlebih dahulu')
    if (new Date - user.lastmining <= cooldown) return m.reply(`Kamu Sudah Menambang, Tunggu *🕐${timers.toTimeString()}* Lagi`.trim())
    const rewards = reward()
    let text = 'Kamu Menambang Dan Sekarang Kelelahan'
    for (const rewardItem in rewards) {
        user[rewardItem] += rewards[rewardItem]
        if (rewards[rewardItem]) text += `\n*${rewardItem}:* ${rewards[rewardItem]}`
    }
    user.pickaxedurability -= durabilityReduction
    if (user.pickaxedurability < minDurability) {
        user.pickaxedurability = minDurability
    }
    m.reply(text.trim())
    user.lastmining= new Date * 1
}
handler.menu =  ['mining']
handler.tags =  ['rpg']
handler.command = /^(mining)$/i

handler.cooldown = cooldown
handler.register = true
handler.disabled = false
handler.group = true

export default handler

function reward() {
    let rewards = {
        exp: Math.floor(Math.random() * 1001),
        trash: Math.floor(Math.random() * 201),
        string: Math.floor(Math.random() * 31),
        rock: Math.floor(Math.random() * 36),
        coal: Math.floor(Math.random() * 20),
        iron: Math.floor(Math.random() * 22),
        diamond: Math.random() < 0.05 ? 3 : 0, // Drop rate 5%
        emerald: Math.random() < 0.1 ? 2 : 0, // Drop rate 10%
        common: Math.random() < 0.8 ? 3 : 0, // Drop rate 80%
        uncommon: Math.random() < 0.7 ? 3 : 0, // Drop rate 70%
        mythic: Math.random() < 0.03 ? 2 : 0, // Drop rate 3%
        legendary: Math.random() < 0.01 ? 1 : 0, // Drop rate 1%
        gold: Math.random() < 0.2 ? 3 : 0 // Drop rate 20%
    };

    // Ensure rewards do not exceed maximum values
    rewards.exp = Math.min(rewards.exp, 1000);
    rewards.trash = Math.min(rewards.trash, 200);
    rewards.string = Math.min(rewards.string, 30);
    rewards.rock = Math.min(rewards.rock, 35);
    rewards.coal = Math.min(rewards.coal, 19);
    rewards.iron = Math.min(rewards.iron, 21);
    rewards.diamond = Math.min(rewards.diamond, 3);
    rewards.emerald = Math.min(rewards.emerald, 2);
    rewards.common = Math.min(rewards.common, 3);
    rewards.uncommon = Math.min(rewards.uncommon, 3);
    rewards.mythic = Math.min(rewards.mythic, 2);
    rewards.legendary = Math.min(rewards.legendary, 1);
    rewards.gold = Math.min(rewards.gold, 3);

    return rewards;
}
