import db from '../../lib/database.js'
import { ranNumb } from '../../lib/func.js'

const cooldown = 86400000 // 24 hours
const resultDelay = 10000 // 10 seconds

const mapLocations = {
    'Azure Stronghold': 'Benteng melayang dengan energi sihir yang kuat, tempat para penyihir memanfaatkan kekuatan kosmos.',
    'Ethereal Sand': 'Padang pasir tanpa akhir di mana realitas berkilau seperti fatamorgana.',
    'Ancient Ice': 'Tanah tandus beku dengan gletser raksasa dan benteng es.',
    'Sunken Fire': 'Jaringan ruang bawah tanah berisi lava, tempat para pembunuh berlatih dalam bayangan.',
    'Thunder Canyon': 'Jurang bergerigi di mana petir terus-menerus menyambar.'
}

const mapImageUrl = 'https://telegra.ph/file/5491601395f67cf018480.jpg'

const huntingTargets = {
    'Azure Stronghold': ["chicken", "griffin", "eagle", "hilichurl", "slime", "abyss", "cicin", "whopperflower", "samachurl", "fatui"],
    'Ethereal Sand': ["goat", "cow", "rabbit", "mitachurl", "vishap", "ruin", "abundance", "swallowtail", "imaginary", "phantom"],
    'Ancient Ice': ["bear", "buffalo", "arctic", "lawachurl", "meka", "automaton", "zombie", "revenant", "oceanid", "colossus"],
    'Sunken Fire': ["pig", "faelen", "thorne", "silvermane", "trotskjak", "hellhound", "wraith", "marionette", "regisvine", "behemoth"],
    'Thunder Canyon': ["zephyr", "ocelot", "fox", "stellaron", "abomination", "voidranger", "propagator", "banshee", "ghoul", "leviathan"]
}

let handler = async (m, { conn, command, usedPrefix, text }) => {
    let user = db.data.users[m.sender]
    
    // Check cooldown
    if (new Date - user.lasthunt <= cooldown) {
        return m.reply(`📍 Sudah cukup perburuan kali ini\nGunakan waktu yang ada untuk beristirahat, perburuan selanjutnya dapat dimulai dalam . . .\n🕖 *${((user.lasthunt + cooldown) - new Date()).toTimeString()}*`)
    }
    
    // Check if user has necessary items
    if (user.armor == 0 || user.sword == 0 || user.bow == 0) {
        return m.reply(`Perlu *${usedPrefix}craft* armor, sword, dan bow terlebih dahulu.\n\nAnda memiliki :\n━ 🥼 ${user.armor} Armor\n━ ⚔️ ${user.sword} Sword\n━ 🏹 ${user.bow} Bow`)
    }
    
    // Determine hunting area based on user position
    let area = user.position || 'Azure Stronghold'; // Default area if not set
    
    if (text) {
        let chosenArea = text.trim();
        if (huntingTargets[chosenArea]) {
            area = chosenArea;
            user.position = area;
        } else {
            return m.reply(`Area tidak dikenal. Pilih dari area berikut:\n${Object.keys(mapLocations).join(', ')}`);
        }
    }
    let targets = huntingTargets[area];
    let buruan = targets.map(target => ({ target, count: ranNumb(0, 2) })).filter(({ count }) => count > 0)
    
    // Send initial hunting message
    await m.reply('_Perburuan Dimulai..._ 🏹')
    
    // Delay result for 10 seconds
    setTimeout(() => {
        let gmbrt = 'https://i.ibb.co/3ywFkYS/hunting-in-mirkwood-by-merlkir-d6e1jhp.jpg'
        let hsl = `*[ Perburuan Selesai ]*\n Kamu berburu di *${area.toUpperCase()}* \n\nHasil tangkapan hari ini:\n\n` +
            buruan.map(({ target, count }) => `*🐾 ${target.toUpperCase()}* = [ ${count} ]`).join('\n')
        
        if (buruan.length === 0) {
            hsl += '\nSayang sekali, kamu tidak menangkap apapun kali ini. Coba lagi nanti! 🌿'
        } else {
            hsl += `\n\nSelamat! Kamu berhasil mendapatkan beberapa hewan! 🎉`
        }

        // Update user data
        for (let { target, count } of buruan) {
            user[target] = (user[target] || 0) + count
        }
        user.armordurability -= ranNumb(80, 120)
        user.sworddurability -= ranNumb(80, 120)
        user.bowdurability -= ranNumb(80, 120)
        if (user.armordurability <= 0) {
            user.armordurability = 0
            user.armor = 0
        }
        if (user.sworddurability <= 0) {
            user.sworddurability = 0
            user.sword = 0
        }
        if (user.bowdurability <= 0) {
            user.bowdurability = 0
            user.bow = 0
        }
        
        // Send results
        conn.sendFile(m.chat, gmbrt, '', hsl, m)
    }, resultDelay)
    user.lasthunt = new Date().getTime()
}

handler.menu = ['berburu']
handler.tags = ['rpg']
handler.command = /^(berburu)$/i
handler.cooldown = cooldown
handler.register = true
handler.group = true

export default handler