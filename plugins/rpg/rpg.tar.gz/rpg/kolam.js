import db from '../../lib/database.js'

let fishNames = ['nixie', 'triton', 'marlin', 'coralin', 'finley', 'gourami', 'azure', 'wave', 'keplie', 'lagoon', 'aqualis', 'fingrod', 'nymphora', 'zeplyn', 'tritonus', 'finara', 'naucitus', 'tetra', 'clownfi', 'hyoxis'];

let handler = async (m, { conn }) => {
    let userData = db.data.users[m.sender];
    let username = userData.name;
    let leveluser = userData.level;

    let past = '*—「 KOLAM  」—*\n━─┈───────────────┈─━\n';
    fishNames.forEach(fishName => {
        past += `• ${capitalizeFirstLetter(fishName)}: *${userData[fishName]}*\n`;
    });

    past += `• ${capitalizeFirstLetter(fishNames[fishNames.length - 1])}: *${userData[fishNames[fishNames.length - 1]]}*\n`;

    past += '━─┈───────────────┈─━\n';
    past = past.trim();

    conn.sendMessage(m.chat, {
        text: past,
        contextInfo: {
            externalAdReply: {
                title: `Name : ${username}`,
                body: `Level : ${leveluser}`,
                thumbnailUrl: `https://i.ibb.co/TBrRcBy/healing-springs-by-jjpeabody-d7kdjsz-pre.jpg`,
                mediaType: 1,
                renderLargerThumbnail: true
            }
        }
    });
}

function capitalizeFirstLetter(string) {
    return string.charAt(0).toUpperCase() + string.slice(1);
}

handler.menu =  ['kolam']
handler.tags =  ['rpg']
handler.command = /^(kotak(ikan)?|kolam(ikan)?)$/i
handler.register = true
export default handler
