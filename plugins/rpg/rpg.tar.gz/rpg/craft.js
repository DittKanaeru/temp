import db from '../../lib/database.js'
import { isNumber } from '../../lib/func.js'

// Database sementara untuk menyimpan status konfirmasi
let confirmationDatabase = {}

const craftingRecipes = {
  'armor': { steel: 2, string: 4, iron: 6 },
  'sword': { iron: 11, steel: 4 },
  'pickaxe': { iron: 12, wood: 12 },
  'bow': { wood: 29, string: 3, iron: 1 },
  'fishingrod': { iron: 10, string: 4 },
  'steel': { iron: 2, yen: 4000 },
  'atm': { yen: 120000 },
  'kitsune': { iron: 300, yen: 10000000, steel: 300, string: 200, diamond: 70 },
  'velxian': { iron: 200, yen: 10000000, wood: 150, diamond: 20 }
}

const handler = async (m, { command, usedPrefix, args, text }) => {
  const user = db.data.users[m.sender]
  if (!user) return m.reply("❌ Data pengguna tidak ditemukan.")
  
  // Jika pengguna hanya menjawab "iya" atau "konfirmasi"
  if (text.trim().toLowerCase() === 'iya' || text.trim().toLowerCase() === 'konfirmasi') {
    const confirmKey = `${m.sender}_confirm`
    const confirmation = confirmationDatabase[confirmKey]
    if (!confirmation) {
      return m.reply('❌ Tidak ada item yang sedang dikonfirmasi untuk dibuat.')
    }

    const { item, total, recipe } = confirmation
    const missingResources = Object.entries(recipe)
      .filter(([resource, amount]) => (user[resource] || 0) < amount * total)

    if (missingResources.length > 0) {
      const missingResourcesText = missingResources.map(([resource, amount]) => `${amount * total - (user[resource] || 0)} ${resource}`).join(', ')
      delete confirmationDatabase[confirmKey]
      return m.reply(`❌ Kamu kekurangan ${missingResourcesText} untuk membuat *${item}*.`)
    }

    Object.entries(recipe).forEach(([resource, amount]) => {
      user[resource] -= amount * total
    })

    const durabilityMap = {
      'kitsune': 800,
      'velxian': 400
    }

    const defaultDurability = 250

    user[`${item}durability`] = (user[`${item}durability`] || 0) + (durabilityMap[item] || defaultDurability) * total
    user[item] = (user[item] || 0) + total
    user.craftcount = (user.craftcount || 0) + total

    delete confirmationDatabase[confirmKey]

    return m.reply(`✅ Berhasil membuat *${total} ${item}*.\n🛠️ *Durability:* ${user[`${item}durability`]}`)
  }

  if (!args[0]) {
    let info = `🛠️ *Crafting Command* 🛠️\n\nFormat: *${usedPrefix + command} [item] [jumlah]*\n`
    info += `Contoh: *${usedPrefix}${command} armor 2*\n\n`
    info += `*━━━[ 📜 Crafting List 📜 ]━━━*\n\n`
    Object.keys(craftingRecipes).forEach(item => {
      info += `- *${item.charAt(0).toUpperCase() + item.slice(1)}*\n\n`
    })
    return m.reply(info)
  }

  const [item, count] = args.map(arg => arg.toLowerCase())
  const total = Math.floor(isNumber(count) ? Math.min(Math.max(parseInt(count), 1), Number.MAX_SAFE_INTEGER) : 1)

  if (!craftingRecipes[item]) {
    return m.reply(`❌ Item *${item}* tidak ditemukan. Silakan cek kembali list crafting.`)
  }

  const recipe = craftingRecipes[item]
  const confirmKey = `${m.sender}_confirm`
  
  let confirmationMessage = `*[ Konfirmasi ]*\n\nKamu yakin mau buat *${item.charAt(0).toUpperCase() + item.slice(1)}*? Untuk membuat itu\n\n`
  Object.entries(recipe).forEach(([resource, amount]) => {
    confirmationMessage += `- ${resource.charAt(0).toUpperCase() + resource.slice(1)}: ${amount * total}\n`
  })
  confirmationMessage += `\nJika kamu yakin punya semua itu, balas ini dengan "Iya"`

  // Simpan konfirmasi di database sementara
  confirmationDatabase[confirmKey] = { item, total, recipe }

  m.reply(confirmationMessage)
}

handler.before = async (m) => {
  const user = db.data.users[m.sender]
  if (!user) return
  const confirmKey = `${m.sender}_confirm`
  const confirmation = confirmationDatabase[confirmKey]

  if (confirmation) {
    const { item, total, recipe } = confirmation

    const missingResources = Object.entries(recipe)
      .filter(([resource, amount]) => (user[resource] || 0) < amount * total)

    if (missingResources.length > 0) {
      const missingResourcesText = missingResources.map(([resource, amount]) => `${amount * total - (user[resource] || 0)} ${resource}`).join(', ')
      delete confirmationDatabase[confirmKey]
      return m.reply(`❌ Kamu kekurangan ${missingResourcesText} untuk membuat *${item}*.`)
    }

    Object.entries(recipe).forEach(([resource, amount]) => {
      user[resource] -= amount * total
    })

    const durabilityMap = {
      'kitsune': 800,
      'velxian': 400
    }

    const defaultDurability = 250

    user[`${item}durability`] = (user[`${item}durability`] || 0) + (durabilityMap[item] || defaultDurability) * total
    user[item] = (user[item] || 0) + total
    user.craftcount = (user.craftcount || 0) + total

    delete confirmationDatabase[confirmKey]

    return m.reply(`✅ Berhasil membuat *${total} ${item}*.\n🛠️ *Durability:* ${user[`${item}durability`]}`)
  }
}

handler.menu = ['craft']
handler.tags = ['rpg']
handler.command = /^(craft(ing)?)$/i
handler.register = true
handler.group = true

export default handler
