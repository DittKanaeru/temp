import db from '../../lib/database.js';

// Deskripsi untuk setiap skill
const skillDescriptions = {
    mage: 'Mage - Pengendali sihir yang mampu melancarkan serangan magis dahsyat. Gunakan kekuatan elemen untuk menghancurkan musuh dari kejauhan.',
    archer: 'Archer - Penembak jitu yang mematikan dengan keahlian panah. Serang musuh dari jarak jauh dengan ketepatan yang luar biasa.',
    tanker: 'Tanker - Pelindung kokoh yang mampu menahan serangan musuh. Berdiri di garis depan dan lindungi timmu dengan pertahanan yang kuat.',
    assassin: 'Assassin - Pembunuh bayangan yang licin dan mematikan. Serang musuh dengan serangan kritis dan menghilang tanpa jejak.',
    fighter: 'Fighter - Petarung tangguh yang ahli dalam pertempuran jarak dekat. Gunakan kekuatan fisik dan keberanian untuk mendominasi pertempuran.'
};

// Waktu cooldown dalam milidetik (2 bulan)
const cooldownPeriod = 2 * 30 * 24 * 60 * 60 * 1000;

const handler = async (m, { usedPrefix, text, command }) => {
    const user = db.data.users[m.sender];
    const skills = Object.keys(skillDescriptions);

    const chosenSkill = text.trim().toLowerCase();

    if (!chosenSkill) {
        return m.reply(`Wahai pejuang, mungkin inilah saatnya kamu untuk memilih skill yang dapat kamu gunakan.

Di bawah ini kamu bisa memilih skill yang ingin kamu gunakan. Namun ingat, berhati-hatilah dalam memilih skill. Kamu hanya bisa memilih dalam 1 waktu selama 2 bulan.

*[ Skills ]*

› *[ Mage ]*
Mage - Pengendali sihir yang mampu melancarkan serangan magis dahsyat. Gunakan kekuatan elemen untuk menghancurkan musuh dari kejauhan.

› *[ Archer ]*
Archer - Penembak jitu yang mematikan dengan keahlian panah. Serang musuh dari jarak jauh dengan ketepatan yang luar biasa.

› *[ Tanker ]*
Tanker - Pelindung kokoh yang mampu menahan serangan musuh. Berdiri di garis depan dan lindungi timmu dengan pertahanan yang kuat.

› *[ Assassin ]*
Assassin - Pembunuh bayangan yang licin dan mematikan. Serang musuh dengan serangan kritis dan menghilang tanpa jejak.

› *[ Fighter ]*
Fighter - Petarung tangguh yang ahli dalam pertempuran jarak dekat. Gunakan kekuatan fisik dan keberanian untuk mendominasi pertempuran.

Cara menggunakan:
${usedPrefix + command} <nama_skill>

Contoh:
${usedPrefix + command} archer`);
    }

    if (!skills.includes(chosenSkill)) {
        return m.reply(`Skill yang kamu pilih tidak valid. Wahai pejuang, mungkin inilah saatnya kamu untuk memilih skill yang dapat kamu gunakan.

Di bawah ini kamu bisa memilih skill yang ingin kamu gunakan. Namun ingat, berhati-hatilah dalam memilih skill. Kamu hanya bisa memilih dalam 1 waktu selama 2 bulan.

*[ Skills ]*

› *[ Mage ]*
Mage - Pengendali sihir yang mampu melancarkan serangan magis dahsyat. Gunakan kekuatan elemen untuk menghancurkan musuh dari kejauhan.

› *[ Archer ]*
Archer - Penembak jitu yang mematikan dengan keahlian panah. Serang musuh dari jarak jauh dengan ketepatan yang luar biasa.

› *[ Tanker ]*
Tanker - Pelindung kokoh yang mampu menahan serangan musuh. Berdiri di garis depan dan lindungi timmu dengan pertahanan yang kuat.

› *[ Assassin ]*
Assassin - Pembunuh bayangan yang licin dan mematikan. Serang musuh dengan serangan kritis dan menghilang tanpa jejak.

› *[ Fighter ]*
Fighter - Petarung tangguh yang ahli dalam pertempuran jarak dekat. Gunakan kekuatan fisik dan keberanian untuk mendominasi pertempuran.

Cara menggunakan:
${usedPrefix + command} <nama_skill>

Contoh:
${usedPrefix + command} archer`);
    }

    const now = Date.now();

    if (user.skill) {
        if (user.lastSkillChange && now - user.lastSkillChange < cooldownPeriod) {
            return m.reply(`Hai pejuang, skillmu saat ini adalah *${user.skill}* dan kamu tidak bisa mengubah skillmu sampai 2 bulan ke depan. Ingat, berhati-hatilah dalam berpetualang. Sejatinya, tak semua skill sempurna.`);
        }
    }

    user.skill = chosenSkill;
    user.lastSkillChange = now;
    return m.reply(`Baiklah pejuang, jika kamu sudah menentukan pilihanmu maka sekarang kamu adalah *${chosenSkill.charAt(0).toUpperCase() + chosenSkill.slice(1)}*. Berhati-hatilah dalam menggunakan skillmu dan jaga etika.`);
};

handler.menu = ['pilihskill'];
handler.tags = ['rpg'];
handler.command = /^(pilihskill|selectskill)$/i;
handler.register = true;
handler.group = true;

export default handler;
