import db from '../../lib/database.js';

const cooldown = 86400000; // 24 hours in milliseconds

function pickRandom(min, max) {
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

let handler = async (m, { conn }) => {
  let user = db.data.users[m.sender];

  if (!user) {
    user = db.data.users[m.sender] = { limit: 0, lastbonuslimit: 0 };
  }

  if (m.chat === "120363234020274962@g.us") {
    // Check if the user is still in the cooldown period
    if (new Date() - user.lastbonuslimit < cooldown) {
      const remainingTime = cooldown - (new Date() - user.lastbonuslimit);
      const minutes = Math.floor((remainingTime % 3600000) / 60000);
      const hours = Math.floor(remainingTime / 3600000);
      throw `Anda sudah mengklaim Limit Daily Claim! Tunggu *${hours} jam ${minutes} menit*`;
    }

    // Generate a random limit between 10 and 60
    let hasil = pickRandom(10, 60);
    user.limit += hasil;

    conn.reply(m.chat, `📣 Karena ini GC original, jadi nikmatin limitnya yaa! Kamu dapat *[${hasil}]* limit. Silakan cek`, m);
    user.lastbonuslimit = new Date() * 1; // Update the last bonus claim time
  } else {
    conn.sendMessage(
      m.chat,
      {
        text: "📣 Ga bisa klaim limit di sini kak, harus di GC utama baru bisa klaim.",
        contextInfo: {
          externalAdReply: {
            showAdAttribution: true,
            title: "Join sekarang ❗",
            body: "Ruka by Dixy4u",
            mediaType: 1,
            thumbnailUrl: "",
            sourceUrl: "https://chat.whatsapp.com/Jn4uIOeGpp2BZkCUku4434",
            renderLargerThumbnail: true,
          },
        },
      },
      { quoted: m }
    );
  }
};

handler.tags = ['rpg'];
handler.command = /^(Rklimit|rukalimit|getlimit)$/i; // Accept multiple command variations
handler.group = true;
handler.register = true;
handler.help = ['Rklimit', 'getlimit'];

export default handler;
