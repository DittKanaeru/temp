import db from '../../lib/database.js';
import items from '../../plugins/rpg/_misteri.js';
import moment from 'moment-timezone';

// Fungsi untuk menghasilkan diskon berdasarkan apakah user sudah menolak sebelumnya
const getUserDiscount = (userId) => {
    if (db.data.users[userId].rejected) {
        return Math.random() * 0.3 + 0.3; // Diskon antara 30% hingga 60%
    } else {
        return Math.random() * 0.6 + 0.3; // Diskon antara 30% hingga 90%
    }
};

// Fungsi untuk menghasilkan daftar item dengan diskon
const generateItemList = (discount) => {
    let itemList = `*[ MYSTERY SHOP IS UNLOCKED ]*:\n\nYour Discount Right now : ${Math.round(discount * 100)}%\n━─┈────────────┈─━\n`;
    for (const item in items) {
        const originalPrice = items[item].buyPrice || 0;
        const discountedPrice = items[item].buyPrice ? Math.floor(items[item].buyPrice * (1 - discount)) + ' yen' : '_Tidak bisa dibeli_';
        itemList += `> *${item.charAt(0).toUpperCase() + item.slice(1)}*\n`;
        itemList += `*Harga Asli:* ~${originalPrice} yen~\n`;
        itemList += `*Harga Diskon:* *[ ${discountedPrice} ]*\n\n`;
    }
    return itemList.trim();
};

// Fungsi untuk memilih hari acak dalam sebulan
const chooseRandomDay = () => {
    const daysInMonth = moment().daysInMonth();
    return Math.floor(Math.random() * daysInMonth) + 1;
};

// Fungsi untuk mengecek apakah hari ini adalah hari misteri yang dipilih
const isMysteryDay = () => {
    const now = moment().tz('Asia/Jakarta');
    const mysteryDay = db.data.mysteryDay || (db.data.mysteryDay = chooseRandomDay());
    return now.date() === mysteryDay;
};

// Fungsi untuk memberi tahu pengguna kapan Mystery Shop akan buka
const getNextMysteryDayMessage = () => {
    const now = moment().tz('Asia/Jakarta');
    const mysteryDay = db.data.mysteryDay || (db.data.mysteryDay = chooseRandomDay());
    const daysInMonth = moment().daysInMonth();

    if (now.date() > mysteryDay) {
        return `Mystery Shop akan dibuka pada tanggal ${mysteryDay} bulan depan.`;
    } else {
        return `Mystery Shop akan dibuka pada tanggal ${mysteryDay} bulan ini.`;
    }
};

const handler = async (m, { conn, command, args, usedPrefix }) => {
    const userId = m.sender;
    const user = db.data.users[userId] || (db.data.users[userId] = { yen: 0, rejected: false, items: {} });

    // Cek apakah hari ini adalah hari misteri yang dipilih
    if (!isMysteryDay()) {
        const nextMysteryDayMessage = getNextMysteryDayMessage();
        conn.reply(m.chat, `Mystery Shop hanya dibuka pada hari misteri. ${nextMysteryDayMessage}`, m);
        return;
    }

    if (args.length === 0) {
        const discount = getUserDiscount(userId);
        user.discount = discount;
        conn.reply(m.chat, generateItemList(discount), m);
        return;
    }

    if (args[0].toLowerCase() === 'iya' && user.waitingForResponse) {
        user.waitingForResponse = false;
        const discount = getUserDiscount(userId);
        user.discount = discount;
        user.rejected = false; // Reset rejection state
        const discountPercentage = Math.round(discount * 100);
        conn.reply(m.chat, `Selamat kamu dapat Diskon ${discountPercentage}% di Mystery Shop kali ini. Ingat jangan buang-buang diskonmu yaa.`, m);
        conn.reply(m.chat, generateItemList(discount), m);
    } else if (args[0].toLowerCase() === 'tidak' && user.waitingForResponse) {
        user.waitingForResponse = false;
        user.rejected = true; // Mark user as having rejected the offer
        conn.reply(m.chat, 'Baiklah', m);
    } else if (args[0].toLowerCase() === 'buy') {
        const itemName = args[1].toLowerCase();
        const amount = parseInt(args[2], 10);

        if (!items[itemName]) {
            conn.reply(m.chat, 'Item tidak ditemukan.', m);
            return;
        }

        if (isNaN(amount) || amount <= 0 || amount > 20) {
            conn.reply(m.chat, 'Jumlah pembelian harus antara 1 hingga 20.', m);
            return;
        }

        const totalPrice = items[itemName].buyPrice * amount * (1 - user.discount);
        if (user.yen < totalPrice) {
            conn.reply(m.chat, `Yen kamu tidak cukup. Kamu butuh ${Math.floor(totalPrice)} yen untuk membeli ${amount} ${itemName}.`, m);
            return;
        }

        user.yen -= Math.floor(totalPrice);
        user.items[itemName] = (user.items[itemName] || 0) + amount;
        conn.reply(m.chat, `Kamu berhasil membeli ${amount} ${itemName} seharga ${Math.floor(totalPrice)} yen.`, m);
    } else {
        conn.reply(m.chat, `*[ MYSTERY SHOP IS UNLOCKED ]*:\n\nYour Discount Right now : ${Math.round(user.discount * 100)}%\n━─┈────────────┈─━\n> Example : .misteryshop buy (item) (jumlah)`, m);
    }
};

handler.menurpg = ['misteryshop'];
handler.tagsrpg = ['rpg'];
handler.command = /^(misteryshop|ms)$/i;
handler.register = true;
handler.group = true;

export default handler;
