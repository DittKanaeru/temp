import db from '../../lib/database.js';

const cooldown = 3 * 60 * 60 * 1000; // 3 hours in milliseconds
const cooldownChangeJob = 30 * 24 * 60 * 60 * 1000; // 30 days in milliseconds

const jobs = {
    butcher: {
        failure: ['❌ Gagal Memotong Hewan', '🔪 Terluka Saat Memotong', '🛒 Barang Daganganmu Tidak Laku'],
        tasks: ['🐮 Kamu Berhasil Memotong Sapi dengan Baik', '🐷 Kamu Berhasil Memotong Babi dengan Cepat', '🐓 Kamu Berhasil Memotong Ayam dengan Rapi', '🥩 Kamu Menjual Semua Hasil Potongmu'],
        rewards: () => Math.floor(Math.random() * 25000) + 70000,
        message: (task, reward) => `✅ ${task}\nDan Mendapatkan yen Senilai *${reward}*`
    },
    doctor: {
        failure: ['❌ Gagal Menyembuhkan Pasien', '🏥 Klinik Terbakar', '💊 Obat Habis'],
        tasks: ['💉 Kamu Berhasil Menyembuhkan Banyak Pasien', '🧪 Kamu Menemukan Obat Baru', '🩺 Kamu Mendapat Penghargaan Medis', '📚 Kamu Menulis Buku Kesehatan'],
        rewards: () => Math.floor(Math.random() * 25000) + 70000,
        message: (task, reward) => `✅ ${task}\nDan Mendapatkan yen Senilai *${reward}*`
    },
    alchemist: {
        failure: ['❌ Gagal Membuat Ramuan', '💥 Eksperimen Meledak', '🧫 Bahan Baku Rusak'],
        tasks: ['🧪 Kamu Berhasil Membuat Ramuan Penyembuhan', '🔥 Kamu Membuat Ramuan Peledak yang Kuat', '🧙‍♂️ Kamu Menemukan Resep Baru', '🏆 Kamu Mendapat Penghargaan Alchemist Terbaik'],
        rewards: () => Math.floor(Math.random() * 25000) + 70000,
        message: (task, reward) => `✅ ${task}\nDan Mendapatkan yen Senilai *${reward}*`
    },
    adventurer: {
        failure: ['❌ Diserang oleh Monster', '🗺️ Tersesat di Hutan', '💀 Jatuh ke dalam Perangkap'],
        tasks: ['🗺️ Kamu Menemukan Harta Karun', '🛡️ Kamu Berhasil Mengalahkan Monster', '🏞️ Kamu Menemukan Tempat Tersembunyi', '🌟 Kamu Mendapatkan Pengalaman Berharga'],
        rewards: () => Math.floor(Math.random() * 25000) + 70000,
        message: (task, reward) => `✅ ${task}\nDan Mendapatkan yen Senilai *${reward}*`
    },
    blacksmith: {
        failure: ['❌ Gagal Membuat Senjata', '🔥 Bengkel Terbakar', '💔 Bahan Baku Rusak'],
        tasks: ['⚒️ Kamu Membuat Pedang Legendaris', '🛡️ Kamu Membuat Armor yang Kuat', '🔧 Kamu Memperbaiki Senjata dengan Baik', '🏅 Kamu Mendapat Pengakuan Sebagai Pandai Besi Terbaik'],
        rewards: () => Math.floor(Math.random() * 25000) + 70000,
        message: (task, reward) => `✅ ${task}\nDan Mendapatkan yen Senilai *${reward}*`
    },
    merchant: {
        failure: ['❌ Barang Daganganmu Dicuri', '💸 Harga Pasar Turun', '🚫 Barang Tidak Laku'],
        tasks: ['🛒 Barang Daganganmu Laris Manis', '📈 Kamu Mendapatkan Keuntungan Besar', '🤝 Kamu Mendapatkan Kesepakatan yang Baik', '🏆 Kamu Mendapat Penghargaan Pedagang Terbaik'],
        rewards: () => Math.floor(Math.random() * 25000) + 70000,
        message: (task, reward) => `✅ ${task}\nDan Mendapatkan yen Senilai *${reward}*`
    },
    farmer: {
        failure: ['❌ Gagal Panen', '🔥 Ladang Kamu Terbakar', '🐛 Tanamanmu Diserang Hama'],
        tasks: ['🌾 Kamu Memiliki Panen Berlimpah', '🌱 Tanamanmu Tumbuh dengan Subur', '🚜 Alat Pertanianmu Berfungsi dengan Baik', '💧 Irigasi Berjalan dengan Lancar'],
        rewards: () => Math.floor(Math.random() * 25000) + 70000,
        message: (task, reward) => `✅ ${task}\nDan Mendapatkan yen Senilai *${reward}*`
    },
    scavenger: {
        failure: ['❌ Terjebak dalam Perangkap', '🏚️ Tempat Persembunyianmu Ditemukan', '💀 Makanan dan Persediaanmu Habis'],
        tasks: ['🗑️ Kamu Menemukan Barang Berharga di Tempat Sampah', '🧠 Kamu Memecahkan Teka-teki untuk Menemukan Lokasi', '🔍 Kamu Menemukan Rahasia Tersembunyi', '🎁 Kamu Mendapatkan Hadiah yang Tak Terduga'],
        rewards: () => Math.floor(Math.random() * 25000) + 70000,
        message: (task, reward) => `✅ ${task}\nDan Mendapatkan yen Senilai *${reward}*`
    }
};

const pickRandom = (list) => list[Math.floor(Math.random() * list.length)];

const handler = async (m, { conn, command, args }) => {
    let user = db.data.users[m.sender];
    let time = cooldown - (new Date() - user.lastWorked);
    let timeChangeJob = cooldownChangeJob - (new Date() - user.changeJobTime);

    if (command === 'kerja') {
        if (user.job && time > 0) {
            let job = jobs[user.job];
            let taskIndex = Math.floor(Math.random() * job.tasks.length);
            let task = job.tasks[taskIndex];
            let reward = job.rewards();
            let message = job.message(task, reward);

            setTimeout(() => {
                if (taskIndex >= job.failure.length) {
                    m.reply(`❌ ${pickRandom(job.failure)}`);
                } else {
                    user.yen += reward;
                    m.reply(message);
                }
                user.lastWorked = new Date() * 1;
            }, Math.floor(Math.random() * 20000) + 10000); // 10-30 detik
        } else if (user.job && timeChangeJob > 0) {
            m.reply(`Kamu tidak bisa mengganti pekerjaan sekarang. Tunggu *${formatDuration(timeChangeJob)}* lagi.`);
        } else if (!user.job) {
            user.job = 'alchemist';
            user.changeJobTime = new Date() * 1;
            m.reply(`Kamu telah dipilihkan pekerjaan sebagai *alchemist*. Selamat bekerja!`);
        }
    }
};

handler.menu = ['kerja'];
handler.tags = ['rpg'];
handler.command = /^kerja$/i;
handler.register = true;
handler.group = true;
handler.cooldown = cooldown;

export default handler;

const formatDuration = (milliseconds) => {
    const seconds = Math.floor(milliseconds / 1000);
    const days = Math.floor(seconds / (3600 * 24));
    const hours = Math.floor((seconds % (3600 * 24)) / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    const remainingSeconds = seconds % 60;

    let durationString = '';
    if (days > 0) durationString += `${days} hari `;
    if (hours > 0) durationString += `${hours} jam `;
    if (minutes > 0) durationString += `${minutes} menit `;
    if (remainingSeconds > 0) durationString += `${remainingSeconds} detik`;

    return durationString.trim();
};