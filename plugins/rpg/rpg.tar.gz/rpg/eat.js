import db from '../../lib/database.js'

const foods = {
    'chicken_bakar': {
        name: 'Chicken Bakar',
        heal: 35
    },
    'fried_chicken': {
        name: 'Fried Chicken',
        heal: 35
    },
    'pig_bakar': {
        name: 'Pig Bakar',
        heal: 35
    }
}

let handler = async (m, { args, usedPrefix }) => {
    let user = db.data.users[m.sender]

    if (!args[0] || (args[0].toLowerCase() !== 'health' && args[0].toLowerCase() !== 'stamina')) {
        let foodList = Object.keys(foods).map(food => `${foods[food].name}: ${user[food] || 0}`).join('\n')
        return m.reply(`
List makanan yang dapat digunakan:
.eat health <nama makanan>
.eat stamina <nama makanan>

Daftar makanan yang tersedia:
${foodList}
Silakan pilih mana yang ingin digunakan.
        `.trim())
    }

    let healType = args[0].toLowerCase()

    let foodName = args.slice(1).join('_').toLowerCase()
    let food = foods[foodName]

    if (!food) {
        return m.reply(`Makanan tidak ditemukan dalam daftar.`)
    }

    if (healType === 'health' && user.health >= user.MAXhealth) {
        return m.reply(`Kamu sudah mencapai batas maksimal kesehatan.`)
    } else if (healType === 'stamina' && user.stamina >= user.MAXstamina) {
        return m.reply(`Kamu sudah mencapai batas maksimal stamina.`)
    }

    if (user[foodName] < 1) {
        return m.reply(`Kamu tidak memiliki ${food.name} untuk digunakan.`)
    }

    user[foodName] -= 1

    let currentHealAmount = Math.min(food.heal, (healType === 'health' ? user.MAXhealth - user.health : user.MAXstamina - user.stamina))
    if (healType === 'health') {
        user.health += currentHealAmount
    } else if (healType === 'stamina') {
        user.stamina += currentHealAmount
    }

    m.reply(`Berhasil menggunakan ${food.name}, kamu sekarang memiliki ${healType === 'health' ? 'kesehatan' : 'stamina'} sebanyak ${currentHealAmount}.`)
}

handler.menu =  ['eat']
handler.tags =  ['rpg']
handler.command = /^(eat)$/i
handler.register = true
handler.group = true

export default handler
