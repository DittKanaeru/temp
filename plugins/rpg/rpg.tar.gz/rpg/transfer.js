import db from '../../lib/database.js'

let itemName = {
    'yen': 'yen',
    'tabungan': 'Tabungan',
    'potion': 'Potion',
    'trash': 'Trash',
    'diamond': 'Diamond',
    'common': 'Common',
    'uncommon': 'Uncommon',
    'mythic': 'Mythic',
    'legendary': 'Legendary',
    'string': 'String',
    'wood': 'Wood',
    'rock': 'Rock',
    'iron': 'Iron',
    'limit': 'limit'
}

let handler = async (m, { conn, args, usedPrefix, DevMode }) => {
    try {
        if (args.length < 3) {
            const availableItems = Object.keys(itemName).map(item => `- ${itemName[item]}`).join('\n');
            return conn.reply(m.chat, `Contoh: *${usedPrefix}transfer yen 100 @tag*\n\nList yang bisa di transfer:\n${availableItems}`, m);
        }

        let type = args[0].toLowerCase()
        let count = parseInt(args[1]) || 0
        let who = m.mentionedJid ? m.mentionedJid[0] : args[2] + '@s.whatsapp.net'

        if (!m.mentionedJid || !args[2]) return m.reply('Tag salah satu, atau ketik nomornya!')

        if (!(type in itemName)) {
            return conn.reply(m.chat, `List yang bisa di transfer: ${Object.keys(itemName).join(', ')}`, m)
        }

        if (count <= 0) {
            return conn.reply(m.chat, `Jumlah item yang akan ditransfer harus lebih besar dari 0.`, m)
        }

        // Pengecekan apakah user pengirim valid
        if (!db.data.users[m.sender]) {
            return conn.reply(m.chat, `Data pengguna tidak ditemukan.`, m)
        }

        let userItem = db.data.users[m.sender][type]
        if (userItem < count) {
            return conn.reply(m.chat, `${itemName[type]} kamu tidak mencukupi untuk mentransfer sebanyak ${count}`, m)
        }

        // Pengecekan apakah user penerima valid
        if (!db.data.users[who]) {
            db.data.users[who] = {}
            for (let key in itemName) {
                db.data.users[who][key] = 0
            }
        }

        // Jika jenis item adalah yen, terapkan pajak 11%
        if (type === 'yen') {
            let tax = Math.ceil(count * 0.11) // Pajak 11%
            let amountAfterTax = count - tax

            if (amountAfterTax <= 0) {
                return conn.reply(m.chat, `Jumlah yen yang akan ditransfer setelah pajak harus lebih besar dari 0.`, m)
            }

            // Kurangi yen dari pengirim dan tambahkan ke penerima setelah pajak
            db.data.users[m.sender][type] -= count
            db.data.users[who][type] = (db.data.users[who][type] || 0) + amountAfterTax

            conn.reply(m.chat, `Berhasil mentransfer ${amountAfterTax} yen ke @${who.split('@')[0]} (termasuk pajak 11%: ${tax} yen)`, m)
        } else {
            // Lakukan transfer item lain tanpa pajak
            db.data.users[m.sender][type] -= count
            db.data.users[who][type] = (db.data.users[who][type] || 0) + count

            conn.reply(m.chat, `Berhasil mentransfer ${count} ${itemName[type]} ke @${who.split('@')[0]}`, m)
        }

    } catch (e) {
        conn.reply(m.chat, `Terjadi kesalahan saat menjalankan perintah. Silakan coba lagi.`, m)
        console.error(e)
        if (DevMode) {
            let text = `Transfer.js error\nNo: *${m.sender.split`@`[0]}*\nCommand: *${m.text}*\n\n${e}`
            for (let jid of global.owner.map(v => v.replace(/[^0-9]/g, '') + '@s.whatsapp.net').filter(v => v != conn.user.jid)) {
                conn.reply(jid, text, m)
            }
        }
    }
}

handler.menu = ['transfer']
handler.tags = ['rpg']
handler.command = /^(transfer|tf)$/i
handler.register = true
handler.group = true
export default handler
