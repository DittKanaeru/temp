const items = {
    health_breaker: {
        buyPrice: 5000000,
        sellPrice: null // Tidak bisa menjual limit
    },
    stamina_breaker: {
        buyPrice: 5000000,
        sellPrice: null
    },
    vrpass: {
        buyPrice: 50000,
        sellPrice: null
    }
};

export default items;