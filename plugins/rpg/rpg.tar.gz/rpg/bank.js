/*import db from '../../lib/database.js'

let handler = async (m, { conn }) => {
  let user = db.data.users[m.sender]
  let level = db.data.users[m.sender].level
  let leveluser = `${level}`
  const caption = `
*Name :* ${user.registered ? user.name : conn.getName(m.sender)}
*yen :* ${new Intl.NumberFormat('en-US').format(user.yen)} 💲
*Bank :* ${new Intl.NumberFormat('en-US').format(user.bank)} 💲

*Rial :* ${new Intl.NumberFormat('en-US').format(user.rial)} 💲
`.trim()
conn.sendMessage(m.chat, {
  text: caption,
  contextInfo: {
      externalAdReply: {
          title: `Dragon's Hoard Bank`,
          body: `Your Account`,
          thumbnailUrl: 'https://i.ibb.co/9pskv9m/gutshot-square-by-deivcalviz-dc8bmht-min.jpg',
          mediaType: 1,
          renderLargerThumbnail: true
      }
  }
})
}
handler.menu =  ['bank']
handler.tags =  ['rpg']
handler.command = /^(bank|atm|dompet)$/i
handler.register = true

export default handler
*/

import db from '../../lib/database.js'

const formatCurrency = (value) => {
  if (value >= 1_000_000_000) return (value / 1_000_000_000).toFixed(1) + 'm';
  if (value >= 1_000_000) return (value / 1_000_000).toFixed(1) + 'jt';
  if (value >= 1_000) return (value / 1_000).toFixed(1) + 'k';
  return value.toString();
}

const deductBankToCoverYen = (user) => {
  if (user.yen < 0) {
    const yenOwed = Math.abs(user.yen);  // The amount of negative yen (debt)
    
    if (user.bank > 0) {
      // Check if bank has enough to cover the full negative yen
      if (user.bank >= yenOwed) {
        user.bank -= yenOwed;   // Deduct exactly what's owed
        user.yen = 0;           // Clear the negative yen
      } else {
        // If bank doesn't have enough, just deduct what's available
        user.yen += user.bank;  // Reduce the debt by the bank's available amount
        user.bank = 0;          // Empty the bank
      }
    }
  }
}

let handler = async (m, { conn }) => {
  let user = db.data.users[m.sender];

  // Deduct from bank if yen is negative
  deductBankToCoverYen(user);

  // Format currency values
  let yenFormatted = formatCurrency(user.yen);
  let bankFormatted = formatCurrency(user.bank);
  let rialFormatted = formatCurrency(user.rial);
  
  const caption = `
*Name :* ${user.registered ? user.name : conn.getName(m.sender)}
*Yen :* ${yenFormatted} 💲
*Bank :* ${bankFormatted} 💲
*Rial :* ${rialFormatted} 💲
`.trim();

  conn.sendMessage(m.chat, {
    text: caption,
    contextInfo: {
      externalAdReply: {
        title: `Dragon's Hoard Bank`,
        body: `Your Account`,
        thumbnailUrl: 'https://i.ibb.co/9pskv9m/gutshot-square-by-deivcalviz-dc8bmht-min.jpg',
        mediaType: 1,
        renderLargerThumbnail: true
      }
    }
  });
};

handler.help = ['bank'];
handler.tags = ['rpg'];
handler.command = /^(bank|atm|dompet)$/i;
handler.register = true;
handler.group = true

export default handler;
